package main

import (
	"fmt"
	"math/rand"
)

func main() {
	upgift1()
	upgift2()
}

// Upgift 1

func upgift1() {
	var dice1 int
	var dice2 int
	freq := make([]int, 13)

	for i := 0; i < 10000; i++ {
		dice1 = rand.Intn(6) + 1 // 0-5 + 1
		dice2 = rand.Intn(6) + 1
		sum := dice1 + dice2
		freq[sum]++
	}

	for j := 2; j < 13; j++ {
		fmt.Println(j, freq[j])
	}
}

// Upgift 2

func upgift2() {
	//skapa grid
	x := 2
	y := 2
	var twoD [5][5]int
	for i := 0; i < 5; i++ {
		for j := 0; j < 5; j++ {
			twoD[i][j] = 0
		}
	}
	twoD[x][y] = 1
	fmt.Println(twoD)
	for x >= 0 && y >= 0 && x < 5 && y < 5 {
		twoD[x][y] = 0

		dir := rand.Intn(4)
		if dir == 0 {
			x++
		} else if dir == 1 {
			x--
		} else if dir == 2 {
			y++
		} else {
			y--
		}
		if x < 0 || y < 0 || x >= 5 || y >= 5 {
			break
		}
		twoD[x][y] = 1
		fmt.Println(twoD)
	}
}

// Upgift 3

type Item int

type Node struct {
	key   int
	value Item
	left  *Node
	right *Node
}

type ItemBinarySearchTree struct {
	root *Node
}

func (bst *ItemBinarySearchTree) Insert(key int, value Item) {
	n := &Node{key, value, nil, nil}
	if bst.root == nil {
		bst.root = n
	} else {
		insertNode(bst.root, n)
	}
}

func insertNode(node, newNode *Node) {
	if newNode.key < node.key {
		if node.left == nil {
			node.left = newNode
		} else {
			insertNode(node.left, newNode)
		}
	} else {
		if node.right == nil {
			node.right = newNode
		} else {
			insertNode(node.right, newNode)
		}
	}
}

func remove(node *Node, key int) *Node {
	if node == nil {
		return nil
	}
	if key < node.key {
		node.left = remove(node.left, key)
		return node
	}
	if key > node.key {
		node.right = remove(node.right, key)
		return node
	}
	// key = node.key
	if node.left == nil && node.right == nil {
		node = nil
		return nil
	}
	if node.left == nil {
		node = node.right
		return node
	}
	if node.right == nil {
		node = node.left
		return node
	}
	leftmostrightside := node.right
	for {
		//hitta minsta värde på högersida
		if leftmostrightside != nil && leftmostrightside.left != nil {
			leftmostrightside = leftmostrightside.left
		} else {
			break
		}
	}
	node.key, node.value = leftmostrightside.key, leftmostrightside.value
	node.right = remove(node.right, node.key)
	return node
}

func upgift3() {
	var bst ItemBinarySearchTree
	bst.Insert(10, 10)
}
