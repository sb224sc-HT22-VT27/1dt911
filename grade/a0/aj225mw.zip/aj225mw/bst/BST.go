package main

import (
	"fmt"

)

/*
Looks ok. 

Minor comments: 
- Would prefer a BST type that stores the root node. For instance: 
type BST struct {
    root *Node
}
- Remove method is ok, but a simpler implementation can be made. 
- The tree is not generic. Only applicable for integers.
// 
Petter
*/


type Node struct {
    Value int
    Left  *Node
    Right *Node
}

func (n *Node) Add(value int) *Node { // Lägg till en nod i trädet
	if n == nil {
		return &Node{Value: value}
	}
	if value < n.Value {
		n.Left = n.Left.Add(value)
	} else if value > n.Value {
		n.Right = n.Right.Add(value)
	}
	return n
}



func (n *Node) Search(value int) bool { // Sök efter ett värde i trädet
	if n == nil {
		return false
	}
	if value == n.Value {
		return true
	} else if value < n.Value {
		return n.Left.Search(value)
	} else {
		return n.Right.Search(value)
	}
}

func (n *Node) InOrder() { // Skriv ut trädet i ordning
	if n != nil {
		n.Left.InOrder()
		fmt.Print(n.Value, " ")
		n.Right.InOrder()
	}
}


func deleteNode(n *Node, value int, parent *Node) bool { // Ta bort en nod från trädet
    if n == nil {
        return false
    }

    if value < n.Value {
        return deleteNode(n.Left, value, n)
    } else if value > n.Value {
        return deleteNode(n.Right, value, n)
    } else {
        // Case 1: inga vänsterbarn
        if n.Left == nil {
            if parent != nil {
                if parent.Left == n {
                    parent.Left = n.Right
                } else if parent.Right == n {
                    parent.Right = n.Right
                }
            }
            return true
        }

        // Case 2: finns vänsterbarn hitta största noden
        largest := n.Left
        largestParent := n

        for largest.Right != nil {
            largestParent = largest
            largest = largest.Right
        }

        n.Value = largest.Value

        if largestParent.Left == largest {
            largestParent.Left = largest.Left
        } else {
            largestParent.Right = largest.Left
        }

        return true
    }
}


func main() {
 	var root *Node

    values := []int{6, 2, 8, 1, 4, 7, 10, 3, 5}

    for _, v := range values {
        root = root.Add(v)
    }

    fmt.Print("InOrder traversal: ")
    root.InOrder()
    fmt.Println()

    fmt.Println("Search for 7:", root.Search(7))
    fmt.Println("Search for 9:", root.Search(9))
	
    fmt.Println("Delete 4")
	deleteNode(root, 4, nil)

    fmt.Println("Delete 8") // NEW LINE
	deleteNode(root, 8, nil) // NEW LINE

    fmt.Println("Delete 7") // NEW LINE
	deleteNode(root, 7, nil) // NEW LINE

    fmt.Println("Delete 10") // NEW LINE
	deleteNode(root, 10, nil) // NEW LINE

	fmt.Print("InOrder traversal after deletion: ")
	root.InOrder()
	fmt.Println()

}