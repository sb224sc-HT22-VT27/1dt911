package main

import (
	"fmt"
	"math/rand"
)

/*
Could be better.
Quicksort should only use one list, i.e., the list subject for sorting that is
passed as an argument in the QuickSort method. Your QuickSort method creates
two extra lists as helpers for the sorting process. Use indices instead.

// Petter
*/

func main() {
	values := []int{6, 2, 8, 1, 4, 7, 10, 3, 5}
	sortedLst := QuickSort(values)
	fmt.Println(QuickSort(sortedLst))
	fmt.Println("is sorted:", isSorted(sortedLst))

	// COMMENT: Testing your QuickSort implementation.
	experiments := 20
	elements := 100_000
	for i := 0; i < experiments; i++ {
		lst := make([]int, elements)
		for i := 0; i < elements; i++ {
			e := rand.Intn(elements)
			lst[i] = e
		}
		sortedLst = QuickSort(lst)
		fmt.Println("Is sorted:", isSorted(sortedLst))
	}
}

func QuickSort(a []int) []int { // COMMENT: Use pointer instead of returning a new lst
	if len(a) <= 1 {
		return a
	}

	pivot := a[len(a)-1]

	left := []int{}
	right := []int{}
	// Splitta i två listor
	for i := 0; i < len(a)-1; i++ {
		if a[i] < pivot {
			left = append(left, a[i])
		} else {
			right = append(right, a[i])
		}
	}
	shortLeft := QuickSort(left)
	shortRight := QuickSort(right)

	// Slå ihop listorna
	return append(append(shortLeft, pivot), shortRight...)
}

// ADDED METHOD
func isSorted(lst []int) bool {
	size := len(lst)
	for i := 0; i < size-1; i++ {
		if lst[i] > lst[i+1] {
			return false
		}
	}
	return true
}
