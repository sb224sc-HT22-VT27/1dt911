package main

import (
	"fmt"
	"math/rand"
)

/*
ok.
See comments in code.

// Petter
*/

func main() {
	arr := [11]int{}
	fmt.Println("Array before:", arr)

	fmt.Println("Array after:", arr) // COMMENT: Same array as the one above?
	frecuency := make([]int, 13)     // en array för summor 2-12. COMMENT: A suggestion is to make a slice of size 11, then
									 // use sum - 2 as a index when incrementing frequency (slice) elements.
									 // For instance, if you roll 2, then 2 would correspond to index 0
									 // since 2 - 2 = 0
	a := 10000
	for i := 0; i < a; i++ {
		roll1 := rand.Intn(6) + 1
		roll2 := rand.Intn(6) + 1
		sum := roll1 + roll2
		frecuency[sum]++ // COMMENT: If slice would be of size 11, then you simply put frequency[sum - 2]++

	}

	total := 0
	for sum := 2; sum <= 12; sum++ { // skriv ut frekvensen för varje summa
		fmt.Println(frecuency[sum])

		total += frecuency[sum]
	}
	fmt.Println("Total:", total)
}
