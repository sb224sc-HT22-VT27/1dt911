package main

import (
	"fmt"
    "math/rand/v2"
)

/*
ok

// Petter
*/
func main() {
	x := 5
	y := 5
	// antalet steg
	for i := 0; i < 20; i++ {
		
		a := rand.IntN(4)
		fmt.Println(a)
		switch a {
			case 0:
				 x += 1
			case 1:
				 x -= 1
			case 2:
				 y += 1
			case 3:
				 y -= 1
			}
			fmt.Println("("+ fmt.Sprint(x)+ "," + fmt.Sprint(y)+")")
			// kontrollera om gräsklipparen är utanför gräsmattan

		/*
		COMMENT:
		Remark that the assignment instructions state that -k <= x, y <= k where
		k = 5 in your case. 
		Reading from your code, it seems that you have moved the coordinate system to
		the first quadrant and defined (5, 5) as origo.
		This is a minor remark, yes, but details matter and can be a deciding factor
		for interpreteting the assignment task correctly.
		// Petter
		*/
		if x == 0 || y == 0 || x == 10 || y == 10 {
			fmt.Println("Mower is out of bounds!")
			break
		}
	}
}

