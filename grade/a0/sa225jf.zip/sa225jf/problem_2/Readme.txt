Problem2  Random walk simulation
--------------------------------

In this program simulate a random walk on agrid from coordinates (-k, -k)
to (k, k).

The walk start at (0,0) and then move one step at a time in a random way: up, down, lef  or right.

The walk stop when the maximun number of stepes been reached, or the walker move outside the boundary [-k, k] x [-k, k].

How can run random walk program:
---------------------------------
"go run random_walk.go"


In this problem 
----------------

I used the official Go documentation and Go by Example"https://moodle.lnu.se/mod/url/view.php?id=5010362" for understanding the basic concepts such as loops, and generating random numbers.
I also used material from the course lectuers "https://moodle.lnu.se/mod/resource/view.php?id=5004843" to structure the solution.

The conceptes that used in this problem:
-----------------------------------------
Random numbers(rand/v2)
loops
conditionals(if / if else/ else)
coordinate tracking(x,y on 2D grid)
stop exeution when crossing the boundary
