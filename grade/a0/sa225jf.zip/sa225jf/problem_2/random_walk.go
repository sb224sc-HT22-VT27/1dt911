package main

import (
	"fmt"
	"math/rand/v2"
)

/*
Good. 
See comments below.
// Petter
*/

// COMMENT: try to avoid global variables. Define variables in methods.
var k int
var mx_St int
var x int
var y int

func main() {
	fmt.Println("Entr boundary k: ")
	fmt.Scan(&k)

	fmt.Println("Enter Max number of Stepes: ")
	fmt.Scan(&mx_St)
	// Here stara the postion
	x = 0
	y = 0

	for st := 1; st <= mx_St; st++ {
		m_ov := rand.IntN(4)
		if m_ov == 0 {
			y++

		} else if m_ov == 1 {
			y--
		} else if m_ov == 2 {
			x--
		} else {
			x++
		}
		if x < -k || x > k || y < -k || y > k {
			fmt.Println("This went beyond the limits in the step", st)
			fmt.Println("The final position is : ", x, y)
			return
		}

	}
	fmt.Println("The walk finshed normal")
	fmt.Println("The final position is : ", x, y)
}
