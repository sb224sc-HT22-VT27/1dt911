package main

import (
	"fmt"
	"math/rand"
)

/*
GOOD JOB!

// Petter
*/

func Quick_sort(a []int) {
	if len(a) < 2 {
		return
	}
	// I chose the last element from the list as pivot
	pi_vot := a[len(a)-1]

	// Then dela upp slicen
	i := 0

	for j := 0; j < len(a)-1; j++ {
		if a[j] < pi_vot {
			a[i], a[j] = a[j], a[i]
			i++
		}
	}
	// Then lägga the Pivot in the correct place
	a[i], a[len(a)-1] = a[len(a)-1], a[i]
	// ordna altså sortera the left and right side
	Quick_sort(a[:i])
	Quick_sort(a[i+1:])
}

func main() {
	d := []int{5, 2, 9, 10, 0, 3, 1, 7, 8}
	fmt.Println("The orignal list: ", d)
	Quick_sort(d)
	fmt.Println("Affter used the Quick Sort:", d)

	// COMMENT: Testing your QuickSort implementation.
	experiments := 20
	elements := 100_000
	for i := 0; i < experiments; i++ {
		lst := make([]int, elements)
		for i := 0; i < elements; i++ {
			e := rand.Intn(elements)
			lst[i] = e
		}
		Quick_sort(lst)
		fmt.Println("Is sorted:", isSorted(lst)) // OK
	}
}

// ADDED METHOD
func isSorted(lst []int) bool {
	size := len(lst)
	for i := 0; i < size-1; i++ {
		if lst[i] > lst[i+1] {
			return false
		}
	}
	return true
}
