Problem 4 about Quick sort on slices
-------------------------------------


The Program applies a quick sort algorithm to a list of integers in Go language.

The algorithm sort the list in ascending order using a divide and conquer method with iteration.

The last element in the list is chosen as the pivot item. All values smaller than the pivot element are moved to the left of the list , and all values larger than pivot are moved to the right os the lisst.
This procedure is then repeated for the left and right sublist.

The sorting is performed in place, meaning the orignal list is modified.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

How run the program in the terminal:
------------------------------------

open the terminal and just write "go run Quick_sort.go"

Example for output:
-------------------
PS C:\Users\shaza\Desktop\systemprogram\Assigment_0\problem_4> go run Quick_sort.go
The orignal list:  [5 2 9 10 0 3 1 7 8]
Affter used the Quick Sort: [0 1 2 3 5 7 8 9 10]
PS C:\Users\shaza\Desktop\systemprogram\Assigment_0\problem_4> 


The concepts as I needed to use for this program from Go:
---------------------------------------------------------

Slices, Functions, Recurision, For loops, If statment (conditions), And swaping value in the slices

sources:
--------

The lecture from the course 
"https://moodle.lnu.se/pluginfile.php/10553085/mod_resource/content/2/lecture_1_intro_to_go.pdf", 
Go by Example "https://gobyexample.com/" , 
and official Go documentation.