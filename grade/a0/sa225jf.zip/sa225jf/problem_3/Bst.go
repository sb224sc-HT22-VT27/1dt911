package main

import "fmt"

/*
Good job.

Minor comments:
- The tree is not generic. Only applicable for integers and strings.
- Stick to english when defining any identifiers, types, interfaces, etc.
//  Petter
*/

type Ord interface {
	~int | ~string
}

// En nod i trädet
type Nod[T Ord] struct {
	valu T

	lef *Nod[T]
	rig *Nod[T]
}

// the binary search tree pekar på rot alltså noden
type BST[T Ord] struct {
	r *Nod[T]
}

func (t_ *BST[T]) Add(v_ T) {
	t_.r = add_rec(t_.r, v_)
}

// add en värde

func add_rec[T Ord](n *Nod[T], v_ T) *Nod[T] {
	if n == nil {
		return &Nod[T]{valu: v_}
	}
	if v_ < n.valu {
		n.lef = add_rec(n.lef, v_)
	} else if v_ > n.valu {
		n.rig = add_rec(n.rig, v_)
	}
	return n
}

// find en värde

func (t_ *BST[T]) Find(v_ T) bool {
	return find_rec(t_.r, v_)
}

func find_rec[T Ord](n *Nod[T], v_ T) bool {
	if n == nil {
		return false
	}
	if v_ == n.valu {
		return true
	}
	if v_ < n.valu {
		return find_rec(n.lef, v_)
	}
	return find_rec(n.rig, v_)
}

//remove en värde

func (t_ *BST[T]) remove(v_ T) {
	t_.r = remov_rec(t_.r, v_)

}
func remov_rec[T Ord](n *Nod[T], v_ T) *Nod[T] {
	if n == nil {
		return nil
	}
	if v_ < n.valu {
		n.lef = remov_rec(n.lef, v_)
		return n
	}
	if v_ > n.valu {
		n.rig = remov_rec(n.rig, v_)
		return n
	}
	// if det finns ingen Children
	if n.lef == nil && n.rig == nil {
		return nil
	}
	// if det finns ett children
	if n.lef == nil {
		return n.rig
	}
	if n.rig == nil {
		return n.lef
	}
	// om det finns två children  då hitta minsta i höger subträd
	m := n.rig
	for m.lef != nil {
		m = m.lef

	}
	n.valu = m.valu
	n.rig = remov_rec(n.rig, m.valu)
	return n
}
func (t_ *BST[T]) walk_inord(f func(T)) {
	walk_rec[T](t_.r, f)

}

// in this function walk in BST alltså går genom trädett i sorted ordning också den ska anropa en function
func walk_rec[T Ord](n *Nod[T], f func(T)) {
	if n == nil {
		return
	}
	walk_rec(n.lef, f)
	f(n.valu)
	walk_rec(n.rig, f)
}

// For Test the code

func main() {
	var tre BST[int]
	tre.Add(6)
	tre.Add(9)
	tre.Add(10)
	tre.Add(0)
	tre.Add(1)
	tre.Add(3)
	fmt.Println("The sorted traversal: ")
	tre.walk_inord(func(v_ int) {
		fmt.Print(v_, " ")
	})

	fmt.Println()
	fmt.Println("Find a special value:", tre.Find(3))
	fmt.Println("Find a another special value:", tre.Find(10))
	tre.remove(6)
	fmt.Println("Ater removd one value : ")
	tre.walk_inord(func(v_ int) {
		fmt.Println(v_, " ")
	})
	fmt.Println()

}
