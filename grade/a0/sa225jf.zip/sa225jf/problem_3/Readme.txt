Problem 3 handel  about generic BST tree :
-------------------------------------------

This program implements a binary generic search tree (BST) with Go language.
The BST support adding, finding and deleting values.
It also support traversing the tree and applying a function to each node using sequential travesal.

The tree is implemented using structure and methods , and generic elements are used to store different data types such as integers and strings.


Now I would also talk about how this program works:
---------------------------------------------------

In simpely :
each value is stored in a node.

values smaller than the current node go to the lef subtree, while values greater than current node go to the right subtree.

Also: 
As I explained above, the tree support many jobs:
this add , with another world insert a value
also find, thats means check if a special value exists
remove , which can delete a value
Moreover walk_inord , traverse the tree in sorted order and apply a function


How can run this program:
--------------------------
yes , just wirte so in terminal:"go run Bst.go"


Example about output:
---------------------

The sorted traversal: 
0 1 3 6 9 10 
Find a special value : true
Find a another special value: true
Ater removd one value : 
0  
1  
3  
9  
10  

Go concepts which used in this program:
---------------------------------------

Structs , Methods, Generics, Recurion, Pointers, If/else conditions, also functions as parameters(for tree traversal)

Sources:
---------
I used the offcial Go documentation and 
the Go by Example program "https://gobyexample.com/" to understand the structures, methods, iterations, and general types.

I also used materials from the course lectures to build the solution "https://moodle.lnu.se/pluginfile.php/10553085/mod_resource/content/2/lecture_1_intro_to_go.pdf".
