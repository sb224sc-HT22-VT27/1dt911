The sources which used as help for i can los poblem 1:
------------------------------------------------------

I used the official Go documentation and Go by Example"https://moodle.lnu.se/mod/url/view.php?id=5010362" for understanding the basic concepts such as slices, loops, and generating random numbers.
I also used material from the course lectuers "https://moodle.lnu.se/mod/resource/view.php?id=5004843" to structure the solution.


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Problem Description:
---------------------
The problem 1  handle about simulate rolling two dice 10000 times and counts the frequency of each possible sum(from 2 to 12) occurs.

How to run the program:
-----------------------
For run the program write in the terminal "go run two_dice.go"

Go concept which used:
-----------------------
In this program I used  from Go concept :
for loop
slices
random numbers using rand/v2
printing with fmt.Println

exampel output:
---------------
The Sum is :  2 happened 291 times
