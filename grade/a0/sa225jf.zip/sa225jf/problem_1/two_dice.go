package main

import (
	"fmt"
	"math/rand/v2"
)

/*
Good.
See comments below.
// Petter
*/

// This cast two dice from 1 to 6
func main() {
	f := make([]int, 12+1)  // COMMENT: A suggestion is to make a slice of size 11, then
							// use s - 2 as a index when incrementing frequency (slice) elements.
							// For instance, if you roll the dice and the sum is 2, then 2 would correspond to index 0
							// since s - 2 = 2 - 2 = 0
	n := 10000
	for i := 0; i < n; i++ {
		d_1 := rand.IntN(6) + 1
		d_2 := rand.IntN(6) + 1
		s := d_1 + d_2
		f[s]++
	}
	for s_ := 2; s_ <= 12; s_++ {
		fmt.Println("The Sum is : ", s_, "happened", f[s_], "times")
	}

}
