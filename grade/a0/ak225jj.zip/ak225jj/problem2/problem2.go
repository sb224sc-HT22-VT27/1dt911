package main

import (
	"fmt"
	"math/rand"
)

/*
Good.
See further comments below.
// Petter
*/

func main() {
	var outOfBounds int = 10
	steps := 1000
	coords := [2]int{0, 0}
	for i := 0; i < steps; i++ {
		coords = makeStep(coords) // COMMENT: Use pointer instead. That way, you don't need to
		                          // create a new list in your makeStep
		if coords[0] == outOfBounds || coords[0] == -outOfBounds {
			fmt.Printf("You got out, you took %d steps", i)
			break
		} else if coords[1] == outOfBounds || coords[1] == -outOfBounds {
			fmt.Printf("You got out you took %d steps", i)
			break
		}
	}
	fmt.Println(coords)
}

func makeStep(coords [2]int) [2]int {

	direction := rand.Intn(4) + 1

	// clockwise direction
	if direction == 1 {
		coords[0]++
		// up
	} else if direction == 2 {
		// right
		coords[1]++
	} else if direction == 3 {
		// down
		coords[0]--
	} else {
		// left
		coords[1]--
	}
	return coords
}
