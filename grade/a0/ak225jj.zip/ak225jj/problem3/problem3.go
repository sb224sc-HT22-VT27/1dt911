package main

import (
	"cmp"
	"fmt"
)

/*
ok.

Minor comments:
- Would prefer a BST type that stores the root node. For instance:
type BST struct {
    root *Node
}

- Appreciate the generic tree.
- See further comments below.

//
Petter
*/

type Node[T cmp.Ordered] struct {
	Key      T
	Left     *Node[T]
	Right    *Node[T]
	HasValue bool // Can be removed if the implementation is revised.
}

func main() {
	var root *Node[int] = &Node[int]{}
	siffror := []int{42, 7, 15, 3, 89, 27, 56, 10, 64, 31, 31}

	for _, n := range siffror {
		root.insert(n)
	}
	root.walker()
	fmt.Println()

	root.Remove(31)
	root.walker()

}

// insert node to tree
func (n *Node[T]) insert(k T) {
	if !n.HasValue {
		n.Key = k
		n.HasValue = true
	}

	if n.Key < k {
		//move right
		if n.Right == nil {
			n.Right = &Node[T]{Key: k, HasValue: true}
		} else {
			n.Right.insert(k)
		}
	} else if n.Key > k {
		// move left
		if n.Left == nil {
			n.Left = &Node[T]{Key: k, HasValue: true}
		} else {
			n.Left.insert(k)
		}
	} // lägg till else om det äe två likadana värden
	// COMMENT: You do not need to add an else case for equal values here since
	// a binary seach tree should contain unique values, meaning that if the n.Key == k,
	// we simply do nothing.

}

// n representerar "den aktuella noden i trädet" som vi just nu undersöker eller ändrar
// n.Key = värdet i just den noden (t.ex. ett heltal, en sträng osv)
// k är typen av noden n.Key
func (n *Node[T]) Remove(k T) *Node[T] {
	if !n.search(k) {
		fmt.Println("The node does not excist")
		return n
	}

	if n.Key > k {
		n.Left = n.Left.Remove(k)
	} else if n.Key < k {
		n.Right = n.Right.Remove(k)
	} else {
		if n.Left == nil {
			return n.Right
		} else if n.Right == nil {
			return n.Left
		}

		min := findMin(n)
		n.Key = min.Key
		n.Right = n.Right.Remove(min.Key)
	}
	return n
}

func findMin[T cmp.Ordered](n *Node[T]) *Node[T] {
	cur := n
	for cur.Left != nil {
		cur = cur.Left
	}
	return cur
}

func (n *Node[T]) search(k T) bool {
	if n == nil {
		return false
	}
	if n.Key < k {
		return n.Right.search(k)
	} else if n.Key > k {
		return n.Left.search(k)
	}
	return true
}

func (n *Node[T]) toString() {
	fmt.Print(n.Key, " ")
	if n.Left != nil {
		n.Left.toString()
	}
	if n.Right != nil {
		n.Right.toString()
	}
}

// ADDED METHOD
// Walks and prints the tree in a depth-first, left-to-right manner
func (n *Node[T]) walker() {
	if n.Left != nil {
		n.Left.walker()
	}
	fmt.Print(n.Key, " ")
	if n.Right != nil {
		n.Right.walker()
	}
}

/*
* 															Node: Val, 2 ;
		Left, Node: (Val, 1 ; ) ; 														Right, Node: (Val, 3 ; )
Left, Node: Val, nil ; Right, Node: Val, nil ;									Left, Node: Val, nil ; Right, Node: Val, nil ;
*/
