package main

import (
    "fmt"
    "math/rand"
)


/*
Good! 
See further comments below.
// Petter
*/
func main() {
	count := make([]int, 11) // index 0 och 1 kommer aldrig användas men det kommer 2-12  
							 // COMMENT: Index 0 and 1 is certainly used in 'count'. Your index (die1+die2)-2 
							 // will be 0 or 1 if the sum die1+die2 evaluates to 2 or 3 respectively.
	for i := 0; i < 10_000; i++ {
        die1 := rand.Intn(6) + 1 // 1–6
        die2 := rand.Intn(6) + 1 // 1–6
		count[(die1+die2)-2]++
    }
	fmt.Println(count)

	for i := range count{
		fmt.Printf("Number: %d frequency: %d\n",i+2 ,count[i])
	}

}

