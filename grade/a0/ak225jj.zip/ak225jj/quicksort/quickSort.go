package main

import (
	"fmt"
	"math/rand"
)

/*
Could be better.
Quicksort should only use one list, i.e., the list subject for sorting that is
passed as an argument in the QuickSort method. Your QuickSort method creates
two extra lists as helpers for the sorting process, making the method memory
intensive compared to using indices. My suggesion is to use indices instead.

// Petter
*/
func main() {
	var s []int

	elements := 100_000
	for range 10 {
		s = append(s, rand.Intn(elements))
	}
	fmt.Println(s)
	sortedS := quick(s)
	fmt.Println(sortedS)
	fmt.Println("Is sorted:", isSorted(sortedS))

	// COMMENT: Testing your QuickSort implementation.
	experiments := 20
	for i := 0; i < experiments; i++ {
		lst := make([]int, elements)
		for i := 0; i < elements; i++ {
			e := rand.Intn(elements)
			lst[i] = e
		}
		sortedS = quick(lst)
		fmt.Println("Is sorted:", isSorted(sortedS)) // OK
	}


}

func quick(s []int) []int {

	if len(s) < 2 {
		return s
	}

	pivot := mot(s)
	var l, m, r []int

	for _, num := range s {
		if num < pivot {
			l = append(l, num)
		} else if num == pivot {
			m = append(m, num)
		} else {
			r = append(r, num)
		}
	}
	return append(append(quick(l), m...), quick(r)...)
}

func mot(s []int) int {
	left := s[0]
	middle := s[len(s)/2]
	right := s[len(s)-1]

	// left > middle
	if left > middle {
		left, middle = middle, left
	}
	// middle > right
	if middle > right {
		middle, _ = right, middle
	}
	// left > middle
	if left > middle {
		_, middle = middle, left
	}
	return middle
}


// ADDED METHOD
// checks if a list is sorted
func isSorted(lst []int) bool {
	size := len(lst)
	for i := 0; i < size - 1; i++ {
		if lst[i] > lst[i + 1] {
			return false
		}
	}
	return true
}