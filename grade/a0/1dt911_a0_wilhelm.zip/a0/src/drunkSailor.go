package src

import (
	"fmt"
	"math/rand"
)

func getNewPosition(currentPosition [2]int) [2]int {
	step := rand.Intn(2) + 1 // step can be either 1 or 2 a 1 = -1 and 2 = +1
	direction := rand.Intn(2) // direction can be either 0 = x or 1 = y

	// convert step to either -1 or +1
	step = 1 + (step-1)*-2

	if direction == 0 {
		return [2]int{currentPosition[0] + step, currentPosition[1]}
	}
	return [2]int{currentPosition[0], currentPosition[1] + step}
}

func DrunkSailor(k int, sailors int) {

	fmt.Println("\nDrunken sailor")

	var lowK int = -k
	var highK int = k
	
	var inSideX bool
	var inSideY bool
	
	var stepsTaken int = 0
	totalSteps := 0
	for range sailors {
		currentPosition := [2]int{0, 0} // starting at origin
		inSideX = true // reset
		inSideY = true // reset
		for inSideX && inSideY {
			currentPosition = getNewPosition(currentPosition)
			
			inSideX = currentPosition[0] > lowK && currentPosition[0] < highK
			inSideY = currentPosition[1] > lowK && currentPosition[1] < highK

			stepsTaken++
			totalSteps++
		}


		stepsTaken = 0
	}
	average := totalSteps / sailors
	fmt.Printf("A total of %d sailors feel they took and average of %d steps before they feel overboard\n", sailors, average)
	fmt.Println("ARRGH that is to bad")

}
