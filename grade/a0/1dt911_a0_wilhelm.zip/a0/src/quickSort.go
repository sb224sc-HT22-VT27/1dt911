package src


func QuickSort(arr []int) []int {
	
	if len(arr) < 2 {
		return arr
	}
	
	left, right := 0, len(arr)-1
	pivotIndex := len(arr) / 2
	
	arr[pivotIndex], arr[right] = arr[right], arr[pivotIndex]
	for i := range arr {
		if arr[i] < arr[right] {
			arr[left], arr[i] = arr[i], arr[left]
			left++
		}
	}
	
	arr[left], arr[right] = arr[right], arr[left]
	sortedLeft := QuickSort(arr[:left])
	sortedRight := QuickSort(arr[left+1:])
	result := append(sortedLeft, arr[left])
	result = append(result, sortedRight...)

	return result
}