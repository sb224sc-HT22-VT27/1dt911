package src

import "fmt"
import "math/rand"

func createList(n int) []int {
	list := make([]int, n)
	for i := 0; i < n; i++ {
		a := rand.Intn(6) + 1
		b := rand.Intn(6) + 1

		c := a + b
		list[i] = c
	}

	return list
}

func RandomNumbers(n int) {
	fmt.Println("Generating random numbers and counting frequencies...")
	list := createList(10000)

	// freq of each number
	freq := make([]int, n)
	for i := range list {
		num := list[i]
		freq[num] += 1
	}

	for i := 2; i <= 12; i++ {
		fmt.Printf("Number %d: %d times\n", i, freq[i])
	}
	

}