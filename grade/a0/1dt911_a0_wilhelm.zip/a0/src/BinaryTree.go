package src

import (
	"fmt"
	"cmp"
)

/*
This implementation of bst is based on my bst which i wrote in python 1 year ago.
*/

type Node[T cmp.Ordered] struct{
	value T
	left *Node[T]
	right *Node[T]
}

type BinaryTree[T cmp.Ordered] struct{
	root *Node[T]
}


func addNode[T cmp.Ordered](tree *BinaryTree[T], new *Node[T]) {
	if tree.root == nil {
		tree.root = new
	} else {
		addNodeToBST(&tree.root, new)
	}
}
func addNodeToBST[T cmp.Ordered](node **Node[T], new *Node[T]) {
	if *node == nil {
		*node = new
		return
	} else if new.value < (*node).value {
		addNodeToBST(&(*node).left, new)
	} else {
		addNodeToBST(&(*node).right, new)
	}
}

func search[T cmp.Ordered](tree *BinaryTree[T], value T) bool {
	return searchNode(tree.root, value)
}

func searchNode[T cmp.Ordered](node *Node[T], value T) bool {
	if node == nil {
		return false // not found
	}

	if (value == node.value){
		return true // found it
	} else if (value > node.value){
		return searchNode(node.right, value)
	} else if (value < node.value){
		return searchNode(node.left, value)
	}
	return false
}


func removeNode[T cmp.Ordered](tree *BinaryTree[T], value T) {
	remove(value, &tree.root)
}

func remove[T cmp.Ordered](value T, node **Node[T]) {
	if *node == nil {
		return // not found
	}
	
	if value < (*node).value {
		remove(value, &(*node).left)
	} else if value > (*node).value {
		remove(value, &(*node).right)
	} else {
		// found the node to remove
		if (*node).left == nil && (*node).right == nil {
			*node = nil // no children aka a leaf
		} else if (*node).left == nil {
			*node = (*node).right // one child (right)
		} else if (*node).right == nil {
			*node = (*node).left // one child (left)
		} else {
			successor := (*node).right
			for successor.left != nil {
				successor = successor.left
			}
			(*node).value = successor.value
			remove(successor.value, &(*node).right) // remove the successor
		} 
	}
}

func lrBSTTraversal[T cmp.Ordered](tree *BinaryTree[T]){
	lrTraversal(tree.root)
}

func rlBSTTraversal[T cmp.Ordered](tree *BinaryTree[T]){
	rlTraversal(tree.root)
}

func lrTraversal[T cmp.Ordered](node *Node[T]){
	if node == nil {
		return;
	}
	lrTraversal(node.left)
	fmt.Println(node.value)
	lrTraversal(node.right)
}

func rlTraversal[T cmp.Ordered](node *Node[T]){
	if node == nil {
		return;
	}
	rlTraversal(node.right)
	fmt.Println(node.value)
	rlTraversal(node.left)
}

func BST(){
	fmt.Println("\nBinary tree search")

	var root BinaryTree[int]
	addNode(&root, &Node[int]{value:5})
	addNode(&root, &Node[int]{value:3})
	addNode(&root, &Node[int]{value:7})
	addNode(&root, &Node[int]{value:4})
	addNode(&root, &Node[int]{value:6})
	addNode(&root, &Node[int]{value:8})

	fmt.Println("Found 4:", search(&root, 4))
	fmt.Println("Found 5:", search(&root, 5))
	fmt.Println("Found 6:", search(&root, 6))
	fmt.Println("Found 15:", search(&root, 15))
	fmt.Println("Found 10:", search(&root, 10))

	fmt.Println("In order traversal:")
	lrBSTTraversal(&root)

	fmt.Println("Reverse in order traversal:")
	rlBSTTraversal(&root)

	fmt.Println("Removing 7")
	removeNode(&root, 7)

	fmt.Println("In order traversal after removal:")
	lrBSTTraversal(&root)

}