package main

import (
	"a0/src"
	"fmt"
)

func main(){
	src.RandomNumbers(10000)
	src.DrunkSailor(3, 1000)
	src.BST()
	
	fmt.Println("\nQuick sort easy implementation")
	unsorted := []int{3, 6, 8, 10, 1, 2, 1}
	fmt.Println(unsorted)
	sortedArray := src.QuickSort(unsorted)
	fmt.Println(sortedArray)
}