package tree

import (
	"cmp"
)

type Tree[Type cmp.Ordered] struct {
	startNode *Node[Type]
}

func (tree *Tree[Type]) Add(value Type, function func()) {
	node := &Node[Type]{value: value, function: function}
	if tree.startNode == nil {
		tree.startNode = node
	} else {
		tree.startNode.Add(node)
	}
}

func (tree Tree[Type]) DFS() []Type {
	values := make([]Type, 0, 100)
	tree.startNode.DFS(&values)
	return values
}

func (tree Tree[Type]) Find(value Type) *Node[Type] {
	prevNode := tree.startNode
	nextNode := prevNode
	for node := nextNode; node != nil; node = nextNode {
		prevNode = nextNode
		if cmp.Compare(value, node.value) <= 0 {
			nextNode = node.left
		} else {
			nextNode = node.right
		}
	}
	return prevNode
}
