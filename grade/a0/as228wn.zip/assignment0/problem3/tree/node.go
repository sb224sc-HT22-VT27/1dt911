package tree

import "cmp"

type Node[Type cmp.Ordered] struct {
	value    Type
	function func()
	left     *Node[Type]
	right    *Node[Type]
}

func (node *Node[Type]) Add(nextNode *Node[Type]) {
	if cmp.Compare(nextNode.value, node.value) <= 0 {
		if node.left == nil {
			node.left = nextNode
		} else {
			node.left.Add(nextNode)
		}
	} else {
		if node.right == nil {
			node.right = nextNode
		} else {
			node.right.Add(nextNode)
		}
	}
}

func (node *Node[Type]) DFS(values *[]Type) {
	if node.left != nil {
		node.left.DFS(values)
	}
	*values = append(*values, node.value)
	if node.right != nil {
		node.right.DFS(values)
	}
}

func (node Node[Type]) RunFunc() {
	node.function()
}

func (node Node[Type]) GetValue() Type {
	return node.value
}
