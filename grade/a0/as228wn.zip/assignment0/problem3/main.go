package main

import (
	"fmt"

	"main.go/tree"
)

func main() {
	tree := tree.Tree[int]{}

	values := []int{10, 8, 7, 3, 1, 2, 20, 12, 15, 6, 16, 4, 19, 18, 5, 14, 13}

	f := func() {
		fmt.Println("Hej")
	}

	for _, value := range values {
		tree.Add(value, f)
	}

	fmt.Println(tree.DFS())

	node := tree.Find(20)

	if node != nil {
		node.RunFunc()
	} else {
		fmt.Println("Node not found")
	}

}
