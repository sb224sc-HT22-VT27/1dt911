package main

import (
	"fmt"
	"math/rand"
)

type position struct {
	x int
	y int
}

func step(direction string, pos position) position {
	switch direction {
	case "right":
		pos.x++
	case "left":
		pos.x--
	case "up":
		pos.y++
	case "down":
		pos.y--
	default:
	}
	return pos
}

func randomDirection() string {
	switch rand.Intn(4) {
	case 0:
		return "right"
	case 1:
		return "left"
	case 2:
		return "up"
	case 3:
		return "down"
	default:
		return ""
	}
}

func main() {
	pos := position{0, 0}
	k := 5
	path := make([]position, 1)

	for true {
		pos = step(randomDirection(), pos)
		if pos.x > k || pos.x < -k || pos.y > k || pos.y < -k {
			break
		}
		path = append(path, pos)
	}

	fmt.Println(path)
}
