package quicksort

import (
	"cmp"
)

func Quicksort[T cmp.Ordered](list []T) []T {
	length := len(list)
	if length > 1 {
		pivot := list[0]
		left := make([]T, 0, length/2)
		right := make([]T, 0, length/2)

		for _, value := range list[1:] {
			if value <= pivot {
				left = append(left, value)
			} else {
				right = append(right, value)
			}
		}
		return append(append(Quicksort(left), pivot), Quicksort(right)...)
	}
	return list
}
