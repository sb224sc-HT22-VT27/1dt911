package quicksort

import "math/rand"

func GenerateIntList(size int) []int {
	list := make([]int, size)
	for i := range size {
		list[i] = i + 1
	}

	for i, value := range list {
		r := rand.Intn(size)
		list[i] = list[r]
		list[r] = value
	}
	return list
}
