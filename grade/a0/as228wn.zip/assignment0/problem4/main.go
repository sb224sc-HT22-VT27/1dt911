package main

import (
	"fmt"

	"main.go/quicksort"
)

func main() {
	list := quicksort.GenerateIntList(20)
	fmt.Println(list)

	list = quicksort.Quicksort(list)
	fmt.Println(list)
}
