package main

import (
	"fmt"
	"math/rand/v2"
)

func rollDice(size int) int {
	result := rand.IntN(size) + 1

	return result
}

func main() {
	var results [11]int

	for range 10000 {
		results[rollDice(6)+rollDice(6)-2]++
	}

	fmt.Println(results)
}
