package greetings

import "fmt"

// Hello returnerar en greeting för the named person.
func Hello(name string) string {
	message := fmt.Sprintf("Hi, %v. Welcome!", name)
	return message
}
