package inductor

import "math"

// Induktiv reaktans: XL = 2*pi*f*L
func CalcReactance(f, l float64) float64 {
	return 2 * math.Pi * f * l
}

func CalcInductance(xl, f float64) float64 {
	return xl / (2 * math.Pi * f)
}

func CalcFrequency(xl, l float64) float64 {
	return xl / (2 * math.Pi * l)
}
