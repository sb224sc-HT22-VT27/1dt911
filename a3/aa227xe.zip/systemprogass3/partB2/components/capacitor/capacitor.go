package capacitor

// Q = C * V
func CalcCharge(c, v float64) float64 {
	return c * v
}

func CalcCapacitance(q, v float64) float64 {
	return q / v
}

func CalcVoltage(q, c float64) float64 {
	return q / c
}
