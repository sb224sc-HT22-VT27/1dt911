package resistor

import "testing"

func TestCalcPower(t *testing.T) {
	got := CalcPower(10, 2) // svRET  e 20W
	if got != 20 {
		t.Fatalf("svaret 20, got %v", got)
	}
}
