package resistor

import "math"

// U = I * R
func CalcVoltage(i, r float64) float64 {
	return i * r
}

func CalcCurrent(u, r float64) float64 {
	return u / r
}

func CalcResistance(u, i float64) float64 {
	return u / i
}

// P = U * I
func CalcPower(u, i float64) float64 {
	return u * i
}

// extr P = I^2 * R (ksk nice)
func CalcPowerFromIR(i, r float64) float64 {
	return math.Pow(i, 2) * r
}
