package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"systemprogass3/partB2/components/capacitor"
	"systemprogass3/partB2/components/inductor"
	"systemprogass3/partB2/components/resistor"
)

const saveFile = "partB2_last_session.txt"

func main() {
	// 1) bara för o visa förra sessionen om filen finns
	showPreviousSession()

	in := bufio.NewReader(os.Stdin)

	// 2) bygger upp 3 komp
	var summaries []string
	for i := 1; i <= 3; i++ {
		fmt.Println("--------------------------------------------------")
		fmt.Printf("Komponent %d av 3\n", i)

		typ := readChoice(in, "Välj komponent (1=resistor, 2=capacitor, 3=inductor): ", []string{"1", "2", "3"})
		switch typ {
		case "1":
			summaries = append(summaries, handleResistor(in, i))
		case "2":
			summaries = append(summaries, handleCapacitor(in, i))
		case "3":
			summaries = append(summaries, handleInductor(in, i))
		}
	}

	// 3) här så sparas det när användaren väljer att avsluta
	fmt.Println("--------------------------------------------------")
	quit := readChoice(in, "Skriv 'q' för att avsluta och spara sammanfattning: ", []string{"q", "Q"})
	if quit == "q" || quit == "Q" {
		if err := saveSummary(summaries); err != nil {
			fmt.Println("Kunde inte spara fil:", err)
			return
		}
		fmt.Println("Sparat! (", saveFile, ")")
	}
}

func showPreviousSession() {
	data, err := os.ReadFile(saveFile)
	if err != nil {
		// filen finns inte första gången, nemas problemas
		return
	}
	fmt.Println("=== Förra sessionen ===")
	fmt.Println(string(data))
	fmt.Println("=======================")
}

func saveSummary(lines []string) error {
	content := strings.Join(lines, "\n")
	return os.WriteFile(saveFile, []byte(content), 0644)
}

func handleResistor(in *bufio.Reader, idx int) string {
	fmt.Println("Resistor: välj vad du vill räkna ut")
	choice := readChoice(in, "1=U (spänning), 2=I (ström), 3=R (resistans), 4=P (effekt via U*I): ", []string{"1", "2", "3", "4"})

	switch choice {
	case "1":
		i := readFloat(in, "Ange I (A): ")
		r := readFloat(in, "Ange R (ohm): ")
		u := resistor.CalcVoltage(i, r)
		return fmt.Sprintf("Komponent %d: Resistor -> U = %.4f V (I=%.4f A, R=%.4f ohm)", idx, u, i, r)

	case "2":
		u := readFloat(in, "Ange U (V): ")
		r := readFloat(in, "Ange R (ohm): ")
		i := resistor.CalcCurrent(u, r)
		return fmt.Sprintf("Komponent %d: Resistor -> I = %.4f A (U=%.4f V, R=%.4f ohm)", idx, i, u, r)

	case "3":
		u := readFloat(in, "Ange U (V): ")
		i := readFloat(in, "Ange I (A): ")
		r := resistor.CalcResistance(u, i)
		return fmt.Sprintf("Komponent %d: Resistor -> R = %.4f ohm (U=%.4f V, I=%.4f A)", idx, r, u, i)

	default: // "4"
		u := readFloat(in, "Ange U (V): ")
		i := readFloat(in, "Ange I (A): ")
		p := resistor.CalcPower(u, i)
		return fmt.Sprintf("Komponent %d: Resistor -> P = %.4f W (U=%.4f V, I=%.4f A)", idx, p, u, i)
	}
}

func handleCapacitor(in *bufio.Reader, idx int) string {
	fmt.Println("Capacitor: Q = C*V")
	choice := readChoice(in, "1=Q (laddning), 2=C (kapacitans), 3=V (spänning): ", []string{"1", "2", "3"})

	switch choice {
	case "1":
		c := readFloat(in, "Ange C (F): ")
		v := readFloat(in, "Ange V (V): ")
		q := capacitor.CalcCharge(c, v)
		return fmt.Sprintf("Komponent %d: Capacitor -> Q = %.6f C (C=%.6f F, V=%.4f V)", idx, q, c, v)

	case "2":
		q := readFloat(in, "Ange Q (C): ")
		v := readFloat(in, "Ange V (V): ")
		c := capacitor.CalcCapacitance(q, v)
		return fmt.Sprintf("Komponent %d: Capacitor -> C = %.6f F (Q=%.6f C, V=%.4f V)", idx, c, q, v)

	default: // "3"
		q := readFloat(in, "Ange Q (C): ")
		c := readFloat(in, "Ange C (F): ")
		v := capacitor.CalcVoltage(q, c)
		return fmt.Sprintf("Komponent %d: Capacitor -> V = %.4f V (Q=%.6f C, C=%.6f F)", idx, v, q, c)
	}
}

func handleInductor(in *bufio.Reader, idx int) string {
	fmt.Println("Inductor: XL = 2*pi*f*L")
	choice := readChoice(in, "1=XL (reaktans), 2=L (induktans), 3=f (frekvens): ", []string{"1", "2", "3"})

	switch choice {
	case "1":
		f := readFloat(in, "Ange f (Hz): ")
		l := readFloat(in, "Ange L (H): ")
		xl := inductor.CalcReactance(f, l)
		return fmt.Sprintf("Komponent %d: Inductor -> XL = %.4f ohm (f=%.2f Hz, L=%.6f H)", idx, xl, f, l)

	case "2":
		xl := readFloat(in, "Ange XL (ohm): ")
		f := readFloat(in, "Ange f (Hz): ")
		l := inductor.CalcInductance(xl, f)
		return fmt.Sprintf("Komponent %d: Inductor -> L = %.6f H (XL=%.4f ohm, f=%.2f Hz)", idx, l, xl, f)

	default: // 3
		xl := readFloat(in, "Ange XL (ohm): ")
		l := readFloat(in, "Ange L (H): ")
		f := inductor.CalcFrequency(xl, l)
		return fmt.Sprintf("Komponent %d: Inductor -> f = %.2f Hz (XL=%.4f ohm, L=%.6f H)", idx, f, xl, l)
	}
}

func readFloat(in *bufio.Reader, prompt string) float64 {
	for {
		fmt.Print(prompt)
		var x float64
		_, err := fmt.Fscan(in, &x)
		if err == nil {
			return x
		}
		// ba rensa skräp från raden
		in.ReadString('\n')
		fmt.Println("Ogiltigt tal, försök igen.")
	}
}

func readChoice(in *bufio.Reader, prompt string, allowed []string) string {
	allowedSet := map[string]bool{}
	for _, a := range allowed {
		allowedSet[a] = true
	}

	for {
		fmt.Print(prompt)
		var s string
		fmt.Fscan(in, &s)
		if allowedSet[s] {
			return s
		}
		fmt.Println("Ogiltigt val, försök igen.")
	}
}
