System Programming Assignment 3
Go Modules and Electric Component Configurator

Overview
This project consists of three parts:

- Part A – A simple HTTP key-value server and a Go client.
- Part B.1 – Creating and using a Go module based on the official Go tutorial.
- Part B.2 – A larger program (lnu_configurator) that uses separate modules to calculate properties of electric components.

The project is written in Go and uses Go modules (go.mod).


How to run the project

Go to the root folder of the project first:

cd systemprogass3


Part A – Server and Client

Start the server:

cd server
go run .

The server runs on:
http://localhost:3000

Stop the server with:
Ctrl + C


Run the client:

Open a new terminal and write:

cd client
go run .

The client performs PUT, GET and DELETE requests and shows the results in the terminal.


Part B.1 – Create and Use a Go Module

This part follows the Go tutorial “Create a Go module”.

Structure:

partB/
  greetings/
  hello/

Run the example:

cd partB/hello
go run .

The program prints a greeting, for example:
Hi, Ali baba. Welcome!

This part demonstrates:
- How to create a Go module
- How to import a local module
- How to use go mod edit -replace


Part B.2 – lnu_configurator

This program uses several modules to calculate properties of:

- Resistor
- Capacitor
- Inductor

Structure:

partB2/
  cmd/lnu_configurator
  components/
    resistor
    capacitor
    inductor


Run the program:

From the project root:

go run ./partB2/cmd/lnu_configurator

The program:
1. Shows the previous session if a file exists.
2. Lets the user configure 3 components.
3. Calculates the selected property.
4. Saves a summary in:
   partB2_last_session.txt

When the program is started again, the saved file is shown at the beginning.


Go environment variables

To list Go environment variables, run:

go env


Reflection

In Part B.1 a new function was created instead of overloading Hello() because Go does not support function overloading. It is not possible to have multiple functions with the same name but different parameters. Therefore, different function names must be used or the function signature must be changed.




All parts run without errors hehehe.
