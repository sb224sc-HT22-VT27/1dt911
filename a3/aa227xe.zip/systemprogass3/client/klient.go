package main

import (
	"fmt"
	"io"
	"net/http"
	"strings"
)

const baseURL = "http://localhost:3000/kvs"

func put(key, value string) bool {
	url := baseURL + "/" + key

	req, err := http.NewRequest(http.MethodPut, url, strings.NewReader(value))
	if err != nil {
		return false
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()

	return resp.StatusCode == http.StatusCreated
}

func get(key string) (string, bool) {
	url := baseURL + "/" + key

	resp, err := http.Get(url)
	if err != nil {
		return "", false
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", false
	}

	body, _ := io.ReadAll(resp.Body)
	return string(body), true
}

func deleteKey(key string) bool {
	url := baseURL + "/" + key

	req, err := http.NewRequest(http.MethodDelete, url, nil)
	if err != nil {
		return false
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()

	return resp.StatusCode == http.StatusOK
}

func main() {
	fmt.Println("Testing client...")

	if !put("first", "initial") {
		fmt.Println("put first failed")
		return
	}

	val, ok := get("first")
	fmt.Println(val, ok)

	put("second", "another")
	put("third", "more")

	deleteKey("third")

	fmt.Println(get("third"))

	fmt.Println("Done.")
}
