package main

import (
	"fmt"
	"log"

	"example.com/greetings"
)

func main() {
	// Set properties of the predefined Logger
	log.SetPrefix("greetings: ")
	log.SetFlags(0) // Disable time, file, line number

	fmt.Println("Go Modules Tutorial")

	// DEL 1: Enkel hälsning
	fmt.Println("\nDEL 1: Enkel hälsning")

	message, err := greetings.Hello("Gladys")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Hälsning: %s\n\n", message)

	// DEL 2: Hantera fel
	fmt.Println("DEL 2: Hantera fel (tomt namn)")

	message, err = greetings.Hello("")
	if err != nil {
		fmt.Printf("Korrekt felhantering: %v\n\n", err)
	} else {
		fmt.Printf("Detta borde inte hända: %s\n", message)
	}

	// DEL 3: Slumpmässiga hälsningar
	fmt.Println(" DEL 3: Slumpmässiga hälsningar - Hello()")

	names := []string{"Isabella", "Bob", "Emma"}
	for i, name := range names {
		message, err := greetings.Hello(name)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Printf("  %d. %s\n", i+1, message)
	}
	fmt.Println()

	// DEL 4: Flera personer samtidigt
	fmt.Println(" DEL 4: Hälsa till flera personer - Hellos()")

	messages, err := greetings.Hellos([]string{
		"Karolina",
		"Alex",
		"Jezper",
		"Julia",
		"William",
	})
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Hälsningar till följande:")
	for name, greeting := range messages {
		fmt.Printf("    - %s: %s\n", name, greeting)
	}
}