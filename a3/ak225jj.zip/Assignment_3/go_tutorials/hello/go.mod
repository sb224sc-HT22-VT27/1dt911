module example.com/hello

go 1.22

replace example.com/greetings => ../greetings

require example.com/greetings v0.0.0
