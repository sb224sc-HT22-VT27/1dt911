package greetings

import (
	"regexp"
	"testing"
)

// TestHelloName calls greetings.Hello with a name, checking
// for a valid return value.
func TestHelloName(t *testing.T) {
	name := "Stina"
	want := regexp.MustCompile(`\b` + name + `\b`)
	msg, err := Hello(name)
	if !want.MatchString(msg) || err != nil {
		t.Fatalf(`Hello("Gladys") = %q, %v, wants match for %#q, nil`, msg, err, want)
	}
}

// TestHelloEmpty calls greetings.Hello with an empty string,
// checking for an error.
func TestHelloEmpty(t *testing.T) {
	msg, err := Hello("")
	if msg != "" || err == nil {
		t.Fatalf(`Hello("") = %q, %v, wants "", error`, msg, err)
	}
}

// TestHellos calls greetings.Hellos with multiple names
func TestHellos(t *testing.T) {
	names := []string{"Alice", "Bob", "Charlie"}
	messages, err := Hellos(names)

	if err != nil {
		t.Fatalf(`Hellos(%v) returned error: %v`, names, err)
	}

	// Check that we got a message for each name
	if len(messages) != len(names) {
		t.Fatalf(`Hellos(%v) returned %d messages, wants %d`, names, len(messages), len(names))
	}

	// Check that each name has a message
	for _, name := range names {
		if _, ok := messages[name]; !ok {
			t.Fatalf(`Hellos(%v) missing message for %q`, names, name)
		}
	}
}