module lnu_configurator

go 1.22

require (
    lnu_configurator/resistor v0.0.0
    lnu_configurator/capacitor v0.0.0
)

replace (
    lnu_configurator/resistor => ./resistor
    lnu_configurator/capacitor => ./capacitor
)