module lnu_configurator/resistor

go 1.22