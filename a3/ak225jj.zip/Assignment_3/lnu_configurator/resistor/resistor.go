package resistor

// CalcPower calculates power (P) in Watts using P = U * I
// U = voltage in Volts, I = current in Amperes
func CalcPower(U, I float64) float64 {
	return U * I
}

// CalcResistance calculates resistance (R) in Ohms using R = U / I
// U = voltage in Volts, I = current in Amperes
func CalcResistance(U, I float64) float64 {
	if I == 0 {
		return 0 // Avoid division by zero
	}
	return U / I
}

// CalcCurrent calculates current (I) in Amperes using I = U / R
// U = voltage in Volts, R = resistance in Ohms
func CalcCurrent(U, R float64) float64 {
	if R == 0 {
		return 0 // Avoid division by zero
	}
	return U / R
}

// CalcVoltage calculates voltage (U) in Volts using U = I * R
// I = current in Amperes, R = resistance in Ohms
func CalcVoltage(I, R float64) float64 {
	return I * R
}