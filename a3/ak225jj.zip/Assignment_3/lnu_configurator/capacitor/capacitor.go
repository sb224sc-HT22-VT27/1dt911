package capacitor

import "math"

// CalcCapacitance calculates capacitance (C) in Farads using C = Q / V
// Q = charge in Coulombs, V = voltage in Volts
func CalcCapacitance(Q, V float64) float64 {
	if V == 0 {
		return 0 // Avoid division by zero
	}
	return Q / V
}

// CalcCharge calculates charge (Q) in Coulombs using Q = C * V
// C = capacitance in Farads, V = voltage in Volts
func CalcCharge(C, V float64) float64 {
	return C * V
}

// CalcEnergy calculates energy (E) in Joules stored in a capacitor
// E = 0.5 * C * V^2
// C = capacitance in Farads, V = voltage in Volts
func CalcEnergy(C, V float64) float64 {
	return 0.5 * C * math.Pow(V, 2)
}

// CalcVoltage calculates voltage (V) in Volts using V = Q / C
// Q = charge in Coulombs, C = capacitance in Farads
func CalcVoltage(Q, C float64) float64 {
	if C == 0 {
		return 0 // Avoid division by zero
	}
	return Q / C
}