module lnu_configurator/capacitor

go 1.22