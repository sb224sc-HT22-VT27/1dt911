package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"lnu_configurator/resistor"
	"lnu_configurator/capacitor"
)

// Component represents a configured component
type Component struct {
	Type       string
	Inputs     map[string]float64
	Result     float64
	ResultName string
	Timestamp  time.Time
}

func main() {
	// Skapa reader för användarinput
	reader := bufio.NewReader(os.Stdin)
	configs := make([]Component, 0)

	// Läs tidigare konfiguration vid start
	loadPreviousConfig(&configs)

	fmt.Println("LNU Electronic Configurator")

	// Huvudloop - konfigurera 3 komponenter
	for len(configs) < 3 {
		fmt.Printf("\nKonfigurera komponent %d/3\n", len(configs)+1)

		// Välj komponenttyp
		compType := selectComponentType(reader)

		var comp Component
		switch compType {
		case "1":
			comp = configureResistor(reader)
		case "2":
			comp = configureCapacitor(reader)
		}

		comp.Timestamp = time.Now()
		configs = append(configs, comp)

		fmt.Printf("\n%s konfigurerad! Resultat: %s = %.2f\n",
			comp.Type, comp.ResultName, comp.Result)
	}

	// Fråga om användaren vill spara
	fmt.Print("\nSpara konfiguration till fil? (j/n): ")
	saveChoice, _ := reader.ReadString('\n')
	saveChoice = strings.TrimSpace(strings.ToLower(saveChoice))

	if saveChoice == "j" || saveChoice == "ja" {
		saveConfigToFile(configs)
		fmt.Println("Konfiguration sparad till data/config.txt")
	} else {
		fmt.Println("Konfiguration sparades INTE")
	}

	// Visa sammanfattning
	printSummary(configs)
}

// Välj komponenttyp (endast resistor eller capacitor)
func selectComponentType(reader *bufio.Reader) string {
	for {
		fmt.Println("\nVälj komponenttyp:")
		fmt.Println("  1. Resistor (motstånd)")
		fmt.Println("  2. Capacitor (kondensator)")
		fmt.Print("Val (1-2): ")

		choice, _ := reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		if choice == "1" || choice == "2" {
			return choice
		}
		fmt.Println("Ogiltigt val. Välj 1 eller 2.")
	}
}

// Konfigurera resistor
func configureResistor(reader *bufio.Reader) Component {
	fmt.Println("\nKonfigurera Resistor")

	comp := Component{
		Type:   "Resistor",
		Inputs: make(map[string]float64),
	}

	fmt.Println("Välj vad du vill beräkna:")
	fmt.Println("  1. Effekt (P) från spänning (U) och ström (I) [P = U x I]")
	fmt.Println("  2. Resistans (R) från spänning (U) och ström (I) [R = U / I]")
	fmt.Println("  3. Ström (I) från spänning (U) och resistans (R) [I = U / R]")
	fmt.Println("  4. Spänning (U) från ström (I) och resistans (R) [U = I x R]")
	fmt.Print("Val (1-4): ")

	choice, _ := reader.ReadString('\n')
	choice = strings.TrimSpace(choice)

	switch choice {
	case "1":
		U := readFloat(reader, "  Ange spänning (U) i Volt: ")
		I := readFloat(reader, "  Ange ström (I) i Ampere: ")
		comp.Inputs["U"] = U
		comp.Inputs["I"] = I
		comp.Result = resistor.CalcPower(U, I)
		comp.ResultName = "Effekt (P)"

	case "2":
		U := readFloat(reader, "  Ange spänning (U) i Volt: ")
		I := readFloat(reader, "  Ange ström (I) i Ampere: ")
		comp.Inputs["U"] = U
		comp.Inputs["I"] = I
		comp.Result = resistor.CalcResistance(U, I)
		comp.ResultName = "Resistans (R)"

	case "3":
		U := readFloat(reader, "  Ange spänning (U) i Volt: ")
		R := readFloat(reader, "  Ange resistans (R) i Ohm: ")
		comp.Inputs["U"] = U
		comp.Inputs["R"] = R
		comp.Result = resistor.CalcCurrent(U, R)
		comp.ResultName = "Ström (I)"

	case "4":
		I := readFloat(reader, "  Ange ström (I) i Ampere: ")
		R := readFloat(reader, "  Ange resistans (R) i Ohm: ")
		comp.Inputs["I"] = I
		comp.Inputs["R"] = R
		comp.Result = resistor.CalcVoltage(I, R)
		comp.ResultName = "Spänning (U)"

	default:
		fmt.Println("  Ogiltigt val, använder standard (Effekt)")
		U := readFloat(reader, "  Ange spänning (U) i Volt: ")
		I := readFloat(reader, "  Ange ström (I) i Ampere: ")
		comp.Inputs["U"] = U
		comp.Inputs["I"] = I
		comp.Result = resistor.CalcPower(U, I)
		comp.ResultName = "Effekt (P)"
	}

	return comp
}

// Konfigurera capacitor
func configureCapacitor(reader *bufio.Reader) Component {
	fmt.Println("\nKonfigurera Capacitor")

	comp := Component{
		Type:   "Capacitor",
		Inputs: make(map[string]float64),
	}

	fmt.Println("Välj vad du vill beräkna:")
	fmt.Println("  1. Kapacitans (C) från laddning (Q) och spänning (V) [C = Q / V]")
	fmt.Println("  2. Laddning (Q) från kapacitans (C) och spänning (V) [Q = C × V]")
	fmt.Println("  3. Energi (E) från kapacitans (C) och spänning (V) [E = ½ × C × V²]")
	fmt.Println("  4. Spänning (V) från laddning (Q) och kapacitans (C) [V = Q / C]")
	fmt.Print("Val (1-4): ")

	choice, _ := reader.ReadString('\n')
	choice = strings.TrimSpace(choice)

	switch choice {
	case "1":
		Q := readFloat(reader, "  Ange laddning (Q) i Coulomb: ")
		V := readFloat(reader, "  Ange spänning (V) i Volt: ")
		comp.Inputs["Q"] = Q
		comp.Inputs["V"] = V
		comp.Result = capacitor.CalcCapacitance(Q, V)
		comp.ResultName = "Kapacitans (C)"

	case "2":
		C := readFloat(reader, "  Ange kapacitans (C) i Farad: ")
		V := readFloat(reader, "  Ange spänning (V) i Volt: ")
		comp.Inputs["C"] = C
		comp.Inputs["V"] = V
		comp.Result = capacitor.CalcCharge(C, V)
		comp.ResultName = "Laddning (Q)"

	case "3":
		C := readFloat(reader, "  Ange kapacitans (C) i Farad: ")
		V := readFloat(reader, "  Ange spänning (V) i Volt: ")
		comp.Inputs["C"] = C
		comp.Inputs["V"] = V
		comp.Result = capacitor.CalcEnergy(C, V)
		comp.ResultName = "Energi (E)"

	case "4":
		Q := readFloat(reader, "  Ange laddning (Q) i Coulomb: ")
		C := readFloat(reader, "  Ange kapacitans (C) i Farad: ")
		comp.Inputs["Q"] = Q
		comp.Inputs["C"] = C
		comp.Result = capacitor.CalcVoltage(Q, C)
		comp.ResultName = "Spänning (V)"

	default:
		fmt.Println("  Ogiltigt val, använder standard (Kapacitans)")
		Q := readFloat(reader, "  Ange laddning (Q) i Coulomb: ")
		V := readFloat(reader, "  Ange spänning (V) i Volt: ")
		comp.Inputs["Q"] = Q
		comp.Inputs["V"] = V
		comp.Result = capacitor.CalcCapacitance(Q, V)
		comp.ResultName = "Kapacitans (C)"
	}

	return comp
}

// Hjälpfunktion för att läsa flyttal
func readFloat(reader *bufio.Reader, prompt string) float64 {
	for {
		fmt.Print(prompt)
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		value, err := strconv.ParseFloat(input, 64)
		if err == nil {
			return value
		}
		fmt.Println("Ogiltigt nummer. Använd siffror (t.ex. 12.5)")
	}
}

// Ladda tidigare konfiguration
func loadPreviousConfig(configs *[]Component) {
	filename := "data/config.txt"

	file, err := os.Open(filename)
	if err != nil {
		fmt.Println("Ingen tidigare konfiguration hittad.")
		return
	}
	defer file.Close()

	fmt.Println("\nTidigare sparad konfiguration:")
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		fmt.Println(scanner.Text())
	}
}

// Spara konfiguration till fil
func saveConfigToFile(configs []Component) {
	// Skapa data-mapp om den inte finns
	err := os.MkdirAll("data", os.ModePerm)
	if err != nil {
		fmt.Printf("Kunde inte skapa mapp: %v\n", err)
		return
	}

	filename := "data/config.txt"
	file, err := os.Create(filename)
	if err != nil {
		fmt.Printf("Kunde inte skapa fil: %v\n", err)
		return
	}
	defer file.Close()

	writer := bufio.NewWriter(file)

	writer.WriteString("LNU Electronic Configurator\n")
	writer.WriteString(fmt.Sprintf("Sparad: %s\n", time.Now().Format("2006-01-02 15:04:05")))
	writer.WriteString("\n")

	for i, comp := range configs {
		writer.WriteString(fmt.Sprintf("Komponent %d: %s\n", i+1, comp.Type))
		writer.WriteString("   Inparametrar:\n")
		for k, v := range comp.Inputs {
			writer.WriteString(fmt.Sprintf("     - %s = %.2f\n", k, v))
		}
		writer.WriteString(fmt.Sprintf("   Resultat: %s = %.2f\n", comp.ResultName, comp.Result))
		writer.WriteString(fmt.Sprintf("    Tid: %s\n", comp.Timestamp.Format("15:04:05")))
		writer.WriteString("\n")
	}

	writer.WriteString("\n")
	writer.Flush()
}

// Visa sammanfattning
func printSummary(configs []Component) {
	fmt.Println("\nSammanfattning ac konfiguration")

	for i, comp := range configs {
		fmt.Printf("\nKomponent %d: %s\n", i+1, comp.Type)
		fmt.Printf("   Resultat: %s = %.2f\n", comp.ResultName, comp.Result)
	}
}