package main

import (
	"fmt"
	"net/http"
)

func Main1() {

	// TEST 1 skapa en client
	client := NewKVSClient("http.//localhost:3000/kvs")

	fmt.Println("Testing Key-Value Store Clinest\n")

	fmt.Println("1. Testing Put operation ")

	status, err := client.Put("username", "Bob")
	if err != nil {
		fmt.Printf("PUT failed whit error: %v\n", err)
	} else {
		fmt.Printf("PUT returned status code: %d\n", status)

		if status == http.StatusCreated {
			fmt.Println("Key created successfully")
		}
	}

	// TEST 2 få key som precis lagrats
	fmt.Println("2. Testing GET operation")
	value, status, err := client.Get("username")

	if err != nil {
		fmt.Printf("GET failed whit error: %v\n: ", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Printf("Value retrived: %s\n", value)
		}
	}

	// TEST 3 lägger in ytterligare key-value par
	fmt.Println("3. Testing PUT for another key")
	status, err = client.Put("email", "bob@example.com")
	if err != nil {
		fmt.Println("PUT failed with error: %v", err)
	} else {
		fmt.Printf("PUT returned status code %d", status)

		if status == http.StatusCreated {
			fmt.Println("Second key created successfully")
		}
	}

	// TEST 4 ta fram andra key
	fmt.Println("4. Getting the second key")
	value, status, err = client.Get("email")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code %d", status)

		if status == http.StatusOK {
			fmt.Printf("Value retrived: %s", value)
		}
	}

	// Test 5: Try to get a non-existent key
	fmt.Println("\n5. Testing GET for non-existent key...")
	_, status, err = client.Get("nonexistent")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusNotFound {
			fmt.Println("✓ Correctly returned 404 for non-existent key")
		}
	}

	// Test 6: Delete a key
	fmt.Println("\n6. Testing DELETE operation...")
	status, err = client.Delete("email")
	if err != nil {
		fmt.Printf("DELETE failed with error: %v\n", err)
	} else {
		fmt.Printf("DELETE returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Println("✓ Key deleted successfully")
		}
	}

	// Test 7: Verify the key is deleted
	fmt.Println("\n7. Verifying deleted key is gone...")
	_, status, err = client.Get("email")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusNotFound {
			fmt.Println("✓ Correctly returned 404 for deleted key")
		}
	}

	// Test 8: Update an existing key
	fmt.Println("\n8. Testing update of existing key...")
	status, err = client.Put("username", "Robert")
	if err != nil {
		fmt.Printf("PUT failed with error: %v\n", err)
	} else {
		fmt.Printf("PUT returned status code: %d\n", status)
		// Note: Server returns 201 for creation, 200 for update
		// Your server currently always returns 201, but this might change
	}

		// Verify the update
	value, status, err = client.Get("username")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Printf("Updated value retrieved: %s\n", value)
		}
	}
	fmt.Println("All tests completed!")	
}
