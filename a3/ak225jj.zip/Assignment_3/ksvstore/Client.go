package main

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
)

type KVSClient struct {
	baseURL string
	client  *http.Client
}

func NewKVSClient(baseURL string) *KVSClient {
	return &KVSClient{
		baseURL: baseURL,
		client:  &http.Client{},
	}
}

func (c *KVSClient) Put(key, value string) (int, error) {
	url := fmt.Sprintf("%s/%s", c.baseURL, key)
	req, err := http.NewRequest("PUT", url, bytes.NewBufferString(value))
	if err != nil {
		return 0, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return 0, fmt.Errorf("failed to send request: %w", err)
	}
	defer resp.Body.Close()

	return resp.StatusCode, nil
}

func (c *KVSClient) Get(key string) (string, int, error) {
	url := fmt.Sprintf("%s/%s", c.baseURL, key)
	resp, err := http.Get(url)
	if err != nil {
		return "", 0, fmt.Errorf("failed to send request: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", resp.StatusCode, fmt.Errorf("failed to read response: %w", err)
	}

	return string(body), resp.StatusCode, nil
}

func (c *KVSClient) Delete(key string) (int, error) {
	url := fmt.Sprintf("%s/%s", c.baseURL, key)
	req, err := http.NewRequest("DELETE", url, nil)
	if err != nil {
		return 0, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return 0, fmt.Errorf("failed to send request: %w", err)
	}
	defer resp.Body.Close()

	return resp.StatusCode, nil
}


func main() { //klagar men det funkar 
	// FIXED: Changed "http.//" to "http://"
	client := NewKVSClient("http://localhost:3000/kvs")

	fmt.Println("Testing Key-Value Store Client\n")

	// Test 1: PUT operation
	fmt.Println("1. Testing PUT operation...")
	status, err := client.Put("username", "Bob")
	if err != nil {
		fmt.Printf("PUT failed with error: %v\n", err)
	} else {
		fmt.Printf("PUT returned status code: %d\n", status)
		if status == http.StatusCreated {
			fmt.Println("✓ Key created successfully")
		}
	}

	// Test 2: GET operation
	fmt.Println("\n2. Testing GET operation...")
	value, status, err := client.Get("username")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Printf("✓ Value retrieved: %s\n", value)
		}
	}

	// Test 3: PUT another key
	fmt.Println("\n3. Testing PUT for another key...")
	status, err = client.Put("email", "bob@example.com")
	if err != nil {
		fmt.Printf("PUT failed with error: %v\n", err)
	} else {
		fmt.Printf("PUT returned status code: %d\n", status)
		if status == http.StatusCreated {
			fmt.Println("✓ Second key created successfully")
		}
	}

	// Test 4: GET second key
	fmt.Println("\n4. Getting the second key...")
	value, status, err = client.Get("email")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Printf("✓ Value retrieved: %s\n", value)
		}
	}

	// Test 5: GET non-existent key
	fmt.Println("\n5. Testing GET for non-existent key...")
	_, status, err = client.Get("nonexistent")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusNotFound {
			fmt.Println("✓ Correctly returned 404 for non-existent key")
		}
	}

	// Test 6: DELETE operation
	fmt.Println("\n6. Testing DELETE operation...")
	status, err = client.Delete("email")
	if err != nil {
		fmt.Printf("DELETE failed with error: %v\n", err)
	} else {
		fmt.Printf("DELETE returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Println("✓ Key deleted successfully")
		}
	}

	// Test 7: Verify deletion
	fmt.Println("\n7. Verifying deleted key is gone...")
	_, status, err = client.Get("email")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusNotFound {
			fmt.Println("✓ Correctly returned 404 for deleted key")
		}
	}

	// Test 8: Update existing key
	fmt.Println("\n8. Testing update of existing key...")
	status, err = client.Put("username", "Robert")
	if err != nil {
		fmt.Printf("PUT failed with error: %v\n", err)
	} else {
		fmt.Printf("PUT returned status code: %d\n", status)
	}

	// Verify the update
	value, status, err = client.Get("username")
	if err != nil {
		fmt.Printf("GET failed with error: %v\n", err)
	} else {
		fmt.Printf("GET returned status code: %d\n", status)
		if status == http.StatusOK {
			fmt.Printf("✓ Updated value retrieved: %s\n", value)
		}
	}

	fmt.Println("All tests completed!")
}