# Part A

Open in your terminal in computer:
curl -X PUT http://localhost:3000/kvs/username -d "Bob"

# open you webbrowser and write:
http://localhost:3000/kvs/username

Now you should see Bob on the screen 

# Open the VS Code terminal and run:
cd ksvstore  
go run srv.go  

# Open a new terminal (both should be running simultaneously):
cd ksvstore  
go run .\Client.go  
 
If you refresh the page there should now say Robert on the screen 


# Part B

## Part B.1 – Go Tutorial

I followed Go's official tutorial on creating modules.  
The code is located in the `go_tutorials/` folder.

Open the VS Code terminal and run:

cd go_tutorials/hello  
go mod tidy   (only the first time)  

Run the hello.go program:

go run hello.go  

Run the greetings tests:

# Run tests
cd go_tutorials/greetings  
go test -v  


## Part B.2

### Resistor Module

The resistor module can calculate:

- Power (P) from voltage (U) and current (I): P = U × I  
- Resistance (R) from voltage (U) and current (I): R = U / I  
- Current (I) from voltage (U) and resistance (R): I = U / R  
- Voltage (U) from current (I) and resistance (R): U = I × R  


### Capacitor Module

The capacitor module can calculate:

- Capacitance (C) from charge (Q) and voltage (V): C = Q / V  
- Charge (Q) from capacitance (C) and voltage (V): Q = C × V  
- Energy (E) from capacitance (C) and voltage (V): E = ½ × C × V²  
- Voltage (V) from charge (Q) and capacitance (C): V = Q / C  


# Run the Program

cd lnu_configurator  

Sync modules (only the first time):

go mod tidy  

Run the program:

go run main.go  


## How the Program Works

1. At startup, the program reads the previously saved configuration from `data/config.txt` and displays it.  
2. The user configures 3 components (chooses type and calculation).  
3. For each component, the user enters the known values.  
4. The program calls the correct function in the appropriate module and displays the result.  
5. After configuring 3 components, the user is asked whether to save the configuration to a file.  
6. When the program is restarted, the saved configuration is displayed again.  



## Example Run – Saved Output

LNU Electronic Configurator
Sparad: 2026-02-13 13:17:13

Komponent 1: Capacitor
   Inparametrar:
     - Q = 12.00
     - V = 12.00
   Resultat: Kapacitans (C) = 1.00
    Tid: 13:16:55

Komponent 2: Capacitor
   Inparametrar:
     - Q = 12.00
     - V = 12.00
   Resultat: Kapacitans (C) = 1.00
    Tid: 13:17:06

Komponent 3: Capacitor
   Inparametrar:
     - Q = 2.00
     - V = 1.00
   Resultat: Kapacitans (C) = 2.00
    Tid: 13:17:11