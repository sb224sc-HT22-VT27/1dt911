# README – Go-uppgift

Detta repository innehåller lösningen på en uppgift uppdelad i tre delar: A1, B1 och B2. Varje del demonstrerar olika aspekter av Go, såsom HTTP kommunikation, Go moduler och enhetstestning.

---

## Förutsättningar

- Go version: 1.25.5  
- Operativsystem: Testat på Windows
- Python: Endast för test.py i A1 (valfritt, ej egen implementation)

---

## Mappstruktur
```
A1/
├── client.go
├── srv.go
└── test.py

B1/
├── go.work
├── greetings/
│   ├── go.mod
│   └── greetings.go
└── main/
    ├── go.mod
    └── main.go

B2/
├── go.work
├── capacitor/
│   ├── go.mod
│   ├── capacitor.go
│   └── capacitor_test.go
├── resistor/
│   ├── go.mod
│   ├── resistor.go
│   └── resistor_test.go
├── voltage/
│   ├── go.mod
│   ├── voltage.go
│   └── voltage_test.go
└── main/
    ├── go.mod
    ├── lnu_configurator.go
    └── config_summary.txt
```

---

## Del A1 – HTTP-klient

### Beskrivning
I denna del användes en given HTTP server, och uppgiften var att implementera en klient i Go. Klienten är baserad på och speglar strukturen och beteendet hos det medföljande Python-testprogrammet (test.py), som användes som inspiration.

Klienten implementerar tre funktioner:
- PUT – skickar en PUT-begäran och returnerar lyckat resultat vid HTTP 201
- GET – skickar en GET-begäran och returnerar värdet samt status
- DELETE – skickar en DELETE-begäran och returnerar status 200 vid lyckad borttagning

Klienten kommunicerar med servern via följande URL:
```go
const URL = "http://localhost:3000/kvs"
```

### Köra programmet

Servern måste startas före klienten.

#### Terminal 1 – Starta servern
```bash
cd A1
go run srv.go
```
#### Terminal 2 – Kör klienten
```bash
cd A1
go run client.go
```
### Om test.py

test.py är given av läraren och är inte en del av den egna implementationen. Det används endast som referens/inspiration och demonstrerar PUT, GET och DELETE-operationer mot servern.

---
## Del B1 – Go-moduler
### Beskrivning

Syftet med denna del var att få en förståelse för Go-moduler genom att följa den officiella guiden på go.dev. Genom att strukturera koden enligt rekommenderat arbetssätt skapades en modul (greetings) som används av ett huvudprogram.

Detta arbetssätt används eftersom Go inte stödjer funktionsöverlagring baserat på parametrar, till skillnad från vissa andra språk.

### Köra programmet
```bash
cd B1
go run ./main/main.go
```
---

## Del B2 – Moduler, workspace och enhetstester
### Beskrivning

Denna del bygger vidare på modulkonceptet från B1 och utgår från elektroniska beräkningsformler för:

- Resistor
- Capacitor
- Voltage

Efter att formlerna tagits fram skapades en modulbaserad struktur med separata Go-moduler för varje beräkningstyp samt en gemensam go.work.

Huvudprogrammet (lnu_configurator.go) presenterar en meny där användaren kan välja:

1. Resistor
2. Capacitor
3. Voltage

Efter att beräkningar utförts kan användaren:

4. Spara och avsluta
5. Avsluta utan att spara

Sparade beräkningar skrivs till fil och visas nästa gång programmet körs.

### Köra huvudprogrammet
```bash
cd B2
go run ./main/lnu_configurator.go
```

### Köra enhetstester

Samtliga beräkningsmoduler har tillhörande enhetstester som verifierar att de matematiska beräkningarna är korrekta. Gå först in i B2 och sedan in i korrelerande map som innehåller modulen som ska testas, exempel nedan.
```bash
cd B2
cd capacitor
go test
```

Vid lyckade tester returneras ok samt exekveringstid i terminalen.

## Sammanfattning

- A1 demonstrerar HTTP kommunikation via en Go klient
- B1 introducerar Go moduler basics
- B2 kombinerar moduler, workspace, filhantering och enhetstestning

Alla delar är testade med Go version 1.25.5.