package main

import (
	"fmt"
	"example.com/greetings"
)

func main() {
	a := greetings.Hello("Erik")
	fmt.Println(a)
}