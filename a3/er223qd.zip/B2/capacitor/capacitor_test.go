package capacitor

import "testing"

func TestCalcResistance (t *testing.T) {

	charge := 10.0
	voltage := 2.0

	expected :=5.0
	result := CalcCapacitance(charge, voltage)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}

	



}