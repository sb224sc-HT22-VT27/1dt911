package voltage

import "testing"

func TestCalcVoltage(t *testing.T) {
	voltage := 10.0
	current := 2.0

	expected := 20.0
	result := CalcVoltage(voltage, current)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}
}
