package resistor

import "testing"

func TestCalcResistance(t *testing.T) {
	voltage := 10.0
	current := 2.0

	expected := 5.0
	result := CalcResistance(voltage, current)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}
}
