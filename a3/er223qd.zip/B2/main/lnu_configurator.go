package main

import (
	"fmt"
	"example.com/resistor"
	"example.com/capacitor"
	"example.com/voltage"
	"os"
)

func SaveConfiguration(current float64, capacitance float64, voltageValue float64) error {
	file, err := os.Create("config_summary.txt")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return err
	}
	defer file.Close()
	
	fmt.Fprintln(file, "Calculated Resistance (Ohms):", resistance)
	fmt.Fprintln(file, "Calculated Capacitance (Farads):", capacitance)
	fmt.Fprintln(file, "Calculated Voltage (Volts):", voltageValue)

	return nil
}

func main() {
	var choice int

	var (
		resistance float64
		capacitance float64
		voltageValue float64

		resistanceset bool
		capacitanceset bool
		voltageset bool
	)

	fileContent, err := os.ReadFile("config_summary.txt")
	if err != nil {
		fmt.Println("Error reading file:", err)
	} else {
		fmt.Println("Previous session configuration:")
		fmt.Println(string(fileContent))
	}

	for {
		fmt.Println("Select component type to configure:")
		fmt.Println("1. Resistor")
		fmt.Println("2. Capacitor")
		fmt.Println("3. Voltage")
		fmt.Println("4. Save and Exit")
		fmt.Println("5. Exit without saving")
		fmt.Scan(&choice)
		switch choice {
		case 1:
			var r, v float64
			fmt.Println("Enter resistance (Ohms):")
			fmt.Scan(&r)
			fmt.Println("Enter voltage (Volts):")
			fmt.Scan(&v)
			resistance = resistor.CalcResistance(r, v)
			fmt.Printf("Calculated resistance: %.2f Ohms\n", resistance)
			resistanceset = true
		case 2:
			var c, v float64
			fmt.Println("Enter charge (Coulombs):")
			fmt.Scan(&c)
			fmt.Println("Enter voltage (Volts):")
			fmt.Scan(&v)
			capacitance = capacitor.CalcCapacitance(c, v)
			fmt.Printf("Calculated capacitance: %.2f Farads\n", capacitance)
			capacitanceset = true
		case 3:
			var r, i float64
			fmt.Println("Enter resistance (Ohms):")
			fmt.Scan(&r)
			fmt.Println("Enter current (Amperes):")
			fmt.Scan(&i)
			voltageValue = voltage.CalcVoltage(r, i)
			fmt.Printf("Calculated voltage: %.2f Volts\n", voltageValue)
			voltageset = true
		case 4:
			fmt.Println("You must configure at least all components before exiting.")
			fmt.Println("You have changed:")
			if currentset {
				fmt.Println("Current calculated.")
			}
			if capacitanceset {
				fmt.Println("Capacitance calculated.")
			}
			if voltageset {
				fmt.Println("Voltage calculated.")
			}
			if currentset && capacitanceset && voltageset {
				fmt.Println("All components configured. Saving and exiting.")
				err := SaveConfiguration(current, capacitance, voltageValue)
				if err != nil {
					fmt.Println("Error saving configuration:", err)
				}
				return
			}
		case 5:
			fmt.Println("Exiting without saving.")
			return
		default:
			fmt.Println("Invalid choice, please select 1 or 2.")
		}
	}
}