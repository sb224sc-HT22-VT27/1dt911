package main

import (
	"io"
	"net/http"
	"strings"
)

const URL = "http://localhost:3000/kvs"

func Get(key string) (string, bool) {
	resp, err := http.Get(URL + "/" + key)
	if err != nil {
		return "", false
	}	
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", false
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", false
	}
	return string(body), true
}

func Put(key string, val string) bool {
	req, err := http.NewRequest(http.MethodPut, URL+"/"+key, strings.NewReader(val))
	if err != nil {
		return false
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == http.StatusCreated
}

func Delete(key string) bool {
	req, err := http.NewRequest(http.MethodDelete, URL+"/"+key, nil)
	if err != nil {
		return false
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == http.StatusOK
}


func main() {
	if !Put("first", "initial") {
		panic("put first failed")
	} else {
		println("Put first succeeded")
	}
	val, ok := Get("first")
	if !ok || val != "initial" {
		panic("get first failed")
	} else {
		println("Get first succeeded:", val)
	}
	if !Put("second", "another") {
		panic("put second failed")
	} else {
		println("Put second succeeded")
	}
	if !Put("third", "more") {
		panic("put third failed")
	} else {
		println("Put third succeeded")
	}
	if !Put("fourth", "done") {
		panic("put fourth failed")
	} else {
		println("Put fourth succeeded")
	}
	_, ok = Get("fifth")
	if ok {
		panic("get fifth should fail")
	} else {
		println("Get fifth correctly failed")
	}
	if !Delete("third") {
		panic("delete failed")
	} else {
		println("Delete third succeeded")
	}
	_, ok = Get("third")
	if ok {
		panic("get third should fail")
	} else {
		println("Get third correctly failed")
	}
}