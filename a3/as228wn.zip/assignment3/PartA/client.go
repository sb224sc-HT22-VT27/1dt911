package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"net/http"
)

var url = "http://localhost:3000/kvs/"
var client = &http.Client{}

func put(key, value string) string {
	req, err := http.NewRequest("PUT", url+key, bytes.NewBuffer([]byte(value)))
	if err != nil {
		panic(err)
	}

	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}

	return resp.Status
}

func get(key string) (string, string) {
	resp, err := http.Get(url + key)
	if err != nil {
		panic(err)
	}

	defer resp.Body.Close()

	value, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}

	return string(value), resp.Status
}

func delete(key string) string {
	req, err := http.NewRequest("DELETE", url+key, nil)
	if err != nil {
		panic(err)
	}

	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}

	return resp.Status
}

func assert(result bool, msg string) {
	if !result {
		fmt.Println(msg)
	}
}

func main() {
	assert(put("first", "initial") == "201 Created", "")

	assert(put("first", "initial") == "201 Created", "put first failed")
	_, stat := get("first")
	assert(stat == "200 OK", "get first failed")

	assert(put("second", "another") == "201 Created", "put second failed")
	assert(put("third", "more") == "201 Created", "put third failed")
	assert(put("fourth", "done") == "201 Created", "put fourth failed")

	_, stat = get("fifth")
	assert(stat == "404 Not Found", "get fifth should fail")

	assert(delete("third") == "200 OK", "delete failed")

	_, stat = get("third")
	assert(stat == "404 Not Found", "get third should fail")

	put("username", "Bob")

	fmt.Println(get("username"))
}
