package capacitor

import (
	"testing"
)

func TestVoltagePositive(t *testing.T) {
	charge := 10
	capacitance := 20
	var want float64 = 0.5
	voltage := CalcVoltage(float64(charge), float64(capacitance))
	if voltage != want {
		t.Errorf("Voltage is %f, expected %f", voltage, want)
	}
}

func TestVoltageNegative(t *testing.T) {
	charge := -10
	capacitance := -20
	var want float64 = 0
	voltage := CalcVoltage(float64(charge), float64(capacitance))
	if voltage != want {
		t.Errorf("Voltage is %f, expected %f", voltage, want)
	}
}

func TestCapacitancePositive(t *testing.T) {
	charge := 10
	voltage := 20
	var want float64 = 0.5
	capacitance := CalcCapacitance(float64(charge), float64(voltage))
	if capacitance != want {
		t.Errorf("Capacitance is %f, expected %f", capacitance, want)
	}
}

func TestCapacitanceNegative(t *testing.T) {
	charge := -10
	voltage := -20
	var want float64 = -0.5
	capacitance := CalcCapacitance(float64(charge), float64(voltage))
	if capacitance != want {
		t.Errorf("Capacitance is %f, expected %f", capacitance, want)
	}
}

func TestChargePositive(t *testing.T) {
	capacitance := 20
	voltage := 10
	var want float64 = 200
	charge := CalcCharge(float64(capacitance), float64(voltage))
	if charge != want {
		t.Errorf("Charge is %f, expected %f", charge, want)
	}
}

func TestChargeNegative(t *testing.T) {
	capacitance := -20
	voltage := -10
	var want float64 = -200
	charge := CalcCharge(float64(capacitance), float64(voltage))
	if charge != want {
		t.Errorf("Charge is %f, expected %f", charge, want)
	}
}
