package capacitor

import "math"

func CalcCapacitance(charge, voltage float64) float64 {
	return charge / math.Abs(voltage)
}

func CalcVoltage(charge, capacitance float64) float64 {
	if capacitance <= 0 {
		return 0
	}
	return charge / capacitance
}

func CalcCharge(capacitance, voltage float64) float64 {
	return capacitance * math.Abs(voltage)
}
