package main

import (
	"fmt"
	"log"
	"os"

	"example.com/capacitor"
	"example.com/resistor"
)

var components = []string{"Capacitors", "Resistors"}
var compFuncs = []func() map[string]float64{cap, res}

func cap() map[string]float64 {
	var properties = map[string]float64{
		"Charge":      0,
		"Capacitance": 0,
		"Voltage":     0,
	}

	fmt.Println("Enter properties: (Leave empty for unknown)")
	for property := range properties {
		fmt.Print(property + ": ")
		var input float64
		_, err := fmt.Scanln(&input)
		if err == nil && input != 0 {
			properties[property] = input
		}
	}

	for property, value := range properties {
		if value == 0 {
			switch property {
			case "Charge":
				properties[property] = capacitor.CalcCharge(properties["Capacitance"], properties["Voltage"])
			case "Capacitance":
				properties[property] = capacitor.CalcCapacitance(properties["Charge"], properties["Voltage"])
			case "Voltage":
				properties[property] = capacitor.CalcVoltage(properties["Charge"], properties["Capacitance"])
			}
		}

	}

	return properties
}

func res() map[string]float64 {
	var properties = map[string]float64{
		"Amperage":   0,
		"Resistance": 0,
		"Voltage":    0,
		"Effect":     0,
	}

	fmt.Println("Enter properties: (Leave empty for unknown)")
	for property := range properties {
		fmt.Print(property + ": ")
		var input float64
		_, err := fmt.Scanln(&input)
		if err == nil && input != 0 {
			properties[property] = input
		}
	}

	for property, value := range properties {
		if value == 0 {
			switch property {
			case "Amperage":
				properties[property] = resistor.CalcAmperage(properties["Voltage"], properties["Resistance"])
			case "Resistance":
				properties[property] = resistor.CalcResistance(properties["Voltage"], properties["Amperage"])
			case "Voltage":
				properties[property] = resistor.CalcVoltage(properties["Amperage"], properties["Resistance"])
			case "Effect":
				properties[property] = resistor.CalcEffect(properties["Voltage"], properties["Amperage"])
			}
		}

	}

	return properties
}

func printResult() {
	result := make([]byte, 200)
	file, err := os.Open("results.txt")
	if file != nil {
		if err != nil {
			log.Panic(err)
		}
		file.Read(result)
		fmt.Println(string(result))
	}
}

func main() {
	printResult()

	var results [3]map[string]float64

	for i := range 3 {
		fmt.Println("Select a component: (integer)")
		for i, comp := range components {
			fmt.Println(i+1, comp)
		}
		var comp int
		_, err := fmt.Scan(&comp)
		if err == nil && comp <= len(compFuncs) {
			results[i] = compFuncs[comp-1]()
			fmt.Println(results[i])
		}
	}

	file, err := os.Create("results.txt")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	for i, result := range results {
		_, err := fmt.Fprintf(file, "Component %d: %v\n", i+1, result)
		if err != nil {
			log.Fatal(err)
		}
	}
}
