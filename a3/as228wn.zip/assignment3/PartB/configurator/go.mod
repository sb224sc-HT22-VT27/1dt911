module example.com/configurator

go 1.25.5

replace example.com/resistor => ../resistor

replace example.com/capacitor => ../capacitor

require (
	example.com/capacitor v0.0.0-00010101000000-000000000000
	example.com/resistor v0.0.0-00010101000000-000000000000
)
