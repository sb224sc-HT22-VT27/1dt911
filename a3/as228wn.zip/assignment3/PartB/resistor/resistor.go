package resistor

import "math"

func CalcEffect(voltage, amperage float64) float64 {
	return math.Abs(voltage) * amperage
}

func CalcAmperage(voltage, resistance float64) float64 {
	return math.Abs(voltage) / math.Abs(resistance)
}

func CalcVoltage(amperage, resistance float64) float64 {
	return amperage * resistance
}

func CalcResistance(voltage, amperage float64) float64 {
	return math.Abs(voltage) / math.Abs(amperage)
}
