package resistor

import (
	"testing"
)

func TestCalcEffectPositive(t *testing.T) {
	voltage := 10.0
	amperage := 2.0
	var want float64 = 20.0
	got := CalcEffect(voltage, amperage)
	if got != want {
		t.Errorf("CalcEffect(%f, %f) = %f, want %f", voltage, amperage, got, want)
	}
}

func TestCalcEffectNegative(t *testing.T) {
	voltage := -10.0
	amperage := 2.0
	var want float64 = 20.0
	got := CalcEffect(voltage, amperage)
	if got != want {
		t.Errorf("CalcEffect(%f, %f) = %f, want %f", voltage, amperage, got, want)
	}
}

func TestCalcAmperagePositive(t *testing.T) {
	voltage := 10.0
	resistance := 2.0
	var want float64 = 5.0
	got := CalcAmperage(voltage, resistance)
	if got != want {
		t.Errorf("CalcAmperage(%f, %f) = %f, want %f", voltage, resistance, got, want)
	}
}

func TestCalcAmperageNegative(t *testing.T) {
	voltage := -10.0
	resistance := -2.0
	var want float64 = 5.0
	got := CalcAmperage(voltage, resistance)
	if got != want {
		t.Errorf("CalcAmperage(%f, %f) = %f, want %f", voltage, resistance, got, want)
	}
}

func TestCalcVoltagePositive(t *testing.T) {
	amperage := 2.0
	resistance := 10.0
	var want float64 = 20.0
	got := CalcVoltage(amperage, resistance)
	if got != want {
		t.Errorf("CalcVoltage(%f, %f) = %f, want %f", amperage, resistance, got, want)
	}
}

func TestCalcVoltageNegative(t *testing.T) {
	amperage := -2.0
	resistance := -10.0
	var want float64 = 20.0
	got := CalcVoltage(amperage, resistance)
	if got != want {
		t.Errorf("CalcVoltage(%f, %f) = %f, want %f", amperage, resistance, got, want)
	}
}

func TestCalcResistancePositive(t *testing.T) {
	voltage := 10.0
	amperage := 2.0
	var want float64 = 5.0
	got := CalcResistance(voltage, amperage)
	if got != want {
		t.Errorf("CalcResistance(%f, %f) = %f, want %f", voltage, amperage, got, want)
	}
}

func TestCalcResistanceNegative(t *testing.T) {
	voltage := -10.0
	amperage := -2.0
	var want float64 = 5.0
	got := CalcResistance(voltage, amperage)
	if got != want {
		t.Errorf("CalcResistance(%f, %f) = %f, want %f", voltage, amperage, got, want)
	}
}
