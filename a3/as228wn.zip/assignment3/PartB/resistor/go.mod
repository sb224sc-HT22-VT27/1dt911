module example.com/resistor

go 1.25.5
