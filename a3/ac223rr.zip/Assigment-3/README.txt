To compile and run the Go programs, Go version 1.22 or newer must be installed. The installation can be verified by running go version in the terminal.

For Part A
The server must be started first. Navigate to the directory containing srv.go and run go run srv.go. This compiles and starts the HTTP server on port 3000. The terminal must remain open while the server is running. In a second terminal window, navigate to the client directory and run go run main.go. This compiles and executes the client program that sends PUT, GET, and DELETE requests to the server and displays the results.

For Part B
The modular configurator program is executed from the project root directory (Part-B\lnu_configurator). Can start the program by using go run ./cmd/lnu_configurator. Go automatically resolves and builds the modules defined in the project using the go.mod file and replace directives. Alternatively, the program can be compiled using go build ./cmd/lnu_configurator, which produces an executable file that can be run directly. The txt file will be saved in the same directory.