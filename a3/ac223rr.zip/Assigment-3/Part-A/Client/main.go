package main

import (
	"bytes" // used to turn a string into an io.Reader for the HTTP request body
	"fmt"
	"io"       // used to read the response body from the server.
	"net/http" // HTTP client/server library.
)

const URL = "http://localhost:3000/kvs" // base URL

// sends GET kvs/{key} and returns (value, true) if the key exists
func get(key string) (string, bool) {
	resp, err := http.Get(URL + "/" + key) // make a GET request to /kvs/<key>
	if err != nil {                        // if network error
		return "", false // return failure
	}
	defer resp.Body.Close() // response body gets closed to avoid resource leaks

	if resp.StatusCode == http.StatusOK { // check if server replied 200 OK
		body, _ := io.ReadAll(resp.Body) // read entire response body into bytes
		return string(body), true        // convert bytes to string and return success
	}

	return "", false // anything other than 200 means key not found or error
}

// sends PUT kvs/{key} with the value in the request body and returns true if server returns 201
func put(key string, value string) bool {
	req, err := http.NewRequest( // create a new HTTP request
		http.MethodPut,                 // use the PUT method
		URL+"/"+key,                    // target URL: /kvs/<key>
		bytes.NewBuffer([]byte(value)), // the raw value bytes
	)
	if err != nil { // If request creation fails
		return false
	}

	client := http.Client{}     // create an HTTP client
	resp, err := client.Do(req) // send the PUT request
	if err != nil {             // If network error
		return false // failure
	}
	defer resp.Body.Close() // close

	return resp.StatusCode == http.StatusCreated // success only if server returns 201
}

// sends DELETE kvs/{key} and returns true if server returns 200 OK
func deleteKey(key string) bool {
	req, err := http.NewRequest( // create a DELETE request
		http.MethodDelete, // use DELETE method
		URL+"/"+key,       // target URL: /kvs/<key>.
		nil,               // no request body needed
	)
	if err != nil { // if request creation fails
		return false // failure
	}

	client := http.Client{}     // create a client
	resp, err := client.Do(req) // send DELETE request
	if err != nil {             // network error
		return false // failure
	}
	defer resp.Body.Close() // close

	return resp.StatusCode == http.StatusOK // success only if server returns 200 OK
}

func main() {

	// set key "first" to "initial"
	if !put("first", "initial") { // call put if it returns false, something went wrong.
		panic("put first failed") // stop the program with an error message
	}

	// check it is set
	if val, ok := get("first"); !ok || val != "initial" { // get the key must be true and value must match
		panic("get first failed") // stop if not correct
	}

	// setting a few more keys
	if !put("second", "another") { // store  key
		panic("put second failed") // stop if failed
	}
	if !put("third", "more") { // store third key.
		panic("put third failed") // stop if failed
	}
	if !put("fourth", "done") { // store fourth key.
		panic("put fourth failed") // stop if failed
	}

	// get a bad key
	if _, ok := get("fifth"); ok { // try to get a key that doesn't exist
		panic("get fifth should fail") // stop because expected failure (404)
	}

	// deleting a key
	if !deleteKey("third") { // delete (third)
		panic("delete failed") // stop if failed
	}

	// try to get deleted key
	if _, ok := get("third"); ok { // third should not exist ok must be false
		panic("get third should fail") // stop if it still exists
	}

	// print(get('username'))
	put("username", "Bob")       // store username
	fmt.Println(get("username")) // Print the result (value, true/false)
}
