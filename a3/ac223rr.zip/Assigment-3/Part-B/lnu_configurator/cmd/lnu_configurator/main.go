/*
This program uses the modules by collecting user input and calling exported
calculation functions during runtime. For example, when
configuring a resistor, the program calls resistor.CalcPower(U, I) or
resistor.CalcCurrent(U, R) and prints the computed value. When
configuring a capacitor, it calls functions such as capacitor.CalcCharge(C, V) and
displays the result. The calculated results are also stored in a list and written to a
summary text file when the user exits
*/

package main

import (
	"bufio" // provides buffered I/O to read user input
	"fmt"
	"os"      // gives access to the operating system
	"strconv" // converts strings to numbers
	"strings" // building text efficiently

	// calculation modules
	"example.com/capacitor"
	"example.com/resistor"
)

// name of the file where we store the summary
const summaryFile = "previous_session.txt"

// represent one configured electronic component.
type ConfiguredComponent struct { // store so it can summarize them in a file
	Kind   string // component type
	Detail string // description of the calculation result
}

func main() {
	PreviousSession()                    // show previous summary when the program starts
	var configured []ConfiguredComponent // slice that hold up to 3 configured components
	reader := bufio.NewReader(os.Stdin)  //reader connected to input

	fmt.Println("---LNU Configurator ---")
	fmt.Println("You will configure up to 3 components.")
	fmt.Println("Choose Quit to save and exit.\n")

	// interaction loop runs until either the user has configured 3 components or the user chooses to quit early
	for len(configured) < 3 {
		fmt.Printf("Configured: %d / 3\n", len(configured))
		fmt.Println("Choose component type:")
		fmt.Println("  1) Resistor (Ohm + Power)")
		fmt.Println("  2) Capacitor (Q = C*V)")
		fmt.Println("  3) Quit")

		choice := readInt(reader, "Select (1-3): ") // read user menu choice as an integer

		// user chooses Quit to exit the loop
		if choice == 3 {
			break
		}
		// based on the choice
		switch choice {
		case 1:
			// resistor module
			comp, ok := configureResistor(reader)
			if ok {
				// store successful configurations
				configured = append(configured, comp)
			}
		case 2:
			// capacitor module
			comp, ok := configureCapacitor(reader)
			if ok {
				configured = append(configured, comp)
			}
		default:
			// any other number is invalid
			fmt.Println("Invalid choice.\n")
		}
		fmt.Println()
	}

	// when the program ends, write a summary of all configured components
	if err := writeSummary(configured); err != nil {
		fmt.Println("ERROR writing summary:", err)
	} else {
		fmt.Println("\nSaved summary to:", summaryFile)
	}
}

// reads the summary file from disk and prints it
// if the file does not exist the program continues anyway
func PreviousSession() {
	data, err := os.ReadFile(summaryFile)
	if err != nil {
		return
	}

	fmt.Println("--- Previous Session Summary ---")
	fmt.Println(string(data))
	fmt.Println("--- End Summary ---\n")
}

// resistor configs. it gathers inputs, calls resistor module, and returns result
// the resistor module is imported
// a public function is called
// user input is passed to the module
// the returned value is used in the program
func configureResistor(reader *bufio.Reader) (ConfiguredComponent, bool) {
	fmt.Println("\nResistor:")
	fmt.Println("What do you want to calculate?")
	fmt.Println("  1) Power P (W) using P = U * I")
	fmt.Println("  2) Voltage U (V) using U = I * R")
	fmt.Println("  3) Current I (A) using I = U / R")
	fmt.Println("  4) Resistance R (Ohm) using R = U / I")

	choice := readInt(reader, "Select (1-4): ")

	switch choice {

	case 1:
		// voltage and current --> calculate power
		u := readFloat(reader, "Enter voltage U (V): ")
		i := readFloat(reader, "Enter current I (A): ")
		p := resistor.CalcPower(u, i)

		detail := fmt.Sprintf(
			"Resistor: U=%.4g V, I=%.4g A -> P=%.4g W",
			u, i, p,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Resistor", detail}, true

	case 2:
		// current and resistance --> calculate voltage
		i := readFloat(reader, "Enter current I (A): ")
		r := readFloat(reader, "Enter resistance R (Ohm): ")
		u := resistor.CalcVoltage(i, r)

		detail := fmt.Sprintf(
			"Resistor: I=%.4g A, R=%.4g Ohm -> U=%.4g V",
			i, r, u,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Resistor", detail}, true

	case 3:
		// voltage and resistance --> calculate current
		u := readFloat(reader, "Enter voltage U (V): ")
		r := readFloat(reader, "Enter resistance R (Ohm): ")

		i, err := resistor.CalcCurrent(u, r)
		if err != nil {
			// division by zero
			fmt.Println("Error:", err)
			return ConfiguredComponent{}, false
		}

		detail := fmt.Sprintf(
			"Resistor: U=%.4g V, R=%.4g Ohm -> I=%.4g A",
			u, r, i,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Resistor", detail}, true

	case 4:
		// voltage and current --> calculate resistance
		u := readFloat(reader, "Enter voltage U (V): ")
		i := readFloat(reader, "Enter current I (A): ")

		r, err := resistor.CalcResistance(u, i)
		if err != nil {
			fmt.Println("Error:", err)
			return ConfiguredComponent{}, false
		}

		detail := fmt.Sprintf(
			"Resistor: U=%.4g V, I=%.4g A -> R=%.4g Ohm",
			u, i, r,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Resistor", detail}, true

	default:
		// invalid menu choice
		fmt.Println("Invalid choice.")
		return ConfiguredComponent{}, false
	}
}

// capacitor configs. same structure as resistor configs but using capacitor equations
// a different module
// a different physical formula
// reuse of shared logic across the program
func configureCapacitor(reader *bufio.Reader) (ConfiguredComponent, bool) {
	fmt.Println("\nCapacitor:")
	fmt.Println("What do you want to calculate?")
	fmt.Println("  1) Charge Q (C) using Q = C * V")
	fmt.Println("  2) Capacitance C (F) using C = Q / V")
	fmt.Println("  3) Voltage V (V) using V = Q / C")

	choice := readInt(reader, "Select (1-3): ")

	switch choice {

	case 1:
		// capacitance and voltage → calculate charge
		c := readFloat(reader, "Enter capacitance C (F): ")
		v := readFloat(reader, "Enter voltage V (V): ")
		q := capacitor.CalcCharge(c, v)

		detail := fmt.Sprintf(
			"Capacitor: C=%.4g F, V=%.4g V -> Q=%.4g C",
			c, v, q,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Capacitor", detail}, true

	case 2:
		// charge and voltage → calculate capacitance
		q := readFloat(reader, "Enter charge Q (C): ")
		v := readFloat(reader, "Enter voltage V (V): ")

		c, err := capacitor.CalcCapacitance(q, v)
		if err != nil {
			fmt.Println("Error:", err)
			return ConfiguredComponent{}, false
		}

		detail := fmt.Sprintf(
			"Capacitor: Q=%.4g C, V=%.4g V -> C=%.4g F",
			q, v, c,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Capacitor", detail}, true

	case 3:
		// charge and capacitance → calculate voltage
		q := readFloat(reader, "Enter charge Q (C): ")
		c := readFloat(reader, "Enter capacitance C (F): ")

		v, err := capacitor.CalcVoltage(q, c)
		if err != nil {
			fmt.Println("Error:", err)
			return ConfiguredComponent{}, false
		}

		detail := fmt.Sprintf(
			"Capacitor: Q=%.4g C, C=%.4g F -> V=%.4g V",
			q, c, v,
		)

		fmt.Println("Result:", detail)
		return ConfiguredComponent{"Capacitor", detail}, true

	default:
		fmt.Println("Invalid choice.")
		return ConfiguredComponent{}, false
	}
}

// file writing. build a readable summary and stores it on disk
func writeSummary(components []ConfiguredComponent) error {
	var sb strings.Builder // Efficient string concatenation

	sb.WriteString("Configured components:\n")

	if len(components) == 0 {
		sb.WriteString("- (none)\n")
	} else {
		for i, c := range components {
			sb.WriteString(fmt.Sprintf("%d) %s\n", i+1, c.Detail))
		}
	}

	// 0644 = owner can read/write, others can read
	return os.WriteFile(summaryFile, []byte(sb.String()), 0644)
}

// input helper functions to simplify user input handling

// reads a full line from the user and trims whitespace
func readLine(reader *bufio.Reader, prompt string) string {
	fmt.Print(prompt)
	text, _ := reader.ReadString('\n')
	return strings.TrimSpace(text)
}

// keep asking until the user enters a valid integer
func readInt(reader *bufio.Reader, prompt string) int {
	for {
		s := readLine(reader, prompt)
		n, err := strconv.Atoi(s)
		if err == nil {
			return n
		}
		fmt.Println("Please enter a valid integer.")
	}
}

// keeps asking until the user enters a valid floating number
func readFloat(reader *bufio.Reader, prompt string) float64 {
	for {
		s := readLine(reader, prompt)
		x, err := strconv.ParseFloat(s, 64)
		if err == nil {
			return x
		}
		fmt.Println("Please enter a valid number (e.g. 12, 3.5, 0.01).")
	}
}
