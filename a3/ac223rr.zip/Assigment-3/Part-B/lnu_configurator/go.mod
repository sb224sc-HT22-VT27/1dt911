module example.com/lnu_configurator

go 1.22

require (
	example.com/resistor v0.0.0
	example.com/capacitor v0.0.0
)

replace example.com/resistor => ./resistor
replace example.com/capacitor => ./capacitor