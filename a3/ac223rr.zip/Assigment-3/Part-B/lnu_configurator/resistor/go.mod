module example.com/resistor

go 1.22