package resistor

import "errors"

// errors
var (
	ErrDivideByZero = errors.New("division by zero")
)

//  calculates power P in watts using: P = U * I
func CalcPower(voltageV, currentA float64) float64 {
	return voltageV * currentA
}

// calculates voltage U in volts using: U = I * R
func CalcVoltage(currentA, resistanceOhm float64) float64 {
	return currentA * resistanceOhm
}

// calculates current I in amperes using: I = U / R
func CalcCurrent(voltageV, resistanceOhm float64) (float64, error) {
	if resistanceOhm == 0 {
		return 0, ErrDivideByZero
	}
	return voltageV / resistanceOhm, nil
}

// calculates resistance R in ohms using: R = U / I
func CalcResistance(voltageV, currentA float64) (float64, error) {
	if currentA == 0 {
		return 0, ErrDivideByZero
	}
	return voltageV / currentA, nil
}
