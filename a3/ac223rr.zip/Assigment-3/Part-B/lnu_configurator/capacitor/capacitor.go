package capacitor

import "errors"

var (
	ErrDivideByZero = errors.New("division by zero")
)

// calculates charge Q in coulombs using: Q = C * V
func CalcCharge(capacitanceF, voltageV float64) float64 {
	return capacitanceF * voltageV
}

// calculates capacitance C in farads using: C = Q / V
func CalcCapacitance(chargeC, voltageV float64) (float64, error) {
	if voltageV == 0 {
		return 0, ErrDivideByZero
	}
	return chargeC / voltageV, nil
}

// calculates voltage V in volts using: V = Q / C
func CalcVoltage(chargeC, capacitanceF float64) (float64, error) {
	if capacitanceF == 0 {
		return 0, ErrDivideByZero
	}
	return chargeC / capacitanceF, nil
}
