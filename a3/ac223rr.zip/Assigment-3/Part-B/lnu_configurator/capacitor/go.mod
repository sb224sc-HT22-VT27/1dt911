module example.com/capacitor

go 1.22