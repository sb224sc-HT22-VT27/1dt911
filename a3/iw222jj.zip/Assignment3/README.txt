README, How to compile and run the programs

Go version: 1.25.5


A1

Step1: Open up a new terminal

Step2: Navigate to srv.go in A1/http folder, and run it using go run srv.go, DONT CLOSE THE terminal

Step3: Open up another terminal and navigate to the client.go file in the same folder and run the command "go run client.go" command in the terminal


B1

Step1: Open up a new terminal

Step2: Navigate to the "main.go" go file in the "main" folder

Step3: Use the command "go run ." to run the program


B2

Step1: Open up a new terminal

Step2: Navigate to the "main" folder

Step3: Run the "lnu_configurator.go" file using the "go run ." command

Step4: Perform the calculations you want

Step5: Press 4 to save into a "config_values" file that gets created inside the main folder, or just press 5 to close the program.