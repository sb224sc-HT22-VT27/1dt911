module example.com/capacitor

go 1.25.5
