package capacitor

import "testing"

func TestCalcResistance (t *testing.T) {

	chargeA := 2.0
	voltA := 2.0

	expected := 1.0
	result := CalcCapacitance(chargeA, voltageA)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}

}