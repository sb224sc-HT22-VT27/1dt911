package capacitor

func CalcCapacitance(charge, voltage float64) float64 {
	return charge / voltage
}