package resistor

import "testing"

func TestResistance(t *testing.T) {
	voltaA := 20.0
	currentA := 2.0

	expected := 1.0
	result := CalcResistance(voltageA, currentA)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}
}
