package resistor

func CalcResistance(voltage, current float64) float64 {
	return voltage / current
}