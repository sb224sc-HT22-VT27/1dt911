module example.com/voltage

go 1.25.5
