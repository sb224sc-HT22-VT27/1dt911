package voltage

import "testing"

func TestVoltage(t *testing.T) {
	voltA := 2.0
	currentA := 2.0

	expected := 20.0
	result := CalcVoltage(voltA, currentA)

	if result != expected {
		t.Errorf("Expected %v, got %v", expected, result)
	}
}
