package voltage


func CalcVoltage(current, resistance float64) float64 {
	return current * resistance
}
