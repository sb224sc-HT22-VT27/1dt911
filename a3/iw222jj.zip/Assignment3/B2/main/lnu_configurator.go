package main

import (
	"fmt"
	"os"

	"example.com/capacitor"
	"example.com/resistor"
	"example.com/voltage"
)

// SaveConfiguration writes the calculated values to a file
func SaveConfiguration(resistance, capacitance, voltageValue float64) error {
	file, err := os.Create("config_values.txt")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return err
	}
	defer file.Close()

	fmt.Fprintln(file, "Calculated Resistance (Ohms):", resistance)
	fmt.Fprintln(file, "Calculated Capacitance (Farads):", capacitance)
	fmt.Fprintln(file, "Calculated Voltage (Volts):", voltageValue)

	return nil
}

func main() {
	var choice int

	// Stored values
	var (
		resistance   float64
		capacitance  float64
		voltageValue float64
	)

	// Flags to check what was calculated
	var (
		resistanceSet  bool
		capacitanceSet bool
		voltageSet     bool
	)

	// Show previous configuration if it exists
	if fileContent, err := os.ReadFile("config_values.txt"); err == nil {
		fmt.Println("Previous session configuration:")
		fmt.Println(string(fileContent))
	}

	for {
		fmt.Println("\nSelect component type to configure:")
		fmt.Println("1. Resistor")
		fmt.Println("2. Capacitor")
		fmt.Println("3. Voltage")
		fmt.Println("4. Save and Exit")
		fmt.Println("5. Exit without saving")
		fmt.Scan(&choice)

		switch choice {
		case 1:
			var r, v float64
			fmt.Println("Enter resistance (Ohms):")
			fmt.Scan(&r)
			fmt.Println("Enter voltage (Volts):")
			fmt.Scan(&v)

			resistance = resistor.CalcResistance(r, v)
			fmt.Printf("Calculated resistance: %.2f Ohms\n", resistance)
			resistanceSet = true

		case 2:
			var c, v float64
			fmt.Println("Enter charge (Coulombs):")
			fmt.Scan(&c)
			fmt.Println("Enter voltage (Volts):")
			fmt.Scan(&v)

			capacitance = capacitor.CalcCapacitance(c, v)
			fmt.Printf("Calculated capacitance: %.2f Farads\n", capacitance)
			capacitanceSet = true

		case 3:
			var r, i float64
			fmt.Println("Enter resistance (Ohms):")
			fmt.Scan(&r)
			fmt.Println("Enter current (Amperes):")
			fmt.Scan(&i)

			voltageValue = voltage.CalcVoltage(r, i)
			fmt.Printf("Calculated voltage: %.2f Volts\n", voltageValue)
			voltageSet = true

		case 4:
			fmt.Println("\nConfiguration summary:")
			if resistanceSet {
				fmt.Println("- Resistance calculated")
			}
			if capacitanceSet {
				fmt.Println("- Capacitance calculated")
			}
			if voltageSet {
				fmt.Println("- Voltage calculated")
			}

			if resistanceSet && capacitanceSet && voltageSet {
				fmt.Println("All components configured. Saving and exiting.")

				if err := SaveConfiguration(resistance, capacitance, voltageValue); err != nil {
					fmt.Println("Error saving configuration:", err)
				}
				return
			}

			fmt.Println("Please configure all components before saving.")

		case 5:
			fmt.Println("Exiting without saving.")
			return

		default:
			fmt.Println("Invalid choice. Please select 1–5.")
		}
	}
}
