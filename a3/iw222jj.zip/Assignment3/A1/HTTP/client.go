package main

import (
	"io"
	"net/http"
	"strings"
)

const URL = "http://localhost:3000/kvs"

func Get(key string) (string, bool) {
	resp, err := http.Get(URL + "/" + key)

	if err != nil {
		return "", false
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", false
	}
	body, err := io.ReadAll(resp.Body)

	if err != nil {
		return "", false
	}
	return string(body), true
}

func Put(key string, val string) bool {
	req, err := http.NewRequest(http.MethodPut, URL+"/"+key, strings.NewReader(val))

	if err != nil {
		return false
	}

	client := &http.Client{}
	resp, err := client.Do(req)

	if err != nil {
		return false
	}

	defer resp.Body.Close()
	return resp.StatusCode == http.StatusCreated
}

func Delete(key string) bool {
	req, err := http.NewRequest(http.MethodDelete, URL+"/"+key, nil)

	if err != nil {
		return false
	}

	client := &http.Client{}
	resp, err := client.Do(req)

	if err != nil {
		return false
	}

	defer resp.Body.Close()
	return resp.StatusCode == http.StatusOK
}


func main() {
	assertPut := func(key, value string) {
		if !Put(key, value) {
			panic("put " + key + " failed")
		}

		println("Put", key, "succeeded")
	}

	assertGet := func(key, expected string) {
		val, ok := Get(key)
		if !ok || val != expected {
			panic("get " + key + " failed")
		}

		println("Get", key, "succeeded:", val)
	}

	assertGetFail := func(key string) {
		if _, ok := Get(key); ok {
			panic("get " + key + " should fail")
		}
		println("Get", key, "correctly failed")
	}

	assertDelete := func(key string) {
		if !Delete(key) {
			panic("delete " + key + " failed")
		}
		println("Delete", key, "succeeded")
	}

	assertPut("first", "initial")
	assertGet("first", "initial")

	assertPut("second", "another")
	assertPut("third", "more")
	assertPut("fourth", "done")

	assertGetFail("fifth")

	assertDelete("third")
	assertGetFail("third")
}
