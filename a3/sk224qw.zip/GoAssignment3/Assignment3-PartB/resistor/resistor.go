package resistor

// calculates power using P = U * I
func CalcEffect(voltage float64, current float64) float64 {
	return voltage * current
}

// calculates voltage using U = I * R
func CalcVoltage(current float64, resistance float64) float64 {
	return current * resistance
}
