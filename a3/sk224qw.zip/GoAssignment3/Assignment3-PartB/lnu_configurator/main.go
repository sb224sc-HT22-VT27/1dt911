package main

import (
	"fmt"
	"os"

	"example.com/capacitor"
	"example.com/resistor"
)

// Reads old data and displays it
func main() {
	data, err := os.ReadFile("session.txt")
	if err == nil {
		fmt.Println("Previous session data:")
		fmt.Println(string(data))
	}

	var result string
	var count int

	// Runs menu for new input
	for {
		fmt.Println("\nComponent Configurator")
		fmt.Println("1. Configure Resistor")
		fmt.Println("2. Configure Capacitor")
		fmt.Println("0. Quit and Save")
		fmt.Print("Selection: ")

		var choice int
		fmt.Scan(&choice)

		if choice == 0 {
			break
		}

		if choice == 1 {
			var v, i float64
			fmt.Print("Enter voltage (V): ")
			fmt.Scan(&v)
			fmt.Print("Enter current (A): ")
			fmt.Scan(&i)

			// Resistor module calculation
			power := resistor.CalcEffect(v, i)
			line := fmt.Sprintf("Resistor: V=%.2f, I=%.2f -> P=%.2f W\n", v, i, power)

			fmt.Print(line)
			result += line
			count++

		} else if choice == 2 {
			var c, v float64
			fmt.Print("Enter capacitance (F): ")
			fmt.Scan(&c)
			fmt.Print("Enter voltage (V): ")
			fmt.Scan(&v)
			// Capacitor module calculation
			charge := capacitor.CalcCharge(c, v)
			line := fmt.Sprintf("Capacitor: C=%.2f, V=%.2f -> Q=%.2f C\n", c, v, charge)

			fmt.Print(line)
			result += line
			count++
		}
	}

	if result != "" {
		// Uses os to save summary
		err := os.WriteFile("session.txt", []byte(result), 0644)
		if err != nil {
			fmt.Println("Error saving session:", err)
		} else {
			fmt.Println("Session saved to session.txt")
		}
	}
}
