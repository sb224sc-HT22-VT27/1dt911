package capacitor

// calculates charge using Q = C * V
func CalcCharge(capacitance float64, voltage float64) float64 {
	return capacitance * voltage
}
