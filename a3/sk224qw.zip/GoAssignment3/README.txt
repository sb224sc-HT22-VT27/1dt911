// öppna terminal -> cd DelA -> go run srv.go -> öppna ny terminal -> go run client.go 

// öppna terminal, gå till mappen cd DelA, starta sedan servern med "go run srv.go", därpå öppna en ny terminal och kör go run client.go 

// Del B, navigera till directoryn lnu_configurator och kör "go run ."