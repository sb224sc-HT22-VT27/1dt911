module part_a

go 1.25.5
