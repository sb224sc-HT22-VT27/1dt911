package main

import (
	"fmt"
	"io"
	"net/http"
	"strings"
)

const baseURL = "http://localhost:3000/kvs/" // url för servern för key value

func Put(key, value string) error { // sparar värde med nyckel

	req, err := http.NewRequest("PUT", baseURL+key, strings.NewReader(value))
	if err != nil {

		return err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {

		return err
	}

	defer resp.Body.Close()
	if resp.StatusCode != http.StatusCreated { //kontrollera att status är 201

		return fmt.Errorf("Gick inte att skapa -> status %d", resp.StatusCode)
	}

	return nil

}

func Get(key string) (string, int, error) { //hämtar värde med nyckeln

	resp, err := http.Get(baseURL + key)
	if err != nil {

		return "", 0, err

	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	return string(body), resp.StatusCode, nil

}

func Delete(key string) error { //raderar värde med nyckeln

	req, err := http.NewRequest("DELETE", baseURL+key, nil)
	if err != nil {

		return err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {

		return err
	}

	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { //kontrollera att status 200

		return fmt.Errorf("gick inte o radera-> status %d", resp.StatusCode)
	}
	return nil

}

func main() {

	// provar med att lägga 201
	if err := Put("testnyckel", "hii"); err == nil {

		fmt.Println("PUT -> Oke(201 skapad)")
	}

	//provar få 200
	val, code, _ := Get("testnyckel")
	if code == http.StatusOK && val == "hii" {

		fmt.Printf("GET -> Oke (200), Värde-> %s\n", val)
	}

	//provar ta bort 200
	if err := Delete("testnyckel"); err == nil {

		fmt.Println("DELETE-> Oke(200)")
	}

	//provar att få en inte existerande 404
	_, code, _ = Get("testnyckel")
	if code == http.StatusNotFound {

		fmt.Println("GET inte existerande-> Oke(404 ej hittad)")
	}
}
