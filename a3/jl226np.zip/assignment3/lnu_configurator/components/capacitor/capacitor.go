package capacitor

func CalcCharge(cFarads float64, uVolts float64) float64 {
	return cFarads * uVolts
}

func CalcEnergy(cFarads float64, uVolts float64) float64 {
	return 0.5 * cFarads * uVolts * uVolts
}
