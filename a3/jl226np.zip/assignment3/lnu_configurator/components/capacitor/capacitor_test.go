package capacitor

import "testing"

func almostEqual(a, b, eps float64) bool {
	if a > b {
		return a-b < eps
	}
	return b-a < eps
}

func TestCalcCharge(t *testing.T) {
	got := CalcCharge(0.001, 5)
	want := 0.005
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcCharge: got %v want %v", got, want)
	}
}

func TestCalcEnergy(t *testing.T) {
	got := CalcEnergy(0.001, 5)
	want := 0.0125
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcEnergy: got %v want %v", got, want)
	}
}
