package battery

import "testing"

func almostEqual(a, b, eps float64) bool {
	if a > b {
		return a-b < eps
	}
	return b-a < eps
}

func TestCalcCapacityAh(t *testing.T) {
	got := CalcCapacityAh(2, 3)
	want := 6.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcCapacityAh: got %v want %v", got, want)
	}
}

func TestCalcEnergyWh(t *testing.T) {
	got := CalcEnergyWh(12, 5)
	want := 60.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcEnergyWh: got %v want %v", got, want)
	}
}

func TestCalcRuntimeHours(t *testing.T) {
	got := CalcRuntimeHours(10, 2)
	want := 5.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcRuntimeHours: got %v want %v", got, want)
	}
}

func TestCalcLoadCurrentA(t *testing.T) {
	got := CalcLoadCurrentA(24, 12)
	want := 2.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcLoadCurrentA: got %v want %v", got, want)
	}
}
