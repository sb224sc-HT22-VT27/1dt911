package battery

func CalcCapacityAh(currentA float64, timeHours float64) float64 {
	return currentA * timeHours
}

func CalcEnergyWh(voltageV float64, capacityAh float64) float64 {
	return voltageV * capacityAh
}

func CalcRuntimeHours(capacityAh float64, loadCurrentA float64) float64 {
	return capacityAh / loadCurrentA
}

func CalcLoadCurrentA(powerW float64, voltageV float64) float64 {
	return powerW / voltageV
}
