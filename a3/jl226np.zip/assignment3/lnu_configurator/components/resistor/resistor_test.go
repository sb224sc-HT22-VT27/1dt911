package resistor

import "testing"

func almostEqual(a, b, eps float64) bool {
	if a > b {
		return a-b < eps
	}
	return b-a < eps
}

func TestCalcPower(t *testing.T) {
	got := CalcPower(10, 2)
	want := 20.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcPower: got %v want %v", got, want)
	}
}

func TestCalcVoltage(t *testing.T) {
	got := CalcVoltage(2, 5)
	want := 10.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcVoltage: got %v want %v", got, want)
	}
}

func TestCalcCurrent(t *testing.T) {
	got := CalcCurrent(10, 5)
	want := 2.0
	if !almostEqual(got, want, 1e-12) {
		t.Fatalf("CalcCurrent: got %v want %v", got, want)
	}
}
