package resistor

func CalcPower(uVolts float64, iAmps float64) float64 {
	return uVolts * iAmps
}
func CalcVoltage(iAmps float64, rOhms float64) float64 {
	return iAmps * rOhms
}

func CalcCurrent(uVolts float64, rOhms float64) float64 {
	return uVolts / rOhms
}
