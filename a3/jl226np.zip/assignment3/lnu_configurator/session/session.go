package session

import (
	"os"
)

func ReadSummary(path string) (string, bool) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", false
	}
	return string(data), true
}

func WriteSummary(path string, content string) error {
	return os.WriteFile(path, []byte(content), 0644)
}
