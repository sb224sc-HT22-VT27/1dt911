module lnu_configurator

go 1.25.4
