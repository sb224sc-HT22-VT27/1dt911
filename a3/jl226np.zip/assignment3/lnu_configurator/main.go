package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"lnu_configurator/components/battery"
	"lnu_configurator/components/capacitor"
	"lnu_configurator/components/resistor"
	"lnu_configurator/session"
)

const summaryFile = "last_session.txt"

type ConfiguredComponent struct {
	Kind    string
	Details string
}

func main() {
	if txt, ok := session.ReadSummary(summaryFile); ok {
		fmt.Println("=== Previous session summary ===")
		fmt.Println(txt)
		fmt.Println("================================")
		fmt.Println()
	}

	in := bufio.NewScanner(os.Stdin)

	var configured []ConfiguredComponent
	for len(configured) < 3 {
		fmt.Printf("Configure component %d/3\n", len(configured)+1)
		fmt.Println("Choose component type:")
		fmt.Println("  1) Resistor")
		fmt.Println("  2) Capacitor")
		fmt.Println("  3) Battery")
		fmt.Print("> ")

		choice := readLine(in)
		switch choice {
		case "1":
			cc, ok := configureResistor(in)
			if ok {
				configured = append(configured, cc)
				fmt.Println("Saved.")
			}
		case "2":
			cc, ok := configureCapacitor(in)
			if ok {
				configured = append(configured, cc)
				fmt.Println("Saved.")
			}
		case "3":
			cc, ok := configureBattery(in)
			if ok {
				configured = append(configured, cc)
				fmt.Println("Saved.")
			}
		default:
			fmt.Println("Invalid choice, try again.")
		}
	}

	fmt.Println("You have configured 3 components.")
	fmt.Print("Type 'q' to quit and write summary file: ")
	for {
		if strings.EqualFold(readLine(in), "q") {
			break
		}
		fmt.Print("Please type 'q' to quit: ")
	}

	summary := buildSummary(configured)
	if err := session.WriteSummary(summaryFile, summary); err != nil {
		fmt.Println("ERROR writing summary:", err)
		os.Exit(1)
	}

	fmt.Println("\nSummary written to", summaryFile)
	fmt.Println("Bye!")
}

func configureResistor(in *bufio.Scanner) (ConfiguredComponent, bool) {
	fmt.Println("\nResistor calculations:")
	fmt.Println("  1) Power P from Voltage U and Current I (P = U * I)")
	fmt.Println("  2) Voltage U from Current I and Resistance R (U = I * R)")
	fmt.Println("  3) Current I from Voltage U and Resistance R (I = U / R)")
	fmt.Print("> ")

	choice := readLine(in)
	switch choice {
	case "1":
		u := readFloat(in, "Enter voltage U [V]: ")
		i := readFloat(in, "Enter current I [A]: ")
		p := resistor.CalcPower(u, i)
		return ConfiguredComponent{
			Kind:    "Resistor",
			Details: fmt.Sprintf("Given U=%.6g V and I=%.6g A => P=%.6g W", u, i, p),
		}, true
	case "2":
		i := readFloat(in, "Enter current I [A]: ")
		r := readFloat(in, "Enter resistance R [Ohm]: ")
		u := resistor.CalcVoltage(i, r)
		return ConfiguredComponent{
			Kind:    "Resistor",
			Details: fmt.Sprintf("Given I=%.6g A and R=%.6g Ohm => U=%.6g V", i, r, u),
		}, true
	case "3":
		u := readFloat(in, "Enter voltage U [V]: ")
		r := readFloat(in, "Enter resistance R [Ohm]: ")
		i := resistor.CalcCurrent(u, r)
		return ConfiguredComponent{
			Kind:    "Resistor",
			Details: fmt.Sprintf("Given U=%.6g V and R=%.6g Ohm => I=%.6g A", u, r, i),
		}, true
	default:
		fmt.Println("Invalid choice.")
		return ConfiguredComponent{}, false
	}
}

func configureCapacitor(in *bufio.Scanner) (ConfiguredComponent, bool) {
	fmt.Println("\nCapacitor calculations:")
	fmt.Println("  1) Charge Q from Capacitance C and Voltage U (Q = C * U)")
	fmt.Println("  2) Energy E from Capacitance C and Voltage U (E = 0.5 * C * U^2)")
	fmt.Print("> ")

	choice := readLine(in)
	switch choice {
	case "1":
		c := readFloat(in, "Enter capacitance C [F]: ")
		u := readFloat(in, "Enter voltage U [V]: ")
		q := capacitor.CalcCharge(c, u)
		return ConfiguredComponent{
			Kind:    "Capacitor",
			Details: fmt.Sprintf("Given C=%.6g F and U=%.6g V => Q=%.6g C", c, u, q),
		}, true
	case "2":
		c := readFloat(in, "Enter capacitance C [F]: ")
		u := readFloat(in, "Enter voltage U [V]: ")
		e := capacitor.CalcEnergy(c, u)
		return ConfiguredComponent{
			Kind:    "Capacitor",
			Details: fmt.Sprintf("Given C=%.6g F and U=%.6g V => E=%.6g J", c, u, e),
		}, true
	default:
		fmt.Println("Invalid choice.")
		return ConfiguredComponent{}, false
	}
}

func configureBattery(in *bufio.Scanner) (ConfiguredComponent, bool) {
	fmt.Println("\nBattery calculations:")
	fmt.Println("  1) Capacity Ah from Current A and Time h (Ah = I * t)")
	fmt.Println("  2) Energy Wh from Voltage V and Capacity Ah (Wh = V * Ah)")
	fmt.Println("  3) Runtime h from Capacity Ah and Load Current A (t = Ah / I)")
	fmt.Println("  4) Load Current A from Power W and Voltage V (I = P / V)")
	fmt.Print("> ")

	choice := readLine(in)
	switch choice {
	case "1":
		i := readFloat(in, "Enter current I [A]: ")
		t := readFloat(in, "Enter time t [h]: ")
		ah := battery.CalcCapacityAh(i, t)
		return ConfiguredComponent{
			Kind:    "Battery",
			Details: fmt.Sprintf("Given I=%.6g A and t=%.6g h => Capacity=%.6g Ah", i, t, ah),
		}, true

	case "2":
		u := readFloat(in, "Enter voltage U [V]: ")
		ah := readFloat(in, "Enter capacity [Ah]: ")
		wh := battery.CalcEnergyWh(u, ah)
		return ConfiguredComponent{
			Kind:    "Battery",
			Details: fmt.Sprintf("Given U=%.6g V and Capacity=%.6g Ah => Energy=%.6g Wh", u, ah, wh),
		}, true

	case "3":
		ah := readFloat(in, "Enter capacity [Ah]: ")
		i := readFloat(in, "Enter load current I [A]: ")
		t := battery.CalcRuntimeHours(ah, i)
		return ConfiguredComponent{
			Kind:    "Battery",
			Details: fmt.Sprintf("Given Capacity=%.6g Ah and I=%.6g A => Runtime=%.6g h", ah, i, t),
		}, true

	case "4":
		p := readFloat(in, "Enter power P [W]: ")
		u := readFloat(in, "Enter voltage U [V]: ")
		i := battery.CalcLoadCurrentA(p, u)
		return ConfiguredComponent{
			Kind:    "Battery",
			Details: fmt.Sprintf("Given P=%.6g W and U=%.6g V => Load current=%.6g A", p, u, i),
		}, true

	default:
		fmt.Println("Invalid choice.")
		return ConfiguredComponent{}, false
	}
}

func buildSummary(items []ConfiguredComponent) string {
	var b strings.Builder
	b.WriteString("Configured components:\n")
	for idx, it := range items {
		b.WriteString(fmt.Sprintf("%d) %s: %s\n", idx+1, it.Kind, it.Details))
	}
	return b.String()
}

func readLine(in *bufio.Scanner) string {
	in.Scan()
	return strings.TrimSpace(in.Text())
}

func readFloat(in *bufio.Scanner, prompt string) float64 {
	for {
		fmt.Print(prompt)
		s := readLine(in)
		var v float64
		_, err := fmt.Sscanf(s, "%f", &v)
		if err == nil {
			return v
		}
		fmt.Println("Please enter a valid number, e.g. 3.14")
	}
}
