package main

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

type Client struct {
	BaseURL string
	HTTP    *http.Client
}

func NewClient(baseURL string) *Client {
	return &Client{BaseURL: baseURL, HTTP: &http.Client{Timeout: 3 * time.Second}}
}

func (c *Client) Put(key, value string) (int, error) {
	req, err := http.NewRequest(http.MethodPut, fmt.Sprintf("%s/%s", c.BaseURL, key), bytes.NewBufferString(value))
	if err != nil {
		return 0, err
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return 0, err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	return resp.StatusCode, nil
}

func (c *Client) Get(key string) (string, int, error) {
	req, err := http.NewRequest(http.MethodGet, fmt.Sprintf("%s/%s", c.BaseURL, key), nil)
	if err != nil {
		return "", 0, err
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return "", 0, err
	}
	b, readErr := io.ReadAll(resp.Body)
	resp.Body.Close()
	if readErr != nil {
		return "", resp.StatusCode, readErr
	}
	return string(b), resp.StatusCode, nil
}

func (c *Client) Delete(key string) (int, error) {
	req, err := http.NewRequest(http.MethodDelete, fmt.Sprintf("%s/%s", c.BaseURL, key), nil)
	if err != nil {
		return 0, err
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return 0, err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	return resp.StatusCode, nil
}

func must(ok bool, msg string) {
	if !ok {
		fmt.Fprintln(os.Stderr, msg)
		os.Exit(1)
	}
}

func main() {
	base := os.Getenv("KVS_URL")
	if base == "" {
		base = "http://localhost:3000/kvs"
	}
	c := NewClient(base)
	p := fmt.Sprintf("kvs_%d_", time.Now().UnixNano())

	k1 := p + "first"
	k2 := p + "second"
	k3 := p + "third"
	k4 := p + "fourth"
	k5 := p + "fifth"
	ku := p + "username"

	status, err := c.Put(k1, "initial")
	must(err == nil && status == 201, "put first failed")

	val, status, err := c.Get(k1)
	must(err == nil && status == 200 && val == "initial", "get first failed")

	status, err = c.Put(k2, "another")
	must(err == nil && status == 201, "put second failed")

	status, err = c.Put(k3, "more")
	must(err == nil && status == 201, "put third failed")

	status, err = c.Put(k4, "done")
	must(err == nil && status == 201, "put fourth failed")

	_, status, err = c.Get(k5)
	must(err == nil && status == 404, "get fifth should fail")

	status, err = c.Delete(k3)
	must(err == nil && status == 200, "delete third failed")

	_, status, err = c.Get(k3)
	must(err == nil && status == 404, "get third should fail")

	status, err = c.Put(ku, "Bob")
	must(err == nil && status == 201, "put username failed")

	val, status, err = c.Get(ku)
	must(err == nil && status == 200 && val == "Bob", "get username failed")
	fmt.Println("username ->", val)

	status, err = c.Put(ku, "Alice")
	must(err == nil && status == 200, "put username overwrite failed")

	val, status, err = c.Get(ku)
	must(err == nil && status == 200 && val == "Alice", "get username after overwrite failed")

	fmt.Println("All tests passed.")
}
