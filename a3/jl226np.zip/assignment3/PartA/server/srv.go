package main

import (
	"io"
	"net/http"
	"sync"
)

var (
	kvs = make(map[string]string)
	mu  sync.RWMutex
)

func putKey(key, value string) int {
	mu.Lock()
	_, existed := kvs[key]
	kvs[key] = value
	mu.Unlock()
	if !existed {
		return http.StatusCreated
	}
	return http.StatusOK
}

func getKey(key string) (string, int) {
	mu.RLock()
	val, ok := kvs[key]
	mu.RUnlock()
	if !ok {
		return "", http.StatusNotFound
	}
	return val, http.StatusOK
}

func delKey(key string) int {
	mu.Lock()
	_, ok := kvs[key]
	if ok {
		delete(kvs, key)
	}
	mu.Unlock()
	if !ok {
		return http.StatusNotFound
	}
	return http.StatusOK
}

func apiPut(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	body, _ := io.ReadAll(r.Body)
	status := putKey(key, string(body))
	w.WriteHeader(status)
	if status == http.StatusCreated {
		w.Write([]byte("201"))
		return
	}
	w.Write([]byte("200"))
}

func apiGet(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	val, status := getKey(key)
	w.WriteHeader(status)
	if status == http.StatusNotFound {
		w.Write([]byte("404"))
		return
	}
	w.Write([]byte("200\n" + val))
}

func apiDelete(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	status := delKey(key)
	w.WriteHeader(status)
	if status == http.StatusNotFound {
		w.Write([]byte("404"))
		return
	}
	w.Write([]byte("200"))
}

func browserPut(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	value := r.PathValue("value")
	status := putKey(key, value)
	w.WriteHeader(status)
	if status == http.StatusCreated {
		w.Write([]byte("201"))
		return
	}
	w.Write([]byte("200"))
}

func browserGet(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	val, status := getKey(key)
	w.WriteHeader(status)
	if status == http.StatusNotFound {
		w.Write([]byte("404"))
		return
	}
	w.Write([]byte("200\n" + val))
}

func browserDelete(w http.ResponseWriter, r *http.Request) {
	key := r.PathValue("key")
	status := delKey(key)
	w.WriteHeader(status)
	if status == http.StatusNotFound {
		w.Write([]byte("404"))
		return
	}
	w.Write([]byte("200"))
}

func root(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Use:\n/put/{key}/{value}\n/get/{key}\n/delete/{key}\n\nAPI:\nPUT /kvs/{key}\nGET /kvs/{key}\nDELETE /kvs/{key}\n"))
}

func main() {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /", root)

	mux.HandleFunc("PUT /kvs/{key}", apiPut)
	mux.HandleFunc("GET /kvs/{key}", apiGet)
	mux.HandleFunc("DELETE /kvs/{key}", apiDelete)

	mux.HandleFunc("GET /put/{key}/{value}", browserPut)
	mux.HandleFunc("GET /get/{key}", browserGet)
	mux.HandleFunc("GET /delete/{key}", browserDelete)

	http.ListenAndServe(":3000", mux)
}
