import requests

URL = "http://localhost:3000/kvs"
TIMEOUT = 3


def get(key):
    r = requests.get(f"{URL}/{key}", timeout=TIMEOUT)
    if r.status_code == 200:
        return r.text, True
    return None, False


def put(key, val):
    r = requests.put(f"{URL}/{key}", data=val, timeout=TIMEOUT)
    return r.status_code in (200, 201)


def delete(key):
    r = requests.delete(f"{URL}/{key}", timeout=TIMEOUT)
    return r.status_code == 200


def main():
    assert put("first", "initial"), "put first failed"
    assert get("first") == ("initial", True), "get first failed"
    assert put("second", "another"), "put second failed"
    assert put("third", "more"), "put third failed"
    assert put("fourth", "done"), "put fourth failed"
    assert get("fifth") == (None, False), "get fifth should fail"
    assert delete("third"), "delete failed"
    assert get("third") == (None, False), "get third should fail"
    assert put("username", "Bob"), "put username failed"
    print("username ->", get("username"))
    print("All tests passed.")


if __name__ == "__main__":
    main()
