Part A

to run: Open a terminal in the folder containing srv.go and start the server with go run srv.go  http://localhost:3000

Browser testing 
http://localhost:3000/put/{key}/{value}
http://localhost:3000/get/{key}
http://localhost:3000/delete/{key}

API endpoints:
PUT /kvs/{key}
GET /kvs/{key}
DELETE /kvs/{key}

or run the test.py file to show a demonstration, and all the tests shloud pass if the server is running.

Part B

to run the program make sure you are in the project root (the map that contains all the files), in this case lnu_configurator.

open the terminal and navigate to the right location using CD,

when you are at the right location you write:
go run . : to run the program
go test ./... : to run the tests