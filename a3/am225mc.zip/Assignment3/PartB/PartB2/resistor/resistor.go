package resistor

func CalcEffect(volt, amperes float64) float64 {
	effect := volt * amperes
	return effect
}

func CalcAmperes(volt, resistance float64) float64 {
	amperes := volt / resistance
	return amperes
}

func CalcVolt(amperes, resistance float64) float64{
	volt := amperes * resistance
	return volt
}
