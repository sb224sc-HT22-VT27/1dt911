package resistor

import "testing"

func TestCalcEffect(t *testing.T) {
	effect := CalcEffect(5, 2)
	if effect != 10 {
		t.Errorf("CalcEffect(5,2) = %v, want 10", effect)
	}
}

func TestCalcAmperes(t *testing.T) {
	amp := CalcAmperes(10, 5)
	if amp != 2 {
		t.Errorf("CalcAmperes(10,5) = %v, want 2", amp)
	}
}

func TestCalcVolt(t *testing.T) {
	volt := CalcVolt(3, 4)
	if volt != 12 {
		t.Errorf("CalcVolt(3,4) = %v, want 12", volt)
	}
}
