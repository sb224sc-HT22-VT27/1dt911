package battery

func CalcEnergy(volt, charge float64) float64 {
	return volt * charge
}

func CalcCharge(energy, volt float64) float64 {
	return energy / volt
}

func CalcVolt(energy, charge float64) float64 {
	return energy / charge
}
