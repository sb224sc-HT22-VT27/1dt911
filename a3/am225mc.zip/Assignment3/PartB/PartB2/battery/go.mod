module example.com/battery

go 1.25.4
