package battery

import (
	"testing"
)

func TestCalcEnergy(t *testing.T) {
	e := CalcEnergy(12, 100)
	if e != 1200 {
		t.Errorf("CalcEnergy(12,100) = %v, want 1200", e)
	}
}

func TestCalcCharge(t *testing.T) {
	q := CalcCharge(1200, 12)
	if q != 100 {
		t.Errorf("CalcCharge(1200,12) = %v, want 100", q)
	}
}

func TestCalcVolt(t *testing.T) {
	v := CalcVolt(1200, 100)
	if v != 12 {
		t.Errorf("CalcVolt(1200,100) = %v, want 12", v)
	}
}
