package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"

	"example.com/battery"
	"example.com/capacitor"
	"example.com/resistor"
)

type saver struct {
	resistor  string
	capacitor string
	battery   string
}

func (s *saver) addToSaver(component, result string) {
	switch component {
	case "resistor":
		s.resistor += result + "\n"
	case "capacitor":
		s.capacitor += result + "\n"
	case "battery":
		s.battery += result + "\n"
	default:
		fmt.Println("Error happened somewhere...")
	}

}

func showPrevSesh() {
	data, err := os.ReadFile("prev.txt")
	if err != nil {
		fmt.Println("Error reading file:", err)
		return
	}

	results := string(data)
	fmt.Println("Previous run:\n", results)
}

func main() {
	showPrevSesh()

	reader := bufio.NewReader(os.Stdin)
	saver := saver{
		resistor:  "RESISTOR\n",
		capacitor: "CAPACITOR\n",
		battery:   "BATTERY\n",
	}

	fmt.Print("--------------NEW RUN-------------\n")
	fmt.Println("Configure 3 components:")

	for i := 0; i < 3; i++ {
		fmt.Printf("\nComponent %d:\n", i+1)

		fmt.Println("Select component type (resistor/capacitor/battery/quit)(r/c/b/q):")
		compType, _ := reader.ReadString('\n')
		compType = strings.TrimSpace(strings.ToLower(compType))

		switch compType {
		case "r":
			fmt.Println("You selected a resistor.")
			resistorPath(reader, &saver)
			fmt.Println("------------RESULTS------------")
			fmt.Print(saver.resistor)

		case "c":
			fmt.Println("You selected a capacitor.")
			capacitorPath(reader, &saver)
			fmt.Println("------------RESULTS------------")
			fmt.Print(saver.capacitor)

		case "b":
			fmt.Println("You selected a battery.")
			batteryPath(reader, &saver)
			fmt.Println("------------RESULTS------------")
			fmt.Print(saver.battery)
		case "q":
			i = 3
		default:
			fmt.Println("Unknown component type. Please enter resistor, capacitor, or battery.")
			i--
		}
	}

	saveToFile(&saver)
	fmt.Println("All done! Exiting...")
}

func resistorPath(reader *bufio.Reader, saver *saver) {
	component := "resistor"
	volt := ReadFloat(reader, "Enter voltage (V): ")
	amperes := ReadFloat(reader, "Enter amperes (I): ")
	resistance := ReadFloat(reader, "Enter Resistance (Ω): ")

	effectR := resistor.CalcEffect(volt, amperes)
	voltR := resistor.CalcVolt(amperes, resistance)
	amperesR := resistor.CalcAmperes(volt, resistance)

	resultEffect := fmt.Sprintf("The effect: %v W", effectR)
	resultVolt := fmt.Sprintf("The volt: %v V", voltR)
	resultAmperes := fmt.Sprintf("The amperes: %v I", amperesR)

	saver.addToSaver(component, resultEffect)
	saver.addToSaver(component, resultVolt)
	saver.addToSaver(component, resultAmperes)
}

func capacitorPath(reader *bufio.Reader, saver *saver) {
	component := "capacitor"

	capacitance := ReadFloat(reader, "Enter capacitance (F): ")
	voltage := ReadFloat(reader, "Enter voltage (V): ")

	charge := capacitor.CalcCharge(capacitance, voltage)
	energy := capacitor.CalcEnergy(capacitance, voltage)
	voltC := capacitor.CalcVolt(charge, capacitance)
	capC := capacitor.CalcCapacitance(charge, voltage)

	resultCharge := fmt.Sprintf("Charge: %.2f C", charge)
	resultEnergy := fmt.Sprintf("Energy: %.2f J", energy)
	resultVolt := fmt.Sprintf("Voltage: %.2f V", voltC)
	resultCapacitance := fmt.Sprintf("Capacitance: %.2f F", capC)

	saver.addToSaver(component, resultCharge)
	saver.addToSaver(component, resultEnergy)
	saver.addToSaver(component, resultVolt)
	saver.addToSaver(component, resultCapacitance)
}

func batteryPath(reader *bufio.Reader, saver *saver) {
	component := "battery"

	voltage := ReadFloat(reader, "Enter voltage (V): ")
	charge := ReadFloat(reader, "Enter charge (C): ")

	energy := battery.CalcEnergy(voltage, charge)
	voltB := battery.CalcVolt(energy, charge)
	chargeB := battery.CalcCharge(energy, voltage)

	resultEnergy := fmt.Sprintf("Energy: %.2f J", energy)
	resultVolt := fmt.Sprintf("Voltage: %.2f V", voltB)
	resultCharge := fmt.Sprintf("Charge: %.2f C", chargeB)

	saver.addToSaver(component, resultEnergy)
	saver.addToSaver(component, resultVolt)
	saver.addToSaver(component, resultCharge)
}

func ReadFloat(reader *bufio.Reader, prompt string) float64 {
	for {
		fmt.Print(prompt)
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		value, err := strconv.ParseFloat(input, 64)
		if err != nil {
			fmt.Println("Invalid input. Please enter a number.")
			continue
		}

		return value
	}
}

func saveToFile(saver *saver) {
	file, err := os.Create("prev.txt")
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()

	fmt.Fprintln(file, "")
	fmt.Fprint(file, saver.resistor)

	fmt.Fprintln(file, "")
	fmt.Fprint(file, saver.capacitor)

	fmt.Fprintln(file, "")
	fmt.Fprint(file, saver.battery)
}
