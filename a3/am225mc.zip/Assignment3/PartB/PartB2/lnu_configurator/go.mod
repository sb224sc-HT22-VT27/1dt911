module example.com/lnu_configurator

go 1.25.4

replace example.com/resistor => ../resistor

require (
	example.com/battery v0.0.0-00010101000000-000000000000
	example.com/capacitor v0.0.0-00010101000000-000000000000
	example.com/resistor v0.0.0-00010101000000-000000000000
)

replace example.com/capacitor => ../capacitor

replace example.com/battery => ../battery
