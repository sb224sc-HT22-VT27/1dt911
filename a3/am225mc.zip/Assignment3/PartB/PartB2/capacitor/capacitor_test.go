package capacitor

import (
	"math"
	"testing"
)

func almostEqual(a, b float64) bool {
	const epsilon = 1e-6
	return math.Abs(a-b) < epsilon
}

func TestCalcCharge(t *testing.T) {
	q := CalcCharge(2, 3)
	if !almostEqual(q, 6) {
		t.Errorf("CalcCharge(2,3) = %v, want 6", q)
	}
}

func TestCalcCapacitance(t *testing.T) {
	c := CalcCapacitance(8, 4)
	if !almostEqual(c, 2) {
		t.Errorf("CalcCapacitance(8,4) = %v, want 2", c)
	}
}

func TestCalcVolt(t *testing.T) {
	v := CalcVolt(10, 2)
	if !almostEqual(v, 5) {
		t.Errorf("CalcVolt(10,2) = %v, want 5", v)
	}
}

func TestCalcEnergy(t *testing.T) {
	e := CalcEnergy(4, 9)
	if !almostEqual(e, 6) {
		t.Errorf("CalcEnergy(4,9) = %v, want 6", e)
	}
}
