package capacitor

import "math"

func CalcCharge(capacitance, volt float64) float64 {
	charge := capacitance * volt
	return charge
}

func CalcCapacitance(charge, volt float64) float64 {
	capacitance := charge / volt
	return capacitance
}

func CalcVolt(charge, capacitance float64) float64 {
	volt := charge / capacitance
	return volt
}

func CalcEnergy(capacitance, volt float64) float64 {
	energy := 0.5 * capacitance * math.Sqrt(volt)
	return energy
}
