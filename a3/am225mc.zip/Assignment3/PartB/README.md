How to run the program

Simply type (go run .) in the lnu_configurator directory in any terminal. 

If you want to use the test methods, simply move to the respective module directory and type (go test). 

If you want to see each function passing, type (go test -v).
