How to run the program
The program requires two terminals, one for running the server, and one for running the client. 
I chose to run srv.go in windows powershell terminal, 
and Client in visual studios built in terminal with go run .
Copy and paste the BaseURL (http://localhost:3000/kvs) in the web from main.go when checking if it worked. 
Then fill in the respective key you wanna check out, 
for example if you wanna check out alpha:
(http://localhost:3000/kvs/alpha)

Steps:

Enter a terminal
Go to the Server folder
Type "go run srv.go"
This will run the server

Enter another terminal
Go to the Client folder
Type "go run ."
This will run the client test in main.go

Search http://localhost:3000/kvs/<Key> in the web
<Key> being one of the four keys that are tested in main.go

To stop the server from running, press CTRL+C in the terminal
