package main

import (
	"fmt"
	"sync"
)

func main() {
	fmt.Println("-----------TESTING STARTS----------")

	// Copy paste and search this in the web
	client := NewClient("http://localhost:3000/kvs")

	var wg sync.WaitGroup

	// The four keys tested
	keys := []string{"alpha", "beta", "gamma", "delta"}

	fmt.Println("-----------Testing Put----------")
	for _, k := range keys {
		wg.Add(1)
		go func(key string) {
			defer wg.Done()
			ok, err := client.Put(key, "value-"+key)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			fmt.Println("Put", key, "success?:", ok)
		}(k)
	}
	wg.Wait()
	fmt.Println("All concurrent puts done!")

	fmt.Println("-----------Testing Get----------")
	for _, k := range keys {
		wg.Add(1)
		go func(key string) {
			defer wg.Done()
			body, ok, err := client.Get(key)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			fmt.Println("Get", key, "success?:", ok, "Body:", body)
		}(k)
	}

	wg.Wait()
	fmt.Println("All concurrent gets done!")

	fmt.Println("-----------Testing Remove----------")
	deleteKeys := []string{"alpha", "gamma"}
	fmt.Println("-----------To remove:", deleteKeys, "----------")

	for _, k := range deleteKeys {
		wg.Add(1)
		go func(key string) {
			defer wg.Done()
			ok, err := client.Delete(key)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			fmt.Println("Delete", key, "success?:", ok)
		}(k)
	}

	wg.Wait()
	fmt.Println("All concurrent deletes done!")

	fmt.Println("-----------Check Get Again----------")
	for _, k := range keys {
		wg.Add(1)
		go func(key string) {
			defer wg.Done()
			body, ok, err := client.Get(key)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}
			fmt.Println("Get", key, "success?:", ok, "Body:", body)
		}(k)
	}

	wg.Wait()
	fmt.Println("All concurrent gets done!")

	fmt.Println("-----------TESTING DONE----------")

}
