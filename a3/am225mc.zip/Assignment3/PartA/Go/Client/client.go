package main

import (
	"io"
	"net/http"
	"strings"
	"sync"
)

type Client struct {
	BaseURL string
	mu      sync.RWMutex
}

func NewClient(baseURL string) *Client {
	return &Client{
		BaseURL: baseURL,
	}
}

func (c *Client) Put(key, value string) (bool, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	URL := c.BaseURL + "/" + key
	req, err := http.NewRequest(http.MethodPut, URL, strings.NewReader(value))
	if err != nil {
		return false, err
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	return resp.StatusCode == http.StatusCreated, nil
}

func (c *Client) Get(key string) (string, bool, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	url := c.BaseURL + "/" + key
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return "", false, err
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", false, err
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusOK {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return "", false, err
		}
		return string(body), true, nil
	}

	return "", false, nil
}

func (c *Client) Delete(key string) (bool, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	URL := c.BaseURL + "/" + key
	req, err := http.NewRequest(http.MethodDelete, URL, nil)
	if err != nil {
		return false, err
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	return resp.StatusCode == http.StatusOK, nil
}
