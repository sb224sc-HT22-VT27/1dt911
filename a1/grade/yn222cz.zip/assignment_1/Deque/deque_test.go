package deque

import (
	"sync"
	"testing"
)

func TestBasicOperations(t *testing.T) {
	d := New[int]()

	if d.Len() != 0 {
		t.Fatalf("expected len 0, got %d", d.Len())
	}

	d.PushBack(10)
	d.PushFront(5)
	d.PushBack(20)

	if d.Len() != 3 {
		t.Fatalf("expected len 3, got %d", d.Len())
	}

	v, ok := d.PopFront()
	if !ok || v != 5 {
		t.Fatalf("expected PopFront = 5, true got %v, %v", v, ok)
	}

	v, ok = d.PopBack()
	if !ok || v != 20 {
		t.Fatalf("expected PopBack = 20, true got %v, %v", v, ok)
	}

	v, ok = d.PopBack()
	if !ok || v != 10 {
		t.Fatalf("expected PopBack = 10, true got %v, %v", v, ok)
	}

	_, ok = d.PopBack()
	if ok {
		t.Fatalf("expected PopBack on empty to be ok=false")
	}
}

func TestConcurrentUse(t *testing.T) {
	d := New[int]()
	var wg sync.WaitGroup

	numGoroutines := 4
	iterations := 2000

	for g := 0; g < numGoroutines; g++ {
		wg.Add(1)
		go func(base int, dq *Deque[int]) {
			defer wg.Done()
			for i := 0; i < iterations; i++ {
				dq.PushBack(base*100000 + i)
			}
		}(g, d)
	}

	for g := 0; g < numGoroutines; g++ {
		wg.Add(1)
		go func(dq *Deque[int]) {
			defer wg.Done()
			for i := 0; i < iterations; i++ {
				dq.PopFront()
			}
		}(d)
	}

	wg.Wait()

	if d.Len() != 0 {
		t.Logf("Final length is %d", d.Len())
	}
}
