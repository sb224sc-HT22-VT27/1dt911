package deque

import (
	"sync"
	"sync/atomic"
)

type node[T any] struct {
	val  T
	prev *node[T]
	next *node[T]
}

type Deque[T any] struct {
	head   *node[T]
	tail   *node[T]
	headMu sync.Mutex
	tailMu sync.Mutex
	len    atomic.Int64
}

func New[T any]() *Deque[T] {
	return &Deque[T]{}
}

func (d *Deque[T]) Len() int {
	return int(d.len.Load())
}

func (d *Deque[T]) PushFront(v T) {
	nn := &node[T]{val: v}
	d.headMu.Lock()
	defer d.headMu.Unlock()

	if d.len.Load() == 0 {
		d.tailMu.Lock()
		d.head, d.tail = nn, nn
		d.tailMu.Unlock()
	} else {
		nn.next = d.head
		if d.head != nil {
			d.head.prev = nn
		}
		d.head = nn
	}
	d.len.Add(1)
}

func (d *Deque[T]) PushBack(v T) {
	nn := &node[T]{val: v}
	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	if d.len.Load() == 0 {
		d.headMu.Lock()
		d.head, d.tail = nn, nn
		d.headMu.Unlock()
	} else {
		nn.prev = d.tail
		if d.tail != nil {
			d.tail.next = nn
		}
		d.tail = nn
	}
	d.len.Add(1)
}

func (d *Deque[T]) PopFront() (T, bool) {
	var zero T
	if d.len.Load() == 0 {
		return zero, false
	}

	d.headMu.Lock()
	defer d.headMu.Unlock()

	if d.head == nil {
		return zero, false
	}

	val := d.head.val
	if d.len.Load() == 1 {
		d.tailMu.Lock()
		d.head, d.tail = nil, nil
		d.tailMu.Unlock()
	} else {
		d.head = d.head.next
		if d.head != nil {
			d.head.prev = nil
		}
	}
	d.len.Add(-1)
	return val, true
}

func (d *Deque[T]) PopBack() (T, bool) {
	var zero T
	if d.len.Load() == 0 {
		return zero, false
	}

	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	if d.tail == nil {
		return zero, false
	}

	val := d.tail.val
	if d.len.Load() == 1 {
		d.headMu.Lock()
		d.head, d.tail = nil, nil
		d.headMu.Unlock()
	} else {
		d.tail = d.tail.prev
		if d.tail != nil {
			d.tail.next = nil
		}
	}
	d.len.Add(-1)
	return val, true
}
