package main

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"runtime"
	"sync"
)

const (
	targetHash = "4f1749bac331cf85ba1e5fa7533be35f"
	chars      = "abcdefghijklmnopqrstuvwxyz0123456789"
)

func main() {
	numWorkers := runtime.NumCPU()
	jobs := make(chan string, len(chars))
	results := make(chan string)
	done := make(chan struct{})

	var wg sync.WaitGroup

	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go worker(jobs, results, done, &wg)
	}

	go func() {
		for _, char := range chars {
			jobs <- string(char)
		}
		close(jobs)
	}()

	go func() {
		wg.Wait()
		close(results)
	}()

	if password, ok := <-results; ok {
		fmt.Printf("Lösenord funnet: %s\n", password)
		close(done)
	} else {
		fmt.Println("Kunde inte hitta lösenordet.")
	}
}

func worker(jobs <-chan string, results chan<- string, done <-chan struct{}, wg *sync.WaitGroup) {
	defer wg.Done()

	for firstChar := range jobs {
		iterate(firstChar, 5, results, done)

		select {
		case <-done:
			return
		default:
		}
	}
}

func iterate(prefix string, depth int, results chan<- string, done <-chan struct{}) {
	if depth == 0 {
		hash := md5.Sum([]byte(prefix))
		if hex.EncodeToString(hash[:]) == targetHash {
			select {
			case results <- prefix:
			case <-done:
			}
		}
		return
	}

	for i := 0; i < len(chars); i++ {
		select {
		case <-done:
			return
		default:
			iterate(prefix+string(chars[i]), depth-1, results, done)
		}
	}
}
