package main

import (
	"fmt"
	"sync"
)

func main() {
	d := New()

	var wgPush sync.WaitGroup
	var wgPop sync.WaitGroup

	for i := 0; i < 10; i++ {
		wgPush.Add(1)
		go func(n int) {
			defer wgPush.Done()
			d.PushFront(n)
			fmt.Println("Pushed Front:", n)
		}(i)
	}

	for i := 100; i < 110; i++ {
		wgPush.Add(1)
		go func(n int) {
			defer wgPush.Done()
			d.PushBack(n)
			fmt.Println("Pushed Back:", n)
		}(i)
	}

	wgPush.Wait()

	for i := 0; i < 10; i++ {
		wgPop.Add(1)
		go func() {
			defer wgPop.Done()
			v, ok := d.PopFront()
			if ok {
				fmt.Println("PopFront:", v)
			}
		}()
	}

	for i := 0; i < 10; i++ {
		wgPop.Add(1)
		go func() {
			defer wgPop.Done()
			v, ok := d.PopBack()
			if ok {
				fmt.Println("PopBack:", v)
			}
		}()
	}

	wgPop.Wait()

	fmt.Println("Final length:", d.Len())
}
