package main

import "sync"

type node struct {
	value interface{}
	prev  *node
	next  *node
	mu    sync.Mutex
}
