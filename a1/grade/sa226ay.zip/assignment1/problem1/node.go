package main

import "sync"

type node[T any] struct {
	mu   sync.Mutex
	val  T
	prev *node[T]
	next *node[T]
}
