package main

type node struct {
	value interface{}
	prev  *node
	next  *node
}
