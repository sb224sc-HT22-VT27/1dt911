package main

import (
	"sync"
	"sync/atomic"
)

type Deque struct {
	head   *node
	tail   *node
	headMu sync.Mutex
	tailMu sync.Mutex
	len    int64
}

func New() *Deque {
	return &Deque{}
}

func (d *Deque) Len() int {
	return int(atomic.LoadInt64(&d.len))
}

func (d *Deque) PushFront(v interface{}) {
	n := &node{value: v}

	d.headMu.Lock()
	defer d.headMu.Unlock()

	oldHead := d.head
	n.next = oldHead
	if oldHead != nil {
		oldHead.mu.Lock()
		oldHead.prev = n
		oldHead.mu.Unlock()
	} else {
		d.tailMu.Lock()
		d.tail = n
		d.tailMu.Unlock()
	}
	d.head = n
	atomic.AddInt64(&d.len, 1)
}

func (d *Deque) PushBack(v interface{}) {
	n := &node{value: v}

	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	oldTail := d.tail
	n.prev = oldTail
	if oldTail != nil {
		oldTail.mu.Lock()
		oldTail.next = n
		oldTail.mu.Unlock()
	} else {
		d.headMu.Lock()
		d.head = n
		d.headMu.Unlock()
	}
	d.tail = n
	atomic.AddInt64(&d.len, 1)
}

func (d *Deque) PopFront() (interface{}, bool) {
	d.headMu.Lock()
	defer d.headMu.Unlock()

	n := d.head
	if n == nil {
		return nil, false
	}

	n.mu.Lock()
	defer n.mu.Unlock()

	next := n.next
	if next != nil {
		next.mu.Lock()
		next.prev = nil
		next.mu.Unlock()
	} else {
		d.tailMu.Lock()
		d.tail = nil
		d.tailMu.Unlock()
	}
	d.head = next
	atomic.AddInt64(&d.len, -1)
	return n.value, true
}

func (d *Deque) PopBack() (interface{}, bool) {
	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	n := d.tail
	if n == nil {
		return nil, false
	}

	n.mu.Lock()
	defer n.mu.Unlock()

	prev := n.prev
	if prev != nil {
		prev.mu.Lock()
		prev.next = nil
		prev.mu.Unlock()
	} else {
		d.headMu.Lock()
		d.head = nil
		d.headMu.Unlock()
	}
	d.tail = prev
	atomic.AddInt64(&d.len, -1)
	return n.value, true
}
