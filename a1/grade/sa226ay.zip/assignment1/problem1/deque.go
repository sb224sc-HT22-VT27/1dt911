package main

import (
	"sync/atomic"
)

type Deque[T any] struct {
	head *node[T]
	tail *node[T]
	len  int64
}

func NewDeque[T any]() *Deque[T] {
	h := &node[T]{}
	t := &node[T]{}
	h.next = t
	t.prev = h
	return &Deque[T]{head: h, tail: t}
}

func (d *Deque[T]) Len() int { return int(atomic.LoadInt64(&d.len)) }

func (d *Deque[T]) PushFront(v T) {
	n := &node[T]{val: v}

	pred := d.head
	pred.mu.Lock()
	curr := pred.next
	curr.mu.Lock()

	n.prev = pred
	n.next = curr
	pred.next = n
	curr.prev = n

	curr.mu.Unlock()
	pred.mu.Unlock()
	atomic.AddInt64(&d.len, 1)
}

func (d *Deque[T]) PushBack(v T) {
	n := &node[T]{val: v}

	curr := d.tail
	curr.mu.Lock()
	pred := curr.prev
	pred.mu.Lock()

	n.prev = pred
	n.next = curr
	pred.next = n
	curr.prev = n

	pred.mu.Unlock()
	curr.mu.Unlock()
	atomic.AddInt64(&d.len, 1)
}

func (d *Deque[T]) PopFront() (T, bool) {
	var zero T

	pred := d.head
	pred.mu.Lock()
	curr := pred.next
	curr.mu.Lock()

	if curr == d.tail {
		curr.mu.Unlock()
		pred.mu.Unlock()
		return zero, false
	}

	succ := curr.next
	succ.mu.Lock()

	val := curr.val
	pred.next = succ
	succ.prev = pred

	succ.mu.Unlock()
	curr.mu.Unlock()
	pred.mu.Unlock()

	atomic.AddInt64(&d.len, -1)
	return val, true
}

func (d *Deque[T]) PopBack() (T, bool) {
	var zero T

	curr := d.tail
	curr.mu.Lock()
	pred := curr.prev
	pred.mu.Lock()

	if pred == d.head {
		pred.mu.Unlock()
		curr.mu.Unlock()
		return zero, false
	}

	ppred := pred.prev
	ppred.mu.Lock()

	val := pred.val
	ppred.next = curr
	curr.prev = ppred

	ppred.mu.Unlock()
	pred.mu.Unlock()
	curr.mu.Unlock()

	atomic.AddInt64(&d.len, -1)
	return val, true
}
