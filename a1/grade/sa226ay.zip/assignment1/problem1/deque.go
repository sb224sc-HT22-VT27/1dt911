package main

import (
	"sync"
	"sync/atomic"
)

type Deque struct {
	head   *node
	tail   *node
	headMu sync.Mutex
	tailMu sync.Mutex
	len    int64
}

func New() *Deque {
	return &Deque{}
}

func (d *Deque) Len() int {
	return int(atomic.LoadInt64(&d.len))
}

func (d *Deque) PushFront(v interface{}) {
	if atomic.LoadInt64(&d.len) == 0 {
		d.headMu.Lock()
		d.tailMu.Lock()

		if d.head == nil {
			n := &node{value: v}
			d.head = n
			d.tail = n
			atomic.AddInt64(&d.len, 1)
			d.tailMu.Unlock()
			d.headMu.Unlock()
			return
		}

		n := &node{value: v, next: d.head}
		d.head.prev = n
		d.head = n
		atomic.AddInt64(&d.len, 1)
		d.tailMu.Unlock()
		d.headMu.Unlock()
		return
	}

	d.headMu.Lock()
	n := &node{value: v, next: d.head}
	if d.head != nil {
		d.head.prev = n
	}
	d.head = n
	atomic.AddInt64(&d.len, 1)
	d.headMu.Unlock()
}

func (d *Deque) PushBack(v interface{}) {
	if atomic.LoadInt64(&d.len) == 0 {
		d.headMu.Lock()
		d.tailMu.Lock()

		if d.tail == nil {
			n := &node{value: v}
			d.head = n
			d.tail = n
			atomic.AddInt64(&d.len, 1)
			d.tailMu.Unlock()
			d.headMu.Unlock()
			return
		}

		n := &node{value: v, prev: d.tail}
		d.tail.next = n
		d.tail = n
		atomic.AddInt64(&d.len, 1)
		d.tailMu.Unlock()
		d.headMu.Unlock()
		return
	}

	d.tailMu.Lock()
	n := &node{value: v, prev: d.tail}
	if d.tail != nil {
		d.tail.next = n
	}
	d.tail = n
	atomic.AddInt64(&d.len, 1)
	d.tailMu.Unlock()
}

func (d *Deque) PopFront() (v interface{}, ok bool) {
	if atomic.LoadInt64(&d.len) == 1 {
		d.headMu.Lock()
		d.tailMu.Lock()

		if d.head == nil {
			d.tailMu.Unlock()
			d.headMu.Unlock()
			return nil, false
		}
		n := d.head
		if d.head == d.tail {
			d.head = nil
			d.tail = nil
		} else {
			d.head = n.next
			if d.head != nil {
				d.head.prev = nil
			}
		}
		atomic.AddInt64(&d.len, -1)
		d.tailMu.Unlock()
		d.headMu.Unlock()
		return n.value, true
	}

	d.headMu.Lock()
	if d.head == nil {
		d.headMu.Unlock()
		return nil, false
	}

	n := d.head
	if d.head == d.tail {
		d.headMu.Unlock()
		return d.PopFront()
	}

	d.head = n.next
	if d.head != nil {
		d.head.prev = nil
	}
	atomic.AddInt64(&d.len, -1)
	d.headMu.Unlock()
	return n.value, true
}

func (d *Deque) PopBack() (v interface{}, ok bool) {
	if atomic.LoadInt64(&d.len) == 1 {
		d.headMu.Lock()
		d.tailMu.Lock()

		if d.tail == nil {
			d.tailMu.Unlock()
			d.headMu.Unlock()
			return nil, false
		}
		n := d.tail
		if d.head == d.tail {
			d.head = nil
			d.tail = nil
		} else {
			d.tail = n.prev
			if d.tail != nil {
				d.tail.next = nil
			}
		}
		atomic.AddInt64(&d.len, -1)
		d.tailMu.Unlock()
		d.headMu.Unlock()
		return n.value, true
	}

	d.tailMu.Lock()
	if d.tail == nil {
		d.tailMu.Unlock()
		return nil, false
	}

	n := d.tail
	if d.head == d.tail {
		d.tailMu.Unlock()
		return d.PopBack()
	}

	d.tail = n.prev
	if d.tail != nil {
		d.tail.next = nil
	}
	atomic.AddInt64(&d.len, -1)
	d.tailMu.Unlock()
	return n.value, true
}
