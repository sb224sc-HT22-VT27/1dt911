package main

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"runtime"
	"sync"
	"time"
)

const (
	length = 6
	TARGET = "4f1749bac331cf85ba1e5fa7533be35f"
)

func idxToStr(idx uint64) string {
	buf := make([]byte, length)
	for i := length - 1; i >= 0; i-- {
		d := idx % 36
		idx /= 36
		if d < 26 {
			buf[i] = byte('a' + d)
		} else {
			buf[i] = byte('0' + (d - 26))
		}
	}
	return string(buf)
}

func pow36(n int) uint64 {
	p := uint64(1)
	for i := 0; i < n; i++ {
		p *= 36
	}
	return p
}

func equalBytes(a, b []byte) bool {
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func worker(ctx context.Context, wg *sync.WaitGroup, start, step uint64, target []byte, results chan<- string) {
	defer wg.Done()

	total := pow36(length)
	for i := start; i < total; i += step {
		select {
		case <-ctx.Done():
			return
		default:
			s := idxToStr(i)
			h := md5.Sum([]byte(s))
			if equalBytes(h[:], target) {
				select {
				case results <- s:
				case <-ctx.Done():
				}
				return
			}
		}
	}
}

func runWithWorkers(n int) (string, time.Duration) {
	target, _ := hex.DecodeString(TARGET)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	results := make(chan string, 1)
	var wg sync.WaitGroup

	start := time.Now()

	for i := 0; i < n; i++ {
		wg.Add(1)
		go worker(ctx, &wg, uint64(i), uint64(n), target, results)
	}

	var password string
	select {
	case password = <-results:
		cancel()
	case <-ctx.Done():
	}

	wg.Wait()
	return password, time.Since(start)
}

func main() {
	workerCounts := []int{6, 8, 10, 12, 14, 16, 18, 20, runtime.NumCPU()}

	var bestTime time.Duration = 1<<63 - 1
	bestWorkers := 0
	var cracked string

	for _, workers := range workerCounts {
		fmt.Printf("\nRunning with %d goroutines...\n", workers)
		pass, duration := runWithWorkers(workers)
		fmt.Printf("Password: %s | Time: %v\n", pass, duration)

		if duration < bestTime {
			bestTime = duration
			bestWorkers = workers
			cracked = pass
		}
	}

	fmt.Printf("Password cracked: %s\n", cracked)
	fmt.Printf("Optimal goroutines: %d\n", bestWorkers)
	fmt.Printf("Best time: %v\n", bestTime)
}
