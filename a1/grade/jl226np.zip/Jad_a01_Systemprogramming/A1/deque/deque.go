package deque

import (
	"fmt"
	"sync"
)

type node[T any] struct {
	value T
	prev  *node[T]
	next  *node[T]
	mu    sync.Mutex
}

type Deque[T any] struct {
	head   *node[T]
	tail   *node[T]
	headMu sync.Mutex
	tailMu sync.Mutex
	length int
	lenMu  sync.Mutex
}

// Constructor
func New[T any]() *Deque[T] {
	return &Deque[T]{}
}

func (d *Deque[T]) PushFront(v T) {
	n := &node[T]{value: v}

	d.headMu.Lock()
	defer d.headMu.Unlock()

	if d.head == nil {
		d.tailMu.Lock()
		d.head = n
		d.tail = n
		d.tailMu.Unlock()
	} else {
		oldHead := d.head
		oldHead.mu.Lock()

		n.next = oldHead
		oldHead.prev = n
		d.head = n

		oldHead.mu.Unlock()
	}

	d.lenMu.Lock()
	d.length++
	d.lenMu.Unlock()
}

func (d *Deque[T]) PushBack(v T) {
	n := &node[T]{value: v}

	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	if d.tail == nil {
		d.headMu.Lock()
		d.head = n
		d.tail = n
		d.headMu.Unlock()
	} else {
		oldTail := d.tail
		oldTail.mu.Lock()

		n.prev = oldTail
		oldTail.next = n
		d.tail = n

		oldTail.mu.Unlock()
	}

	d.lenMu.Lock()
	d.length++
	d.lenMu.Unlock()
}

func (d *Deque[T]) PopFront() (T, bool) {
	var zero T

	d.headMu.Lock()
	if d.head == nil {
		d.headMu.Unlock()
		return zero, false
	}

	oldHead := d.head
	oldHead.mu.Lock()

	if oldHead.next == nil {
		d.tailMu.Lock()
		d.head = nil
		d.tail = nil
		d.tailMu.Unlock()

		oldHead.mu.Unlock()
		d.headMu.Unlock()
	} else {
		next := oldHead.next
		next.mu.Lock()

		next.prev = nil
		d.head = next

		next.mu.Unlock()
		oldHead.mu.Unlock()
		d.headMu.Unlock()
	}

	d.lenMu.Lock()
	d.length--
	d.lenMu.Unlock()

	return oldHead.value, true
}

func (d *Deque[T]) PopBack() (T, bool) {
	var zero T

	d.tailMu.Lock()
	if d.tail == nil {
		d.tailMu.Unlock()
		return zero, false
	}

	oldTail := d.tail
	oldTail.mu.Lock()

	if oldTail.prev == nil {
		d.headMu.Lock()
		d.tail = nil
		d.head = nil
		d.headMu.Unlock()

		oldTail.mu.Unlock()
		d.tailMu.Unlock()
	} else {
		prev := oldTail.prev
		prev.mu.Lock()

		prev.next = nil
		d.tail = prev

		prev.mu.Unlock()
		oldTail.mu.Unlock()
		d.tailMu.Unlock()
	}

	d.lenMu.Lock()
	d.length--
	d.lenMu.Unlock()

	return oldTail.value, true
}

func (d *Deque[T]) Length() int {
	d.lenMu.Lock()
	defer d.lenMu.Unlock()
	return d.length
}

func (d *Deque[T]) PrintDeque() {
	fmt.Print("[")
	for curr := d.head; curr != nil; curr = curr.next {
		fmt.Printf("%v", curr.value)
		if curr.next != nil {
			fmt.Print(" ")
		}
	}
	fmt.Println("]")
}
