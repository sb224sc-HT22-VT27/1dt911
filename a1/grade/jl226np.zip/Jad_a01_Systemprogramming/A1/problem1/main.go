package main

import (
	"A1/deque"
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	d := deque.New[int]()
	for i := 0; i < 30; i++ {
		v := rand.Intn(200)

		if rand.Intn(2) == 0 {
			fmt.Println("Pushed Front:", v)
			d.PushFront(v)
		} else {
			fmt.Println("Pushed Back:", v)
			d.PushBack(v)
		}
	}

	for i := 0; i < 30; i++ {
		if rand.Intn(2) == 0 {
			val, ok := d.PopFront()
			if ok {
				fmt.Println("PopFront:", val)
			}
		} else {
			val, ok := d.PopBack()
			if ok {
				fmt.Println("PopBack:", val)
			}
		}
	}

	for {
		val, ok := d.PopFront()
		if !ok {
			break
		}
		fmt.Println("PopFront:", val)
	}

	fmt.Println("Final length:", d.Length())
}
