package cracker

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"strings"
	"sync/atomic"
	"time"
)

const targetHash = "4f1749bac331cf85ba1e5fa7533be35f"
const charset = "abcdefghijklmnopqrstuvwxyz0123456789"

func worker(id, workers int, found *int32, result chan<- string) {
	n := len(charset)
	var sb strings.Builder

	for a := id; a < n && atomic.LoadInt32(found) == 0; a += workers {
		for b := 0; b < n && atomic.LoadInt32(found) == 0; b++ {
			for c := 0; c < n && atomic.LoadInt32(found) == 0; c++ {
				for d := 0; d < n && atomic.LoadInt32(found) == 0; d++ {
					for e := 0; e < n && atomic.LoadInt32(found) == 0; e++ {
						for f := 0; f < n && atomic.LoadInt32(found) == 0; f++ {

							sb.Reset()
							sb.WriteByte(charset[a])
							sb.WriteByte(charset[b])
							sb.WriteByte(charset[c])
							sb.WriteByte(charset[d])
							sb.WriteByte(charset[e])
							sb.WriteByte(charset[f])

							pwd := sb.String()
							hash := md5.Sum([]byte(pwd))

							if hex.EncodeToString(hash[:]) == targetHash {
								if atomic.CompareAndSwapInt32(found, 0, 1) {
									result <- pwd
								}
								return
							}
						}
					}
				}
			}
		}
	}
}

func runWithWorkers(workers int) (string, time.Duration) {
	var found int32 = 0
	result := make(chan string, 1)

	start := time.Now()

	for w := 0; w < workers; w++ {
		go worker(w, workers, &found, result)
	}

	password := <-result
	duration := time.Since(start)

	return password, duration
}

func Run() {
	fmt.Println("Starting password cracking benchmarks...")
	fmt.Println("------------------------------------------------")

	for workers := 10; workers <= 20; workers++ {
		fmt.Printf("Testing with %d goroutines...\n", workers)
		pwd, duration := runWithWorkers(workers)

		fmt.Printf("Password FOUND: %s\n", pwd)
		fmt.Printf("Time: %v\n", duration)
		fmt.Println("------------------------------------------------")
	}
}
