package main

import (
	"A1/problem2/cracker"
)

func main() {
	cracker.Run()
}
