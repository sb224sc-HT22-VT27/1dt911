package main

import (
	"A1/deque"
	"fmt"
	"math/rand"
	"runtime"
	"runtime/pprof"
	"sync"
	"sync/atomic"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	fmt.Println("========== DEMO OUTPUT (Push/Pop logg) ==========")

	d := deque.New[int]()

	for i := 0; i < 30; i++ {
		v := rand.Intn(200)

		if rand.Intn(2) == 0 {
			fmt.Println("Pushed Front:", v)
			d.PushFront(v)
		} else {
			fmt.Println("Pushed Back:", v)
			d.PushBack(v)
		}
	}

	fmt.Println("Length after pushes:", d.Length())

	for i := 0; i < 30; i++ {
		if rand.Intn(2) == 0 {
			val, ok := d.PopFront()
			if ok {
				fmt.Println("PopFront:", val)
			}
		} else {
			val, ok := d.PopBack()
			if ok {
				fmt.Println("PopBack:", val)
			}
		}
	}

	for {
		val, ok := d.PopFront()
		if !ok {
			break
		}
		fmt.Println("PopFront:", val)
	}

	fmt.Println("Final length:", d.Length())

	fmt.Println("\n========== CONCURRENCY TEST (RESULTS + THREADS) ==========")

	d2 := deque.New[int]()

	const workers = 8
	const opsPerWorker = 1000

	var pushes atomic.Int64
	var pops atomic.Int64

	fmt.Println("GOMAXPROCS:", runtime.GOMAXPROCS(0))
	fmt.Println("NumCPU:", runtime.NumCPU())
	fmt.Println("Goroutines at start:", runtime.NumGoroutine())
	fmt.Println("Starting workers:", workers)

	var wg sync.WaitGroup
	wg.Add(workers)

	done := make(chan struct{})
	go func() {
		ticker := time.NewTicker(200 * time.Millisecond)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				threadsCreated := 0
				if p := pprof.Lookup("threadcreate"); p != nil {
					threadsCreated = p.Count()
				}

				fmt.Printf("[LIVE] goroutines=%d | osThreadsCreated=%d | pushes=%d | pops=%d\n",
					runtime.NumGoroutine(),
					threadsCreated,
					pushes.Load(),
					pops.Load(),
				)
			case <-done:
				return
			}
		}
	}()

	for id := 0; id < workers; id++ {
		go func(workerID int) {
			defer wg.Done()

			r := rand.New(rand.NewSource(time.Now().UnixNano() + int64(workerID)))

			for i := 0; i < opsPerWorker; i++ {
				action := r.Intn(4)

				switch action {
				case 0:
					d2.PushFront(r.Intn(1000))
					pushes.Add(1)
				case 1:
					d2.PushBack(r.Intn(1000))
					pushes.Add(1)
				case 2:
					if _, ok := d2.PopFront(); ok {
						pops.Add(1)
					}
				case 3:
					if _, ok := d2.PopBack(); ok {
						pops.Add(1)
					}
				}

				if i%200 == 0 {
					time.Sleep(time.Microsecond * time.Duration(r.Intn(200)))
				}
			}
		}(id)
	}

	wg.Wait()
	close(done)

	fmt.Println("\n=== RESULTS ===")
	fmt.Println("Total pushes:", pushes.Load())
	fmt.Println("Total pops:", pops.Load())
	fmt.Println("Final length (computed traversal):", d2.Length())

	remaining := 0
	for {
		if _, ok := d2.PopFront(); !ok {
			break
		}
		remaining++
	}

	fmt.Println("Remaining drained elements:", remaining)
	fmt.Println("Final length after drain:", d2.Length())

	threadsCreated := 0
	if p := pprof.Lookup("threadcreate"); p != nil {
		threadsCreated = p.Count()
	}
	fmt.Println("OS threads created (total):", threadsCreated)
	fmt.Println("Goroutines at end:", runtime.NumGoroutine())
}
