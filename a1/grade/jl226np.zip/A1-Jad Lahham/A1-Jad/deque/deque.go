package deque

import "sync"

type node[T any] struct {
	value T
	prev  *node[T]
	next  *node[T]
	mu    sync.Mutex
}

type Deque[T any] struct {
	head *node[T]
	tail *node[T]
}

func New[T any]() *Deque[T] {
	h := &node[T]{}
	return &Deque[T]{head: h, tail: h}
}

func (d *Deque[T]) PushFront(v T) {
	n := &node[T]{value: v}

	d.head.mu.Lock()
	defer d.head.mu.Unlock()

	first := d.head.next
	if first != nil {
		first.mu.Lock()
		defer first.mu.Unlock()
	}

	n.prev = d.head
	n.next = first
	d.head.next = n

	if first != nil {
		first.prev = n
	} else {
		d.tail = n
	}
}

func (d *Deque[T]) PushBack(v T) {
	n := &node[T]{value: v}

	pred := d.head
	pred.mu.Lock()

	curr := pred.next
	if curr == nil {
		n.prev = pred
		n.next = nil
		pred.next = n
		d.tail = n
		pred.mu.Unlock()
		return
	}

	curr.mu.Lock()

	for curr.next != nil {
		next := curr.next
		next.mu.Lock()

		pred.mu.Unlock()
		pred = curr
		curr = next
	}

	n.prev = curr
	n.next = nil
	curr.next = n
	d.tail = n

	curr.mu.Unlock()
	pred.mu.Unlock()
}

func (d *Deque[T]) PopFront() (T, bool) {
	var zero T

	d.head.mu.Lock()
	defer d.head.mu.Unlock()

	first := d.head.next
	if first == nil {
		return zero, false
	}

	first.mu.Lock()
	defer first.mu.Unlock()

	second := first.next

	if second != nil {
		second.mu.Lock()
		second.prev = d.head
		second.mu.Unlock()

		d.head.next = second
	} else {
		d.head.next = nil
		d.tail = d.head
	}

	return first.value, true
}

func (d *Deque[T]) PopBack() (T, bool) {
	var zero T

	pred := d.head
	pred.mu.Lock()

	curr := pred.next
	if curr == nil {
		pred.mu.Unlock()
		return zero, false
	}

	curr.mu.Lock()

	for curr.next != nil {
		next := curr.next
		next.mu.Lock()

		pred.mu.Unlock()
		pred = curr
		curr = next
	}

	pred.next = nil
	d.tail = pred

	val := curr.value
	curr.mu.Unlock()
	pred.mu.Unlock()

	return val, true
}

func (d *Deque[T]) Length() int {
	count := 0

	pred := d.head
	pred.mu.Lock()

	curr := pred.next
	for curr != nil {
		curr.mu.Lock()
		pred.mu.Unlock()

		count++

		pred = curr
		curr = curr.next
	}

	pred.mu.Unlock()
	return count
}
