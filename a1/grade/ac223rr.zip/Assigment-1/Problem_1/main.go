package main

import "sync"

type node[T any] struct {
	value T
	prev  *node[T]
	next  *node[T]
	mu    sync.Mutex
}

type Deque[T any] struct {
	head *node[T]
	tail *node[T]
}

// create an empty deque with no real elements in between
func NewDeque[T any]() *Deque[T] {
	h := &node[T]{}
	t := &node[T]{}
	h.next = t
	t.prev = h
	return &Deque[T]{head: h, tail: t}
}

// counts the number of elements in the deque.
func (d *Deque[T]) Len() int {
	d.head.mu.Lock() // while walking through the list lock both sentinels so that no push/pop can change the ends
	d.tail.mu.Lock()
	defer d.tail.mu.Unlock()
	defer d.head.mu.Unlock()

	n := 0
	// walk from first real node until we reach the tail
	for cur := d.head.next; cur != d.tail; cur = cur.next {
		n++
	}
	return n
}

// checks if the deque has no real elements
func (d *Deque[T]) IsEmpty() bool {
	// lock head so that head next cannot change while checking
	d.head.mu.Lock()
	defer d.head.mu.Unlock()
	return d.head.next == d.tail
}

// insert a new value at the front of the deque
func (d *Deque[T]) PushFront(v T) {
	d.head.mu.Lock() // lock the head to change head.next.
	first := d.head.next

	// case 1: deque is empty
	if first == d.tail { // update head and tail
		d.tail.mu.Lock()

		newN := &node[T]{value: v, prev: d.head, next: d.tail}
		d.head.next = newN
		d.tail.prev = newN

		d.tail.mu.Unlock()
		d.head.mu.Unlock()
		return
	}

	// case 2: deque already has at least one element
	first.mu.Lock()

	newN := &node[T]{value: v, prev: d.head, next: first}
	d.head.next = newN // modify head and the old first node
	first.prev = newN

	first.mu.Unlock()
	d.head.mu.Unlock()
}

// remove and returns the first element
func (d *Deque[T]) PopFront() (T, bool) {
	var zero T
	// lock head to safely read and modify head.next
	d.head.mu.Lock()
	first := d.head.next
	// case 1: empty deque
	if first == d.tail {
		d.head.mu.Unlock()
		return zero, false
	}

	// case 2: exactly one element
	if first.next == d.tail {
		d.tail.mu.Lock()
		first.mu.Lock()

		val := first.value
		d.head.next = d.tail
		d.tail.prev = d.head

		first.mu.Unlock()
		d.tail.mu.Unlock()
		d.head.mu.Unlock()
		return val, true
	}

	// case 3: at least two elements.
	first.mu.Lock()
	second := first.next // remove first by linking head directly to second
	second.mu.Lock()

	val := first.value
	d.head.next = second
	second.prev = d.head

	second.mu.Unlock()
	first.mu.Unlock()
	d.head.mu.Unlock()
	return val, true
}

// insert a new value at the back of the deque.
func (d *Deque[T]) PushBack(v T) {
	// Start at tail end.
	d.tail.mu.Lock() // lock the tail sentinel to change tail.prev
	last := d.tail.prev

	// case 1: deque is empty
	if last == d.head {
		d.tail.mu.Unlock()

		d.head.mu.Lock() // lock both
		d.tail.mu.Lock()

		// check after acquiring both locks.
		if d.head.next == d.tail {
			newN := &node[T]{value: v, prev: d.head, next: d.tail}
			d.head.next = newN
			d.tail.prev = newN

			d.tail.mu.Unlock()
			d.head.mu.Unlock()
			return
		}

		// something else inserted meanwhile; continue as normal case.
		d.head.mu.Unlock()
		last = d.tail.prev
	}

	// case 2: deque already has elements.
	last.mu.Lock()

	newN := &node[T]{value: v, prev: last, next: d.tail}
	last.next = newN // modify last and tail
	d.tail.prev = newN

	last.mu.Unlock()
	d.tail.mu.Unlock()
}

//  remove and returns the last element.
func (d *Deque[T]) PopBack() (T, bool) {
	var zero T

	// lock tail to safely read and modify
	d.tail.mu.Lock()
	last := d.tail.prev

	// case 1: empty deque
	if last == d.head {
		d.tail.mu.Unlock()
		return zero, false
	}

	// case 2: exactly one element
	if last.prev == d.head {
		d.tail.mu.Unlock()
		d.head.mu.Lock()
		d.tail.mu.Lock()

		// check after acquiring both locks.
		last = d.tail.prev
		if last == d.head {
			d.tail.mu.Unlock()
			d.head.mu.Unlock()
			return zero, false
		}

		last.mu.Lock()
		val := last.value
		d.tail.prev = d.head
		d.head.next = d.tail

		last.mu.Unlock()
		d.tail.mu.Unlock()
		d.head.mu.Unlock()
		return val, true
	}

	// case 3: at least two elements.
	last.mu.Lock()
	before := last.prev // remove last by linking tail directly to the node before it.
	before.mu.Lock()

	val := last.value
	d.tail.prev = before
	before.next = d.tail

	before.mu.Unlock()
	last.mu.Unlock()
	d.tail.mu.Unlock()
	return val, true
}

//  return the first value without removing it
func (d *Deque[T]) PeekFront() (T, bool) {
	var zero T
	// lock head so head.next cannot change while  reading it.
	d.head.mu.Lock()
	first := d.head.next

	if first == d.tail {
		d.head.mu.Unlock()
		return zero, false
	}
	// lock the first real node before reading its value
	first.mu.Lock()
	val := first.value

	first.mu.Unlock()
	d.head.mu.Unlock()
	return val, true
}

// return the last value without removing it.
func (d *Deque[T]) PeekBack() (T, bool) {
	var zero T
	d.tail.mu.Lock() // lock tail so tail.prev cannot change while reading it.
	last := d.tail.prev

	if last == d.head {
		d.tail.mu.Unlock()
		return zero, false
	}
	// lock the last real node before reading its value.
	last.mu.Lock()
	val := last.value

	last.mu.Unlock()
	d.tail.mu.Unlock()
	return val, true
}
