package main

import (
	"fmt"
	"sync"
	"time"
)

// a single node in the deque.
// each node stores a value and pointers to the previous and next nodes.
type node[T any] struct {
	value T
	prev  *node[T]
	next  *node[T]
}

type Deque[T any] struct {
	head *node[T] // first elemen
	tail *node[T] // last element
	size int

	frontMu sync.Mutex // protect operations on the front (head)
	backMu  sync.Mutex // protect oporations on the back (tail)
	sizeMu  sync.Mutex // protect the size counter
}

// create an empty deque.
func NewDeque[T any]() *Deque[T] {
	return &Deque[T]{}
}

// add a new element to the front of the deque.
func (d *Deque[T]) PushFront(value T) {
	// create a new node to insert
	n := &node[T]{value: value}
	// first lock the size, because size determines which case we are in
	d.sizeMu.Lock()
	// case 1: deque is empty
	if d.size == 0 {
		//  must lock both ends because head and tail will both change
		d.frontMu.Lock()
		d.backMu.Lock()

		d.head = n
		d.tail = n
		d.size = 1

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return
	}
	// case 2: deque has exactly one element
	if d.size == 1 {
		d.frontMu.Lock()
		d.backMu.Lock()
		// new node becomes the head
		n.next = d.head
		d.head.prev = n
		d.head = n
		d.size++

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return
	}
	// case 3: deque has 2 or more elements (only the front pointer changes)
	d.size++
	d.frontMu.Lock()
	d.sizeMu.Unlock()

	n.next = d.head
	d.head.prev = n
	d.head = n

	d.frontMu.Unlock()
}

// add a new element to the back of the deque.
func (d *Deque[T]) PushBack(value T) {
	n := &node[T]{value: value}

	d.sizeMu.Lock()
	// case 1: empty deque
	if d.size == 0 {
		d.frontMu.Lock()
		d.backMu.Lock()

		d.head = n
		d.tail = n
		d.size = 1

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return
	}
	// case 2: one element
	if d.size == 1 {
		d.frontMu.Lock()
		d.backMu.Lock()

		n.prev = d.tail
		d.tail.next = n
		d.tail = n
		d.size++

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return
	}
	// case 3: two or more elements
	d.size++
	d.backMu.Lock()
	d.sizeMu.Unlock()

	n.prev = d.tail
	d.tail.next = n
	d.tail = n

	d.backMu.Unlock()
}

// remove and returnr the element at the front of the deque.
func (d *Deque[T]) PopFront() (value T, ok bool) {
	d.sizeMu.Lock()

	// case 1: empty deque
	if d.size == 0 {
		d.sizeMu.Unlock()
		return value, false
	}
	// case 2: one element
	if d.size == 1 {
		d.frontMu.Lock()
		d.backMu.Lock()

		value = d.head.value
		d.head = nil
		d.tail = nil
		d.size = 0

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return value, true
	}
	// case 3: exactly two elements
	if d.size == 2 {
		d.frontMu.Lock()
		d.backMu.Lock()

		value = d.head.value
		d.head = d.tail
		d.head.prev = nil
		d.tail.next = nil
		d.size--

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return value, true
	}
	// case 4: more than two elements
	d.size--
	d.frontMu.Lock()
	d.sizeMu.Unlock()

	n := d.head
	value = n.value
	d.head = n.next
	d.head.prev = nil

	d.frontMu.Unlock()
	return value, true
}

// remove and return the element at the back of the deque.
func (d *Deque[T]) PopBack() (value T, ok bool) {
	d.sizeMu.Lock()
	// case 1: empty deque
	if d.size == 0 {
		d.sizeMu.Unlock()
		return value, false
	}
	// case 2: one element
	if d.size == 1 {
		d.frontMu.Lock()
		d.backMu.Lock()

		value = d.tail.value
		d.head = nil
		d.tail = nil
		d.size = 0

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return value, true
	}
	// case 3: exactly two elements
	if d.size == 2 {
		d.frontMu.Lock()
		d.backMu.Lock()

		value = d.tail.value
		d.tail = d.head
		d.tail.next = nil
		d.head.prev = nil
		d.size--

		d.backMu.Unlock()
		d.frontMu.Unlock()
		d.sizeMu.Unlock()
		return value, true
	}
	// case 4: more than two elements
	d.size--
	d.backMu.Lock()
	d.sizeMu.Unlock()

	n := d.tail
	value = n.value
	d.tail = n.prev
	d.tail.next = nil

	d.backMu.Unlock()
	return value, true
}

// return the current number of elements in the deque.
func (d *Deque[T]) Len() int {
	d.sizeMu.Lock()         // lock to make sure we read the size safely if other goroutines are pushing or popping at the same time
	defer d.sizeMu.Unlock() // automatically unlock at the end
	return d.size
}

// show the internal state of the deque
func (d *Deque[T]) PrintState() {
	// lock everything because reading multiple shared variables:
	d.frontMu.Lock()
	d.backMu.Lock()
	d.sizeMu.Lock()
	// print the sequence of elements from head to tail
	fmt.Print("Deque: ")

	curr := d.head
	for curr != nil {
		fmt.Print(curr.value, " ")
		curr = curr.next
	}

	fmt.Println()
	fmt.Println("  head:", valueOrNil(d.head))
	fmt.Println("  tail:", valueOrNil(d.tail))
	fmt.Println("  size:", d.size)
	fmt.Println()
	// unlock all mutexes after reading
	d.sizeMu.Unlock()
	d.backMu.Unlock()
	d.frontMu.Unlock()
}

// if the node is (empty) prints "nil" instead of causing an error or print the value stored in the node.
func valueOrNil[T any](n *node[T]) any {
	if n == nil {
		return "nil"
	}
	return n.value
}

// test
func main() {
	dq := NewDeque[int]() // create a new deque that stores integers
	var wg sync.WaitGroup // wait until all goroutines finish

	wg.Add(3) // 3 goroutines, so set the counter to 3

	// goroutine 1 push elements to the front
	go func() {
		defer wg.Done() // notify when this goroutine is done
		// push 1 to the front of the deque
		fmt.Println("[G1] PushFront(1)")
		dq.PushFront(1)

		dq.PrintState() // print the current state of the deque

		// push 2 to the front of the deque
		fmt.Println("[G1] PushFront(2)")
		dq.PushFront(2)
		dq.PrintState()
	}()

	// goroutine 2 push elements to the back
	go func() {
		defer wg.Done()

		// push 10 to the back of the deque
		fmt.Println("[G2] PushBack(10)")
		dq.PushBack(10)
		dq.PrintState()

		// push 20 to the back of the deque
		fmt.Println("[G2] PushBack(20)")
		dq.PushBack(20)
		dq.PrintState()
	}()

	// goroutine 3 pop elements from front and back
	go func() {
		defer wg.Done()

		// Add a small delay so that some pushes happen firstt so this makes the output easier to follow
		time.Sleep(50 * time.Millisecond)

		// pop one element from the front
		fmt.Println("[G3] PopFront()")
		if v, ok := dq.PopFront(); ok {
			fmt.Println("  popped:", v)
		}
		dq.PrintState()

		fmt.Println("[G3] PopBack()")
		if v, ok := dq.PopBack(); ok {
			fmt.Println("  popped:", v)
		}
		dq.PrintState()
	}()
	// wait until all goroutines are done
	wg.Wait()

	// print the final size of the deque
	fmt.Println("Final size:", dq.Len())
}
