package main

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"sync"
	"time"
)

var hashToCrack = "4f1749bac331cf85ba1e5fa7533be35f"
var passwordSize = 6                                              // password length is exactly 6 characters
var allowedChars = []byte("abcdefghijklmnopqrstuvwxyz0123456789") // the  allowed characters in the password

// compute the MD5 hash of a string and returns it as a hex string
func makeHash(text string) string {
	hash := md5.Sum([]byte(text))
	return hex.EncodeToString(hash[:])
}

// each worker receives prefixes and tries all possible suffixes.
func crackWorker(
	prefixChannel <-chan string, // a channel that gives prefixes to work on
	remainingLength int, // length of suffix to brute-force
	foundPassword chan<- string, // channel used to report success
	stopSignal <-chan struct{}, // channel used to stop all workers early
	waitGroup *sync.WaitGroup, // used to signal when the worker is done
) {
	defer waitGroup.Done() // let main know this worker exits

	charCount := len(allowedChars)

	// read prefixes until the channel is closed
	for prefix := range prefixChannel {
		charIndexes := make([]int, remainingLength)
		done := false

		// generate all possible suffix combinations and check if another goroutine already found the password
		for !done {
			select {
			case <-stopSignal:
				return
			default:
			}

			// build the suffix string using current indexes
			suffix := make([]byte, remainingLength)
			for i := 0; i < remainingLength; i++ {
				suffix[i] = allowedChars[charIndexes[i]]
			}
			// combine prefix and suffix to form full password
			passwordTry := prefix + string(suffix)
			// hash the password and compare it, then send the found password
			if makeHash(passwordTry) == hashToCrack {
				select {
				case foundPassword <- passwordTry:
				default:
				}
				return
			}

			// increment the suffix counter to next combination
			for i := remainingLength - 1; i >= 0; i-- {
				charIndexes[i]++
				if charIndexes[i] < charCount {
					break
				}
				charIndexes[i] = 0
				if i == 0 {
					done = true // all combinations tried
				}
			}
		}
	}
}

// run the cracker using a fixed number of goroutines and split the password into (two-character prefix / four-character suffix)
func runTest(numberOfGoroutines int) (string, time.Duration) {
	prefixLength := 2
	suffixLength := passwordSize - prefixLength
	prefixChannel := make(chan string, 1500) // sends prefixes to workers
	foundPassword := make(chan string, 1)    // receives cracked password
	stopSignal := make(chan struct{})        // signals workers to stop
	var waitGroup sync.WaitGroup

	startTime := time.Now()

	// generate all two character prefixes
	go func() {
		defer close(prefixChannel)
		for _, a := range allowedChars {
			for _, b := range allowedChars {
				select {
				case prefixChannel <- string([]byte{a, b}):
				case <-stopSignal:
					return
				}
			}
		}
	}()

	// start goroutines
	for i := 0; i < numberOfGoroutines; i++ {
		waitGroup.Add(1)
		go crackWorker(
			prefixChannel,
			suffixLength,
			foundPassword,
			stopSignal,
			&waitGroup,
		)
	}

	// close the result channel once all goroutines are done
	go func() {
		waitGroup.Wait()
		close(foundPassword)
	}()
	// wait for a password to be found (or goroutine to finish)
	password, ok := <-foundPassword
	// stop all goroutines once result is known
	close(stopSignal)

	elapsedTime := time.Since(startTime)

	if ok {
		return password, elapsedTime
	}
	return "", elapsedTime
}

func main() {
	goroutineTests := []int{16} // test different numbers of goroutines

	fmt.Println("MD5 Password Cracker")
	fmt.Println("--------------------------------------")

	for _, count := range goroutineTests {
		password, timeTaken := runTest(count)

		fmt.Printf(
			"Goroutines: %2d | Time: %-10v | Password: %s\n",
			count,
			timeTaken,
			password,
		)
	}
}
