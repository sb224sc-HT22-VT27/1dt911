Assignment 1 
Parallel programering in GO

This project contains  problem 1 and problem 2 of programering Assignment 1.
-------------------------------------------------------------------------------

The problem 1 is about Thread safe deque:
The code is in File : pro_1.GO

Description:

This implements a thread safe, queue using a doubly linked list with fine grained.
Each node has its own lock, allowing multiple goroutines to operate on different parts of the deque simultaneously.
The implementation uses atomic operations for size tracking to minimze lock contention.

How to run the program:
go run pro_1.go
----------------------------------------------------------------------------------------------

The problem 2 is about Parallel password cracker
The code is in File: pro_2.go

Description:
This implements a Parallel password cracker using goroutines and channels to fin a six character password (a-z, 0-9) from a given MD5 hash" 4f1749bac331cf85ba1e5fa7533be35f"

How to run the program:
go run pro_2.go


sources:

I used:
Go dokumentation
https://gobyexample.com/
lectures:
processes and threads: https://moodle.lnu.se/mod/resource/view.php?id=5025430
channels in Go: https://moodle.lnu.se/mod/resource/view.php?id=5040194
Deadlocks: https://moodle.lnu.se/mod/resource/view.php?id=5044614
Atomics, Lock-and Wait-free: https://moodle.lnu.se/mod/resource/view.php?id=5049692


