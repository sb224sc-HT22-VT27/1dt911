package main

import (
	"crypto/md5"
	"fmt"
	"sync"
	"time"
)

const T_hash = "4f1749bac331cf85ba1e5fa7533be35f"

var chrs = []byte("abcdefghijklmnopqrstuvwxyz0123456789")

func md5_stringen(s_ string) string {
	su := md5.Sum([]byte(s_))
	return fmt.Sprintf("%x", su)
}

func w_serch(st_ int, en_ int, foun chan<- string, stop <-chan struct{}, wg *sync.WaitGroup) {
	defer wg.Done()

	for i := st_; i < en_; i++ {
		for j := 0; j < len(chrs); j++ {
			for k := 0; k < len(chrs); k++ {
				for a := 0; a < len(chrs); a++ {
					for m := 0; m < len(chrs); m++ {
						for d := 0; d < len(chrs); d++ {
							select {
							case <-stop:
								return
							default:
							}

							p_ := string([]byte{chrs[i], chrs[j], chrs[k], chrs[a], chrs[m], chrs[d]})
							if md5_stringen(p_) == T_hash {
								select {
								case foun <- p_:
								case <-stop:

								}
								return
							}
						}
					}
				}
			}
		}

	}
}

func main() {
	work := 4

	star_T := time.Now()
	foun := make(chan string, 1)
	stop := make(chan struct{})

	var wg sync.WaitGroup
	part_dels := len(chrs) / work
	st_ := 0

	for w_ := 0; w_ < work; w_++ {
		en_ := st_ + part_dels
		if w_ == work-1 {
			en_ = len(chrs)
		}
		wg.Add(1)
		go w_serch(st_, en_, foun, stop, &wg)
		st_ = en_
	}
	go func() {
		wg.Wait()
		close(foun)
	}()

	pwd, ok := <-foun
	close(stop)

	if ok {
		fmt.Println("The password is founded: ", pwd)
	} else {
		fmt.Println("The passwored is not founded! ")

	}
	fmt.Println("The workers: ", work)
	fmt.Println("The time is : ", time.Since(star_T))
}
