package main

import (
	"fmt"
	"sync"
	"sync/atomic"
)

// skapa nod, för att vi behöver en nod som kan peka framt och bakåt

type N struct {
	v    int
	nex  *N         // pek på noden after
	prv  *N         // pek på noden före
	lock sync.Mutex /// varje node har sitt eget lås så fine grained locking

}

// skapa deque structen

type Deq struct {
	fron   *N
	bak    *N
	sz     int64
	f_lock sync.Mutex
	b_lock sync.Mutex
}

// skapa constructor alltså start med tom deque

func Nw_deq() *Deq {
	return &Deq{}

}

// Pushfront med fine grained locking, ska skapa pushfront(x) med hjälp av lecture
func (d *Deq) PshFron(x int) {
	n := &N{v: x}
	d.f_lock.Lock()

	if d.fron == nil {
		//om deque är tom så det måste sätta både front och back

		d.b_lock.Lock()
		d.fron = n
		d.bak = n
		d.b_lock.Unlock()

	} else {
		d.fron.lock.Lock()
		n.nex = d.fron
		d.fron.prv = n
		old_fron := d.fron
		d.fron = n
		old_fron.lock.Unlock()
	}
	d.f_lock.Unlock()
	atomic.AddInt64(&d.sz, 1) // använder här atomic istället för s_lock
}

// push back med fine grained locking
func (d *Deq) PshBak(x int) {
	n := &N{v: x}

	d.b_lock.Lock()

	if d.bak == nil {
		/// deque är tom
		d.f_lock.Lock()
		d.fron = n
		d.bak = n
		d.f_lock.Unlock()

	} else {
		d.bak.lock.Lock()
		n.prv = d.bak
		d.bak.nex = n
		old_bak := d.bak
		d.bak = n
		old_bak.lock.Unlock()
	}
	d.b_lock.Unlock()
	atomic.AddInt64(&d.sz, 1)
}

// skapar popfront med fine gradined locking
func (d *Deq) PpFron() (int, bool) {
	d.f_lock.Lock()

	if d.fron == nil {
		d.f_lock.Unlock()
		return -1, false

	}
	d.fron.lock.Lock()
	vl := d.fron.v
	nex_N := d.fron.nex
	d.fron = d.fron.nex
	d.fron.lock.Unlock()

	d.fron = nex_N
	if d.fron == nil {
		// blivit tom så måste också då nolla back
		d.b_lock.Lock()
		d.bak = nil
		d.b_lock.Unlock()

	} else {
		d.fron.lock.Lock()
		d.fron.prv = nil
		d.fron.lock.Unlock()
	}
	d.f_lock.Unlock()
	atomic.AddInt64(&d.sz, -1)

	return vl, true
}

// popback function med fine gradined locking

func (d *Deq) PpBak() (int, bool) {
	d.b_lock.Lock()

	if d.bak == nil {
		d.b_lock.Unlock()
		return -1, false
	}

	d.bak.lock.Lock()
	vl := d.bak.v
	pre_N := d.bak.prv
	d.bak.lock.Unlock()

	d.bak = pre_N
	if d.bak == nil {
		d.f_lock.Lock()
		d.fron = nil
		d.f_lock.Unlock()

	} else {
		d.bak.lock.Lock()
		d.bak.nex = nil
		d.bak.lock.Unlock()
	}

	d.b_lock.Unlock()
	atomic.AddInt64(&d.sz, -1)

	return vl, true
}
func (d *Deq) Size() int64 {
	return atomic.LoadInt64(&d.sz)
}

func main() {
	d := Nw_deq()
	d.PshFron(3)
	d.PshBak(5)
	d.PshFron(9)

	x, _ := d.PpBak()

	fmt.Println("The PopBack is: ", x)

	y, _ := d.PpFron()
	fmt.Println("The PopFront is : ", y)
	fmt.Println("The current  size is :", d.Size())
}
