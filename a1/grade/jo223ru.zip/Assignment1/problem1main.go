package main

import (
	"fmt"
	"sync"
	
)

// en person i kön
type Nod struct{

	värde string 
	föreg *Nod
	nästa *Nod

	
}

// dubbelkön = deque
type Dubbelkö struct{

	låsFram sync.Mutex // låser framme
	låsBak sync.Mutex // låser bak
	fram *Nod // första personen
	bak *Nod // sista personen
	antal int // hur många person som finnsi kön



	
}

//NyKö skapar en tom ny kö
func NyKö() *Dubbelkö{

	return &Dubbelkö{}
	
}

// LäggFram lägger till perosn lägst fram ikön, där k = kö(deque) och v = värde(strängen man lägger in i könn)  
func (k *Dubbelkö) LäggFram(v string){

	k.låsFram.Lock()
	defer k.låsFram.Unlock()
	nyNod := &Nod{värde: v}

	if k.fram == nil{

		k.låsBak.Lock()
		k.fram = nyNod
		k.bak = nyNod 
		k.låsBak.Unlock()
	}else{

		nyNod.nästa = k.fram
		k.fram.föreg = nyNod // föregående nod(föreg)
		k.fram = nyNod
		

		
	}
	k.antal++








	
}

// LäggBak lägger till person längst bak i kön
func (k *Dubbelkö) LäggBak(v string){

	k.låsBak.Lock()
	defer k.låsBak.Unlock()

	nyNod := &Nod{värde : v}
	if k.bak == nil{ // om tom

		k.låsFram.Lock()
		k.fram = nyNod
		k.bak = nyNod
		k.låsFram.Unlock()
	}else{

		nyNod.föreg = k.bak
		k.bak.nästa = nyNod
		k.bak = nyNod
	}
	k.antal++
}

//TaFram tar bort första personn i kön
func (k *Dubbelkö) TaFram() (string, bool){


	k.låsFram.Lock()
	defer k.låsFram.Unlock()

	if k.fram == nil{

		return "", false
	}

	värde := k.fram.värde

	if k.fram.nästa == nil{ // om personen är den första

		k.låsBak.Lock()
		k.fram = nil
		k.bak = nil
		k.låsBak.Unlock()
	}else{

		k.fram = k.fram.nästa 
		k.fram.föreg = nil 
	}
	k.antal--
	return värde, true
}

//TaBak tar bort siste personen i klön
func (k *Dubbelkö) TaBak() (string, bool){

	k.låsBak.Lock()
	defer k.låsBak.Unlock()
	if k.bak == nil{
		return "", false
	}
	värde := k.bak.värde

	if k.bak.föreg == nil{ // om det ej finns en person bakom den sista så är den personen den sista

		k.låsFram.Lock()
		k.fram = nil
		k.bak = nil
		k.låsFram.Unlock()
		


		
	}else{
		k.bak = k.bak.föreg
		k.bak.nästa = nil
	}
	k.antal--
	return värde, true
}

// Antal -> antalet personener i kön
func (k *Dubbelkö) Antal() int{

	k.låsFram.Lock()
	defer k.låsFram.Unlock()
	return k.antal 
}

//ÄrTom -> kollar om kön om tom eller inte
func (k *Dubbelkö) ÄrTom() bool{

	k.låsFram.Lock()
	defer k.låsFram.Unlock()
	return k.antal == 0
}

func main(){

	kö := NyKö()
	var wg sync.WaitGroup

	// första testet: lägg till personer i kön
	fmt.Println("test 1 -> lägg till personer")
	for i := 0; i < 5; i++{

		wg.Add(1)
		go func(id int){

			defer wg.Done()
			kö.LäggFram(fmt.Sprintf("Fram-%d", id))
			kö.LäggBak(fmt.Sprintf("Bak-%d", id))
		}(i)
	}

	wg.Wait()
	fmt.Printf("Antal i kön: %d\n", kö.Antal())

	// andra testet -> ta bort personer från kön
	fmt.Println("\nTest 2-> Tar bort personer")

	for i := 0;i < 3; i++{

		wg.Add(2)
		go func(){

			defer wg.Done()
			if v, ok := kö.TaFram(); ok{

				fmt.Printf("Tog fram -> %s\n", v)
			}
		}()
		go func() {


			defer wg.Done()
			if v, ok := kö.TaBak(); ok{
				fmt.Printf("Tog bak -> %s\n", v)
			}
			
		}()


		
	}

	wg.Wait()
	fmt.Printf("Antal i kön: %d\n", kö.Antal())
}
