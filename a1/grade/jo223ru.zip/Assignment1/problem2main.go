package main

import (
	"fmt" 
	"encoding/hex" // konvertera MD5 hash till hex sträng
	"crypto/md5" // beräkna MD5 hash
	"sync" // för WaitGroup för att vänta på gorotines
	"time" // mäta tid
)

func hash(s string) string{ // tar sträng och retuerar dess MD5 hash som hex sträng

	sum := md5.Sum([]byte(s))
	return hex.EncodeToString(sum[:])

	
}

func arbetare(start, slut int, målet string, resultat chan<- string, wg *sync.WaitGroup){ // testar lösenord inom ett interval(arbetare)

	defer wg.Done() // markerar gorotine som klar när funktionen är färdig
	tecken := "abcdefghijklmnopqrstuvwxyz0123456789"
	for n := start; n < slut; n++{

		x := n
		lösen := make([]byte, 6) // lösenordet är angivet att vara 6 tecken

		// kovertera nummer till 6 tecken lösenord
		for i := 5; i>=0; i--{

			lösen[i] = tecken[x%36]
			x /= 36
		}

		if hash(string(lösen)) ==målet{ //beräkna hash och jämför det med det målet
			resultat <- string(lösen) // skicka hittat lösenord till kanal
			return // sluta arbetaren när lösenordet har blvit hittat
		}
	} 

	
}

func main(){

	måletsHash := "4f1749bac331cf85ba1e5fa7533be35f" // hashen som ska knäckas
	totalt := 36*36 * 36 *36*36 *36 // totalt antal kombinationer 36^6
	arbetarLista := []int{1,2,4} // antalet gorotines att testa
	fmt.Println("<------Pararel lösenordknäckare------>")

	for _, antal := range arbetarLista{

		fmt.Printf("\n<----Testar med %d goroutlines--->",antal)
		start := time.Now() // starttid för tidmätningen
		resultat := make(chan string, 1) // kanal för att skicka det hittade lösenordet
		var wg sync.WaitGroup // WaitGroup för att vänta på alla goritiens
		del := totalt / antal // dela upp arbetet mellan gorotines
		for i := 0; i < antal; i++{

			s := i* del // startindex för arbetaren
			e := s+del  // slutindex
			if i == antal-1{ // sista arbetaren tar resten


				e = totalt
			}

			wg.Add(1)
			go arbetare(s, e,måletsHash, resultat, &wg) // starta goroutine
		}

		go func(){ // stänger lamaöem mär alla gorotines är klara 
			wg.Wait()
			close(resultat)
		}()

		hittat := ""
		if lösen, ok := <-resultat; ok{ // läs resultat från kanalen om löseenordet har blvit hittats

			hittat = lösen
		}

		tid := time.Since(start) // beräkna hur långt det tod
		if hittat != ""{

			fmt.Printf("Hittat på %v\n", tid) // format specifiera med printf
			fmt.Printf("Lösenordet är ->%s\n", hittat) //println så enkelt mellan slag
			break
		}else{
			fmt.Printf("Inte hittat på %v\n", tid) // om lösenordet inte har blivit hittad(denna ska dock aldrig köras/hända)
		}
	}

	
}

