package src

import (
	"strconv"
	"strings"
	"sync"
)

type LLNode struct {
	value int
	prev  *LLNode
	next  *LLNode
	mutex sync.Mutex
}

type LL struct {
	head  *LLNode
	tail  *LLNode
	size  int
	mutex sync.Mutex
}

var Ll = &LL{}

func Problem_1() *LL {
	Ll.head = nil
	Ll.tail = nil
	Ll.size = 0
	return Ll
}

func (ll *LL) Add_last(new_element int) {
	newNode := &LLNode{value: new_element}
	
	ll.mutex.Lock()
	if ll.head == nil {
		ll.head = newNode
		ll.tail = newNode
		ll.size = 1
		ll.mutex.Unlock()
		return
	}
	
	tail := ll.tail
	ll.mutex.Unlock()
	
	tail.mutex.Lock()
	newNode.mutex.Lock()
	
	tail.next = newNode
	newNode.prev = tail
	
	tail.mutex.Unlock()
	
	ll.mutex.Lock()
	ll.tail = newNode
	ll.size++
	ll.mutex.Unlock()
	
	newNode.mutex.Unlock()
}

func (ll *LL) Add_first(new_element int) {
	newNode := &LLNode{value: new_element}
	
	ll.mutex.Lock()
	if ll.head == nil {
		ll.head = newNode
		ll.tail = newNode
		ll.size = 1
		ll.mutex.Unlock()
		return
	}
	
	head := ll.head
	ll.mutex.Unlock()
	
	newNode.mutex.Lock()
	head.mutex.Lock()
	
	newNode.next = head
	head.prev = newNode
	
	head.mutex.Unlock()
	
	ll.mutex.Lock()
	ll.head = newNode
	newNode.mutex.Unlock()
	ll.size++
	ll.mutex.Unlock()
	
}

func (ll *LL) Pop_last() (int, bool) {
	ll.mutex.Lock()
	
	if ll.size == 0 {
		ll.mutex.Unlock()
		return 0, false
	}
	
	if ll.size == 1 {
		tail := ll.tail
		if tail == nil {
			ll.mutex.Unlock()
			return 0, false
		}
		ll.mutex.Unlock()
		tail.mutex.Lock()
		value := tail.value
		tail.mutex.Unlock()

		ll.mutex.Lock()
		ll.head = nil
		ll.tail = nil
		ll.size = 0
		ll.mutex.Unlock()
		return value, true
	}
	
	tail := ll.tail
	prev := tail.prev
	ll.mutex.Unlock()

	if tail == nil || prev == nil {
		return 0, false
	}
	
	prev.mutex.Lock()
	tail.mutex.Lock()
	
	value := tail.value
	tail.mutex.Unlock()
	prev.next = nil
	
	ll.mutex.Lock()
	ll.tail = prev
	prev.mutex.Unlock()
	ll.size--
	ll.mutex.Unlock()
	
	return value, true
}

func (ll *LL) Pop_first() (int, bool) {
	ll.mutex.Lock()
	
	if ll.size == 0 {
		ll.mutex.Unlock()
		return -1, false
	}
	
	if ll.size == 1 {
		head := ll.head
		ll.mutex.Unlock()
		if head == nil { 
			return -1, false
		}
		
		head.mutex.Lock()
		value := head.value
		head.mutex.Unlock()

		ll.mutex.Lock()
		ll.head = nil
		ll.tail = nil
		ll.size = 0
		ll.mutex.Unlock()
		return value, true
	}
	
	head := ll.head
	next := head.next
	ll.mutex.Unlock()
	
	if head == nil || next == nil {
		return -1, false
	}
	
	head.mutex.Lock()
	
	value := head.value
	head.mutex.Unlock()
	next.mutex.Lock()
	next.prev = nil
	
	ll.mutex.Lock()
	ll.head = next
	next.mutex.Unlock()
	ll.size--
	ll.mutex.Unlock()
	
	
	return value, true
}

func (ll *LL) To_string() string {
	ll.mutex.Lock()
	head := ll.head
	ll.mutex.Unlock()
	
	var b strings.Builder
	b.WriteString("{")
	
	node := head
	for node != nil {
		node.mutex.Lock()
		b.WriteString(strconv.Itoa(node.value))
		next := node.next
		node.mutex.Unlock()
		
		if next != nil {
			b.WriteString(", ")
		}
		node = next
	}
	
	b.WriteString("}")
	return b.String()
}