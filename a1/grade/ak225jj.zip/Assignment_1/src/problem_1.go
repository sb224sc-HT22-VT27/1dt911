package src

import (
	"strconv"
	"strings"
	"sync"
)

type LLNode struct {
	value int
	prev  *LLNode
	next  *LLNode
	mutex sync.Mutex
}

type LL struct {
	head *LLNode
	tail *LLNode
	// size  int // ta bort
	//mutex sync.Mutex // ta bort  TODO: ska fortfarande funka
}

var Ll = &LL{}

func Problem_1() *LL {
	head := &LLNode{}
	tail := &LLNode{}

	head.next = tail
	tail.prev = head

	Ll.head = head
	Ll.tail = tail

	return Ll
}

func (ll *LL) Add_last(new_element int) {
	newNode := &LLNode{value: new_element}

	for {
		ll.tail.mutex.Lock()

		pred := ll.tail.prev
		pred.mutex.Lock()

		if ll.tail.prev == pred && pred.next == ll.tail {
			newNode.prev = pred
			newNode.next = ll.tail
			pred.next = newNode
			ll.tail.prev = newNode

			pred.mutex.Unlock()
			ll.tail.mutex.Unlock()
			return
		}

		pred.mutex.Unlock()
		ll.tail.mutex.Unlock()
	}
}

func (ll *LL) Add_first(new_element int) {
	newNode := &LLNode{value: new_element}

	for {
		ll.head.mutex.Lock()

		succ := ll.head.next
		succ.mutex.Lock()

		if ll.head.next == succ && succ.prev == ll.head {
			newNode.next = succ
			newNode.prev = ll.head
			succ.prev = newNode
			ll.head.next = newNode

			succ.mutex.Unlock()
			ll.head.mutex.Unlock()
			return
		}

		succ.mutex.Unlock()
		ll.head.mutex.Unlock()
	}
}

func (ll *LL) Pop_last() (int, bool) {
	for {
		ll.tail.mutex.Lock()

		node := ll.tail.prev
		if node == ll.head {
			ll.tail.mutex.Unlock()
			return 0, false
		}

		node.mutex.Lock()

		pred := node.prev
		pred.mutex.Lock()

		if ll.tail.prev == node && node.next == ll.tail && node.prev == pred {
			value := node.value
			pred.next = ll.tail
			ll.tail.prev = pred

			pred.mutex.Unlock()
			node.mutex.Unlock()
			ll.tail.mutex.Unlock()

			return value, true
		}

		pred.mutex.Unlock()
		node.mutex.Unlock()
		ll.tail.mutex.Unlock()
	}
}

func (ll *LL) Pop_first() (int, bool) {
	for {
		ll.head.mutex.Lock()

		node := ll.head.next
		if node == ll.tail {
			ll.head.mutex.Unlock()
			return 0, false
		}
		node.mutex.Lock()
		succ := node.next
		succ.mutex.Lock()

		if ll.head.next == node && node.prev == ll.head && node.next == succ {
			value := node.value
			ll.head.next = succ
			succ.prev = ll.head

			succ.mutex.Unlock()
			node.mutex.Unlock()
			ll.head.mutex.Unlock()
			return value, true
		}
		node.mutex.Unlock()
		succ.mutex.Unlock()
		ll.head.mutex.Unlock()
	}
}

func (ll *LL) To_string() string {

	var b strings.Builder
	b.WriteString("{")

	curr := ll.head.next

	for curr != ll.tail {
		curr.mutex.Lock()

		b.WriteString(strconv.Itoa(curr.value))

		next := curr.next
		curr.mutex.Unlock()

		if next != ll.tail {
			b.WriteString(", ")
		}
		curr = next
	}

	b.WriteString("}")
	return b.String()
}
