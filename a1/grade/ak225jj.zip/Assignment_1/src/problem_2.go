package src

import (
	"crypto/md5"
	"fmt"
	"sync"
	"sync/atomic"
)

type pw_worker struct {
	hash     string
	length   int
	start    int64
	end      int64
	pw_chan  chan string
	charset  string
	char_len int
	id       int
	stop     *int32
}

func Problem_2(hash string, length int, workers int) string {
	var pw_chan = make(chan string, 1)
	var wg sync.WaitGroup
	var stop int32 = 0

	charset := "abcdefghijklmnopqrstuvwxyz0123456789"
	char_len := len(charset)

	total_combinations := int64(1)
	for range length {
		total_combinations *= int64(char_len)
	}

	work_per_worker := total_combinations / int64(workers)
	
	for i := range workers {
		start := work_per_worker * int64(i)
		end := start + work_per_worker
		
		if i == workers-1 {
			end = total_combinations
		}

		wg.Add(1)
		go func(worker_id int, start_idx, end_idx int64) {
			defer wg.Done()
			worker := &pw_worker{
				hash:     hash,
				length:   length,
				start:    start_idx,
				end:      end_idx,
				pw_chan:  pw_chan,
				charset:  charset,
				char_len: char_len,
				id:       worker_id,
				stop:     &stop,
			}
			worker.bf_optimized()
		}(i, start, end)
	}

	var found_password string
	go func() {
		wg.Wait()
		close(pw_chan)
	}()

	found_password = <-pw_chan
	
	if found_password == "" {
		fmt.Println("Password not found!")
	} else {
		fmt.Printf("Password found! Password: %s\n", found_password)
	}
	
	return found_password
}

func (pw *pw_worker) bf_optimized() {
	current := pw.start
	
	for current < pw.end {
		if atomic.LoadInt32(pw.stop) != 0 {
			return
		}
		
		password := pw.index_to_password(current)
		
		if pw.check_password(password) {
			atomic.StoreInt32(pw.stop, 1)
			pw.pw_chan <- password
			return
		}
		
		current++
	}
}

func (pw *pw_worker) index_to_password(index int64) string {
	// Convert linear index to base-36 representation
	result := make([]byte, pw.length)
	
	for i := pw.length - 1; i >= 0; i-- {
		result[i] = pw.charset[index%int64(pw.char_len)]
		index /= int64(pw.char_len)
	}
	
	return string(result)
}

func (pw *pw_worker) check_password(password string) bool {
	hash := md5.Sum([]byte(password))
	return fmt.Sprintf("%x", hash) == pw.hash
}