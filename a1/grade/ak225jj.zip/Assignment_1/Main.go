package main

import (
	"assignment1/src"
	"crypto/md5"
	"fmt"
	"sync"
	"time"
)

func testLinkedList() {

	linkedList := src.Problem_1()
	var wg sync.WaitGroup

	// Lägg till 20 element
	n := 20
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func(count int) {
			linkedList.Add_last(count)
			wg.Done()
		}(i)
	}
	wg.Wait()
	fmt.Println("After Add_last (20 elements):", linkedList.To_string())

	// Poppa 3 från slutet
	wg.Add(3)
	for i := 0; i < 3; i++ {
		go func(count int) {
			linkedList.Pop_last()
			wg.Done()
		}(i)
	}
	wg.Wait()
	fmt.Println("After Pop_last (3 elements):", linkedList.To_string())

	// Lägg till 2 i början
	wg.Add(2)
	for i := 0; i < 2; i++ {
		go func(count int) {
			linkedList.Add_first(count)
			wg.Done()
		}(i)
	}
	wg.Wait()
	fmt.Println("After Add_first (2 elements):", linkedList.To_string())

	// Poppa 3 från början
	wg.Add(3)
	for i := 0; i < 3; i++ {
		go func(count int) {
			linkedList.Pop_first()
			wg.Done()
		}(i)
	}
	wg.Wait()
	fmt.Println("After Pop_first (3 elements):", linkedList.To_string())

	// Alla operationer samtidigt
	m := 3
	wg.Add(m*4)
	for i := 0; i < m; i++ {
		go func(count int) {
			linkedList.Pop_first()
			wg.Done()
		}(i)
		
		go func(count int) {
			linkedList.Add_first(count)
			wg.Done()
		}(i)
		
		go func(count int) {
			linkedList.Pop_last()
			wg.Done()
		}(i)
		
		go func(count int) {
			linkedList.Add_last(count)
			wg.Done()
		}(i)
	}
	
	wg.Wait()
	fmt.Println("After everything:", linkedList.To_string())

}

func test_md5() {
	hash := "4f1749bac331cf85ba1e5fa7533be35f"
	length := 6

	fmt.Println("Starting password cracker...")
	fmt.Printf("Target hash: %s\n", hash)
	fmt.Printf("Password length: %d\n", length)

	workers := 8

	fmt.Printf("\n=== Testing with %d workers ===\n", workers)

	result_chan := make(chan string, 1)

	go func() {
		password := src.Problem_2(hash, length, workers)
		result_chan <- password
	}()

	select {
	case password := <-result_chan:
		if password != "" {
			fmt.Printf("\nPassword found: %s\n", password)

			fmt.Printf("Verifying hash...\n")
			verified := verify_hash(password, hash)
			if verified {
				fmt.Println("Hash verification successful!")
			}
		} else {
			fmt.Println("\nPassword not found")
		}
	case <-time.After(60 * time.Second):
		fmt.Println("\nTimeout after 60 seconds")
	}
}

func verify_hash(password, expected_hash string) bool {

	hash := md5.Sum([]byte(password))
	actual_hash := fmt.Sprintf("%x", hash)
	return actual_hash == expected_hash
}

func main() {
	for i := 0; i < 10000; i++ {
		testLinkedList()
	}
	//test_md5()

}
