package main

import (
	"fmt"
	"sync"
)

type Node struct {
	Value int
	Prev  *Node
	Next  *Node
	lock  sync.Mutex
}

type Deque struct {
	head *Node
	tail *Node
}

// Create deque with sentinel nodes
func NewDeque() *Deque {
	head := &Node{}
	tail := &Node{}

	head.Next = tail
	tail.Prev = head

	return &Deque{
		head: head,
		tail: tail,
	}
}

func (d *Deque) Addfront(value int) {
	pred := d.head
	pred.lock.Lock()

	curr := pred.Next
	curr.lock.Lock()

	newNode := &Node{
		Value: value,
		Prev:  pred,
		Next:  curr,
	}

	pred.Next = newNode
	curr.Prev = newNode

	curr.lock.Unlock()
	pred.lock.Unlock()
}

func (d *Deque) Addback(value int) {
	succ := d.tail
	succ.lock.Lock()

	curr := succ.Prev
	curr.lock.Lock()

	newNode := &Node{
		Value: value,
		Prev:  curr,
		Next:  succ,
	}

	curr.Next = newNode
	succ.Prev = newNode

	curr.lock.Unlock()
	succ.lock.Unlock()
}

func (d *Deque) Removefront() int {
	pred := d.head
	pred.lock.Lock()

	curr := pred.Next
	curr.lock.Lock()

	if curr == d.tail {
		curr.lock.Unlock()
		pred.lock.Unlock()
		return 0
	}

	succ := curr.Next

	pred.Next = succ
	succ.Prev = pred

	curr.lock.Unlock()
	pred.lock.Unlock()

	return curr.Value
}

func (d *Deque) Removeback() int {
	succ := d.tail
	succ.lock.Lock()

	curr := succ.Prev
	curr.lock.Lock()

	if curr == d.head {
		curr.lock.Unlock()
		succ.lock.Unlock()
		return 0
	}

	pred := curr.Prev

	pred.Next = succ
	succ.Prev = pred

	curr.lock.Unlock()
	succ.lock.Unlock()

	return curr.Value
}

func (d *Deque) String() string {
	result := ""
	node := d.head.Next
	for node != d.tail {
		result += fmt.Sprintf("%d ", node.Value)
		node = node.Next
	}
	return result
}

func main() {
	d := NewDeque()

	fmt.Println("Sequential test")
	d.Addfront(10)
	d.Addback(20)
	d.Addfront(5)
	d.Addback(30)

	fmt.Println(d.String())

	fmt.Println(d.Removefront()) // 5
	fmt.Println(d.Removeback())  // 30
	fmt.Println(d.Removefront()) // 10
	fmt.Println(d.Removeback())  // 20

	var wg sync.WaitGroup

	fmt.Println("Concurrent test")

	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			d.Addfront(id)
			d.Addback(id + 1000)
			d.Removefront()
			d.Removeback()
		}(i)
	}

	wg.Wait()

	fmt.Println("Done. No crash → node locking works.")
}
