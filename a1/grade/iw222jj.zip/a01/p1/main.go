package main

import (
	"fmt"
	"sync"
)

type Node struct {
	Value int
	Prev  *Node
	Next  *Node
}

type Deque struct {
	head     *Node
	tail     *Node
	headLock sync.Mutex
	tailLock sync.Mutex
}

func (d *Deque) Addfront(value int) {
	d.headLock.Lock()
	newNode := &Node{Value: value}

	if d.head == nil {
		d.tailLock.Lock()
		d.head = newNode
		d.tail = newNode
		d.tailLock.Unlock()
		d.headLock.Unlock()
		return
	}

	newNode.Next = d.head
	d.head.Prev = newNode
	d.head = newNode

	d.headLock.Unlock()
}

func (d *Deque) Addback(value int) {
	d.headLock.Lock()
	d.tailLock.Lock()

	newNode := &Node{Value: value}

	if d.tail == nil {
		d.head = newNode
		d.tail = newNode
		d.tailLock.Unlock()
		d.headLock.Unlock()
		return
	}

	// Normal case: only tail changed
	newNode.Prev = d.tail
	d.tail.Next = newNode
	d.tail = newNode

	d.tailLock.Unlock()
	d.headLock.Unlock()
}

func (d *Deque) Removefront() int {
	d.headLock.Lock()
	defer d.headLock.Unlock()

	if d.head == nil {
		return 0
	}

	value := d.head.Value
	d.head = d.head.Next

	if d.head != nil {
		d.head.Prev = nil
		return value
	}

	// Deque becomes empty
	d.tailLock.Lock()
	d.tail = nil
	d.tailLock.Unlock()

	return value
}

func (d *Deque) Removeback() int {
	d.headLock.Lock()
	d.tailLock.Lock()

	if d.tail == nil {
		d.tailLock.Unlock()
		d.headLock.Unlock()
		return 0
	}

	value := d.tail.Value
	d.tail = d.tail.Prev

	if d.tail != nil {
		d.tail.Next = nil
	} else {
		d.head = nil
	}

	d.tailLock.Unlock()
	d.headLock.Unlock()

	return value
}

func main() {
	d := Deque{}

	fmt.Println("Test: PushFront / PushBack")
	d.Addfront(10) // [10]
	d.Addback(20)  // [10, 20]
	d.Addfront(5)  // [5, 10, 20]
	d.Addback(30)  // [5, 10, 20, 30]

	fmt.Println("Removefront (should be 5):")
	v := d.Removefront()
	fmt.Println(v)

	fmt.Println("Removeback (should be 30):")
	v = d.Removeback()
	fmt.Println(v)

	fmt.Println("Removefront (shoudls be 10):")
	v = d.Removefront()
	fmt.Println(v)

	fmt.Println("Removeback (should be 20):")
	v = d.Removeback()
	fmt.Println(v)

	var wg sync.WaitGroup

	// Starta 100 goroutines som alla jobbar med dequen
	for i := 0; i < 100; i++ {
		wg.Add(1)

		go func(id int) {
			defer wg.Done()

			// Varje goroutine gör operationer med varje funktion
			d.Addfront(id)
			d.Addback(id + 1000)
			d.Removefront()
			d.Removeback()

		}(i)
	}

	wg.Wait()

	fmt.Println("Klar! Programmet kraschade inte → låsningen fungerar.")
}
