package main

import (
	"fmt"
	"sync"
	"time"
)

type semaphore struct {
	max   int
	count int
	lock  sync.Mutex
	cond  *sync.Cond
}

func newSemaphore(n int) *semaphore {
	s := &semaphore{
		count: n,
		max:   n,
	}
	s.cond = sync.NewCond(&s.lock)
	return s
}

func (s *semaphore) AcquireKey() {
	s.lock.Lock()
	for s.count == 0 {
		s.cond.Wait()
	}
	s.count -= 1
	s.lock.Unlock()
}

func (s *semaphore) ReleaseKey() {
	s.lock.Lock()
	s.count += 1
	s.cond.Signal()
	s.lock.Unlock()
}

func main() {
	N := 2
	sem := newSemaphore(N)

	var wg sync.WaitGroup

	for i := 1; i <= 5; i++ { // Run 5 routines
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			fmt.Printf("Goroutine %d: trying to enter critical section\n", id)
			sem.AcquireKey()
			fmt.Printf("Goroutine %d: entered critical section\n", id)

			time.Sleep(2 * time.Second)

			fmt.Printf("Goroutine %d: leaving critical section\n", id)
			sem.ReleaseKey()
		}(i)
	}

	wg.Wait()
	fmt.Println("All goroutines finished")
}
