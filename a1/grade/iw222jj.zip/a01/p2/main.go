package main

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"time"
)

func md5hash(s string) string {
	h := md5.Sum([]byte(s))
	return hex.EncodeToString(h[:])
}

func crack(startingLetter string, chars string, target string, found chan string, cancel <-chan struct{}) {
	var s string

	for _, c2 := range chars {
		for _, c3 := range chars {
			for _, c4 := range chars {
				for _, c5 := range chars {
					for _, c6 := range chars {

						select {
						case <-cancel:
							return
						default:
						}

						s = startingLetter + string(c2) + string(c3) +
							string(c4) + string(c5) + string(c6)

						if md5hash(s) == target {
							found <- s
							return
						}
					}
				}
			}
		}
	}
}

func main() {
	chars := "abcdefghijklmnopqrstuvwxyz0123456789"
	targetHash := "4f1749bac331cf85ba1e5fa7533be35f"

	workers := 1

	found := make(chan string)
	cancel := make(chan struct{})

	runes := []rune(chars)
	total := len(runes)

	chunk := (total + workers - 1) / workers

	start := time.Now()

	// Start worker goroutines
	for i := 0; i < total; i += chunk {
		end := i + chunk
		if end > total {
			end = total
		}

		batch := string(runes[i:end])

		go func(batch string) {
			for _, c1 := range batch {
				select {
				case <-cancel:
					return
				default:
				}
				crack(string(c1), chars, targetHash, found, cancel)
			}
		}(batch)
	}

	password := <-found
	close(cancel)

	fmt.Println("Password found:", password)
	fmt.Println("Time:", time.Since(start))
}
