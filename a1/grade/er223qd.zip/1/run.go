package main

import (
	"fmt"
	"sync"
)

type Element struct {
	val  interface{}
	prev *Element
	next *Element
	mu   sync.Mutex
}

type Deque struct {
	head      *Element
	tail      *Element
	size      int
	size_lock sync.Mutex
}

func NewDeque() *Deque {
	h := &Element{}
	t := &Element{}
	h.next = t
	t.prev = h
	return &Deque{head: h, tail: t}
}

func (d *Deque) pushFront(val interface{}) {
	prev := d.head
	prev.mu.Lock()

	curr := prev.next
	curr.mu.Lock()

	newElement := &Element{}
	newElement.val = val
	newElement.prev = prev
	newElement.next = curr

	prev.next = newElement
	curr.prev = newElement

	d.size_lock.Lock()
	d.size++
	d.size_lock.Unlock()

	curr.mu.Unlock()
	prev.mu.Unlock()
}

func (d *Deque) pushBack(val interface{}) {
	succ := d.tail
	succ.mu.Lock()

	curr := succ.prev
	curr.mu.Lock()

	newElement := &Element{}
	newElement.val = val
	newElement.prev = curr
	newElement.next = succ

	curr.next = newElement
	succ.prev = newElement

	d.size_lock.Lock()
	d.size++
	d.size_lock.Unlock()

	curr.mu.Unlock()
	succ.mu.Unlock()
}
func (d *Deque) popFront() interface{} {
	prev := d.head
	prev.mu.Lock()

	curr := prev.next
	curr.mu.Lock()

	if curr == d.tail {
		curr.mu.Unlock()
		prev.mu.Unlock()
		return nil
	}

	succ := curr.next

	prev.mu.Unlock()

	prev.next = succ
	succ.prev = prev
	d.size_lock.Lock()
	d.size--
	d.size_lock.Unlock()

	curr.mu.Unlock()

	return curr.val
}

func (d *Deque) popBack() interface{} {
	succ := d.tail
	succ.mu.Lock()

	curr := succ.prev
	curr.mu.Lock()

	if curr == d.head {
		curr.mu.Unlock()
		succ.mu.Unlock()
		return nil
	}

	prev := curr.prev

	succ.mu.Unlock()

	prev.next = succ
	succ.prev = prev

	d.size_lock.Lock()
	d.size--
	d.size_lock.Unlock()

	curr.mu.Unlock()

	return curr.val
}

func (d *Deque) length() int {
	d.size_lock.Lock()
	defer d.size_lock.Unlock()
	return d.size
}

func main() {
	deque := NewDeque()

	var wg sync.WaitGroup
	antal_element := 1000

	for i := 0; i < antal_element; i++ {
		wg.Add(1)
		go func(v int) {
			defer wg.Done()
			deque.pushFront(v)
		}(i)
	}

	for i := 0; i < antal_element; i++ {
		wg.Add(1)
		go func(v int) {
			defer wg.Done()
			deque.pushBack(v)
		}(i)
	}

	wg.Wait()

	fmt.Println("Längden innan bortagning", deque.length())

	for i := 0; i < antal_element; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			deque.popFront()
		}()
	}

	for i := 0; i < antal_element; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			deque.popBack()
		}()
	}

	wg.Wait()

	fmt.Println("Längden efter bortagning", deque.length())

}
