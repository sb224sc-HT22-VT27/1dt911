package main

import (
	"fmt"
	"sync"
)

type node struct {
	value  interface{}
	prev *node
	next *node
}

type Deque struct {
	head    *node
	tail    *node
	frontMu sync.Mutex
	backMu  sync.Mutex
	lenMu   sync.Mutex
	length  int
}


func NewDeque() *Deque {
	return &Deque{}
}

func (d *Deque) PushFront(value interface{}) {
	d.frontMu.Lock()
	n := &node{value: value}

	if d.head == nil {
		d.backMu.Lock()
		d.head = n
		d.tail = n
		d.backMu.Unlock()
	} else {
		n.next = d.head
		d.head.prev = n
		d.head = n
	}

	d.frontMu.Unlock()

	d.lenMu.Lock()
	d.length++
	d.lenMu.Unlock()

	fmt.Println("PushFront:", value)
}

func (d *Deque) PushBack(value interface{}) {
	d.backMu.Lock()
	n := &node{value: value}

	if d.tail == nil {
		d.frontMu.Lock()
		d.head = n
		d.tail = n
		d.frontMu.Unlock()
	} else {
		d.tail.next = n
		n.prev = d.tail
		d.tail = n
	}

	d.backMu.Unlock()

	d.lenMu.Lock()
	d.length++
	d.lenMu.Unlock()

	fmt.Println("PushBack:", value)
}

func (d *Deque) PopFront() interface{} {
	d.frontMu.Lock()

	if d.head == nil {
		d.frontMu.Unlock()
		return nil
	}

	n := d.head
	d.head = n.next

	if d.head != nil {
		d.head.prev = nil
	} else {
		d.backMu.Lock()
		d.tail = nil
		d.backMu.Unlock()
	}

	d.frontMu.Unlock()

	d.lenMu.Lock()
	d.length--
	d.lenMu.Unlock()

	fmt.Println("PopFront:", n.value)
	return n.value
}

func (d *Deque) PopBack() interface{} {
	d.backMu.Lock()

	if d.tail == nil {
		d.backMu.Unlock()
		return nil
	}

	n := d.tail
	d.tail = n.prev

	if d.tail != nil {
		d.tail.next = nil
	} else {
		d.frontMu.Lock()
		d.head = nil
		d.frontMu.Unlock()
	}

	d.backMu.Unlock()

	d.lenMu.Lock()
	d.length--
	d.lenMu.Unlock()

	fmt.Println("PopBack:", n.value)
	return n.value
}

func (d *Deque) Len() int {
	d.lenMu.Lock()
	l := d.length
	d.lenMu.Unlock()
	return l
}

func main() {
	d := NewDeque()

	var wg sync.WaitGroup

	goroutines := 1000

	for i := 0; i < goroutines; i++ {
		wg.Add(1)
		go func(value int) {
			d.PushFront(value)
			wg.Done()
		}(i)
	}

	for i := 0; i < goroutines; i++ {
		wg.Add(1)
		go func(value int) {
			d.PushBack(value)
			wg.Done()
		}(i)
	}

	for i := 0; i < goroutines; i++ {
		wg.Add(1)
		go func() {
			d.PopFront()
			wg.Done()
		}()
	}

	for i := 0; i < goroutines; i++ {
		wg.Add(1)
		go func() {
			d.PopBack()
			wg.Done()
		}()
	}

	wg.Wait()

	fmt.Println("Final length:", d.Len())
}
