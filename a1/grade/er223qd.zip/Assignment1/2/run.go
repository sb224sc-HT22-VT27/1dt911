package main

import (
	"crypto/md5"
	"fmt"
	"runtime"
	"time"
)

func main() {
    runtime.GOMAXPROCS(runtime.NumCPU())
    target := "4f1749bac331cf85ba1e5fa7533be35f"

    charset := "abcdefghijklmnopqrstuvwxyz0123456789"

    workerCount := 16

    foundChan := make(chan string)

    start := time.Now()

    ranges := splitCharset(charset, workerCount)

    for _, r := range ranges {
        go worker(r, charset, target, foundChan)
    }

    password := <-foundChan

    fmt.Println("Password FOUND:", password)
    fmt.Println("Time taken:", time.Since(start))
}

func splitCharset(charset string, n int) []string {
    result := []string{}
    size := len(charset) / n
    extra := len(charset) % n 

    start := 0
    for i := 0; i < n; i++ {
        end := start + size
        if i < extra {
            end++
        }
        result = append(result, charset[start:end])
        start = end
    }
    return result
}

func worker(starts string, charset string, targetHash string, foundChan chan<- string) {

    for _, first := range starts {
        for _, c2 := range charset {
            for _, c3 := range charset {
                for _, c4 := range charset {
                    for _, c5 := range charset {
                        for _, c6 := range charset {

                            test := string(first) + string(c2) + string(c3) + string(c4) + string(c5) + string(c6)

                            hash := md5.Sum([]byte(string(test)))
                            hexString := fmt.Sprintf("%x", hash)

                            if hexString == targetHash {
                                foundChan <- test
                                return
                            }
                        }
                    }
                }
            }
        }
    }
}
