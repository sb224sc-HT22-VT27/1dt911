package main

import (
	"crypto/md5"
	"flag"
	"fmt"
	"log"
	"sync"
	"sync/atomic"
	"time"
)

const (
	alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
	passLen  = 6
)

var attempts uint64

func md5Hex(s string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(s)))
}

func indexToPass(n uint64) string {
	base := uint64(len(alphabet))
	out := make([]byte, passLen)
	for i := passLen - 1; i >= 0; i-- {
		out[i] = alphabet[n%base]
		n /= base
	}
	return string(out)
}

func worker(id int, targetHash string, work <-chan uint64, result chan<- string, done <-chan struct{}, wg *sync.WaitGroup) {
	defer wg.Done()
	for idx := range work {
		select {
		case <-done:
			return
		default:
		}

		if atomic.AddUint64(&attempts, 1)%1_000_000 == 0 {
			fmt.Printf("Checked %d passwords\n", attempts)
		}
		pwd := indexToPass(idx)

		// Compares hash to target
		if md5Hex(pwd) != targetHash {
			continue
		}

		select {
		case result <- pwd:
		case <-done:
		}
		return
	}
}

func generator(work chan<- uint64, done <-chan struct{}) {
	defer close(work)
	max := uint64(1)
	for i := 0; i < passLen; i++ {
		max *= uint64(len(alphabet))
	}

	for i := uint64(0); i < max; i++ {
		select {
		case <-done:
			return
		case work <- i:
		}
	}
}

func main() {
	const targetHash = "4f1749bac331cf85ba1e5fa7533be35f"
	workers := flag.Int("workers", 2, "number of worker goroutines")
	flag.Parse()
	if *workers <= 0 {
		log.Fatalf("workers must be > 0")
	}

	fmt.Println("Target hash:", targetHash)
	fmt.Println("Using workers:", *workers)
	work := make(chan uint64, 10000)
	result := make(chan string, 1)
	done := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(*workers)

	// Start worker
	for i := 0; i < *workers; i++ {
		go worker(i, targetHash, work, result, done, &wg)
	}

	// Start generator
	go generator(work, done)

	start := time.Now()
	pwd := <-result
	close(done)
	fmt.Println("Password found:", pwd)

	fmt.Println("Time taken:", time.Since(start))
}
