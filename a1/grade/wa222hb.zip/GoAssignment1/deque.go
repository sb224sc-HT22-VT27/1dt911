package main

import (
	"fmt"
	"sync"
)

type node struct {
	mutex sync.Mutex
	value interface{}
	past  *node
	next  *node
}

type Deque struct {
	head *node
	tail *node
}

func (d *Deque) Init() {
	d.head = &node{}
	d.tail = &node{}
	d.head.next = d.tail
	d.tail.past = d.head
}

// inserts value at front of deque
func (d *Deque) PushFront(v interface{}) {
	n := &node{value: v}

	d.head.mutex.Lock()
	first := d.head.next
	first.mutex.Lock()

	n.past = d.head
	n.next = first
	d.head.next = n
	first.past = n

	first.mutex.Unlock()
	d.head.mutex.Unlock()
}

// removes and returns value at front of the deque
func (d *Deque) PopFront() (interface{}, bool) {
	d.head.mutex.Lock()
	first := d.head.next
	first.mutex.Lock()

	if first == d.tail {
		first.mutex.Unlock()
		d.head.mutex.Unlock()
		return nil, false
	}

	second := first.next
	second.mutex.Lock()

	val := first.value
	d.head.next = second
	second.past = d.head

	second.mutex.Unlock()
	first.mutex.Unlock()
	d.head.mutex.Unlock()
	return val, true
}

// inserts value at back of deque
func (d *Deque) PushBack(v interface{}) {

	n := &node{value: v}

	last := d.tail.past
	last.mutex.Lock()
	d.tail.mutex.Lock()

	n.next = d.tail
	n.past = last
	last.next = n
	d.tail.past = n

	d.tail.mutex.Unlock()
	last.mutex.Unlock()
}

// removes and returns the value at back of deque
func (d *Deque) PopBack() (interface{}, bool) {
	d.tail.mutex.Lock()
	last := d.tail.past
	d.tail.mutex.Unlock()

	if last == d.head {
		return nil, false
	}

	before := last.past

	before.mutex.Lock()
	last.mutex.Lock()
	d.tail.mutex.Lock()

	val := last.value
	d.tail.past = before
	before.next = d.tail

	d.tail.mutex.Unlock()
	last.mutex.Unlock()
	before.mutex.Unlock()
	return val, true
}

func main() {
	var dq Deque
	dq.Init()

	dq.PushFront(10)
	dq.PushBack(20)

	var wg sync.WaitGroup
	wg.Add(2)

	go func() {
		defer wg.Done()
		dq.PopFront()
	}()

	go func() {
		defer wg.Done()
		dq.PopBack()
	}()

	wg.Wait()

	dq.PushFront(5)
	dq.PushBack(15)

	fmt.Println(dq.head.next.value)
	fmt.Println(dq.tail.past.value)
}
