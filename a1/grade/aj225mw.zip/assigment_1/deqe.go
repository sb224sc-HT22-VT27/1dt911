package main

import (
	"sync"
	"fmt"
)


type Node struct {
	value interface{}
	prev  *Node
	next  *Node
	lock  sync.Mutex
}


type Deque struct {
	head *Node 
	tail *Node 
	size int
	sizeMu sync.Mutex
}


func NewDeque() *Deque {
	h := &Node{}
	t := &Node{}
	h.next = t
	t.prev = h
	return &Deque{head: h, tail: t}
}



func (d *Deque) add_front(value interface{}) {
	pred := d.head
	pred.lock.Lock()

	curr := pred.next
	curr.lock.Lock()

	newNode := &Node{}
	newNode.value = value
	newNode.prev  = pred
	newNode.next  = curr

	pred.next = newNode
	curr.prev = newNode

	d.sizeMu.Lock()
	d.size++
	d.sizeMu.Unlock()

	curr.lock.Unlock()
	pred.lock.Unlock()
}

func (d *Deque) add_rear(value interface{}) {
	succ := d.tail
	succ.lock.Lock()

	curr := succ.prev
	curr.lock.Lock()

	newNode := &Node{}
	newNode.value = value
	newNode.prev  = curr
	newNode.next  = succ

	curr.next = newNode
	succ.prev = newNode

	d.sizeMu.Lock()
	d.size++
	d.sizeMu.Unlock()

	curr.lock.Unlock()
	succ.lock.Unlock()
}
func (d *Deque) remove_front() interface{} {
	pred := d.head
	pred.lock.Lock()

	curr := pred.next
	curr.lock.Lock()

	if curr == d.tail {
		curr.lock.Unlock()
		pred.lock.Unlock()
		return nil
	}

	succ := curr.next

	pred.lock.Unlock() 
	
	pred.next = succ
	succ.prev = pred

	d.sizeMu.Lock()
	d.size--
	d.sizeMu.Unlock()
	
	curr.lock.Unlock()

	return curr.value
}

func (d *Deque) remove_rear() interface{} {
	succ := d.tail
	succ.lock.Lock()

	curr := succ.prev
	curr.lock.Lock()

	if curr == d.head {
		curr.lock.Unlock()
		succ.lock.Unlock()
		return nil
	}

	pred := curr.prev

	succ.lock.Unlock()
	
	pred.next = succ
	succ.prev = pred

	d.sizeMu.Lock()
	d.size--
	d.sizeMu.Unlock()
	
	curr.lock.Unlock()

	return curr.value
}


func (d *Deque) Len() int {
	d.sizeMu.Lock()
	defer d.sizeMu.Unlock()	
	return d.size
}

func (d *Deque) String() string {
	result := ""
	node := d.head.next
	for node != d.tail {
		result += fmt.Sprintf("%v ", node.value)
		node = node.next
	}
	return result
}

func main() {
    d := NewDeque()

    var wg sync.WaitGroup
    n := 2000

    for i := 0; i < n; i++ {
        wg.Add(2)

        go func(v int) {
            defer wg.Done()
            d.add_front(v)
        }(i)

        go func(v int) {
            defer wg.Done()
            d.add_rear(v)
        }(i)
    }

    wg.Wait()

    fmt.Println("String representation:", d.String())
    fmt.Println("Full length:", d.Len())

    for i := 0; i < n; i++ {
        wg.Add(2)

        go func() {
            defer wg.Done()
            d.remove_front()
        }()

        go func() {
            defer wg.Done()
            d.remove_rear()
        }()
    }

    wg.Wait()

    fmt.Println("Final length (should be 0):", d.Len())
}