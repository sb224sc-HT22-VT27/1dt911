package main

import (
	"fmt"
	"sync"
	"time"
)

type Node struct {
	value interface{}
	prev  *Node
	next  *Node
}


type Deque struct {
	head *Node
	tail *Node
	size int
	frontlock sync.Mutex
	backlock  sync.Mutex
}

func newDeque() *Deque {
	return &Deque{}
}


func (self *Deque) add_front(value interface{}) {
    newNode := &Node{value: value}
    self.frontlock.Lock()
    self.backlock.Lock()

    if self.head == nil {
        self.head = newNode
        self.tail = newNode
    } else {
        newNode.next = self.head
        self.head.prev = newNode
        self.head = newNode
    }
    self.size++
    self.backlock.Unlock()
    self.frontlock.Unlock()
}


func (self *Deque) add_rear(value interface{}) {
    newNode := &Node{value: value}
    self.frontlock.Lock()
    self.backlock.Lock()

    if self.tail == nil { 
        self.head = newNode
        self.tail = newNode
    } else {
        self.tail.next = newNode
        newNode.prev = self.tail
        self.tail = newNode
    }
    self.size++
    self.backlock.Unlock()
    self.frontlock.Unlock()
}


func (self *Deque) is_empty() bool {
	self.frontlock.Lock()
    self.backlock.Lock()
	empty := self.size == 0
	self.backlock.Unlock()
    self.frontlock.Unlock()

	return empty
}

func (self *Deque) __str__() string {
	result := ""
	node := self.head
	for node != nil {
		result += fmt.Sprintf("%v ", node.value)
		node = node.next
	}
	return result
}

func (self *Deque) remove_front() interface{} {
    self.frontlock.Lock()
    self.backlock.Lock()
    if self.head == nil {
        self.backlock.Unlock()
        self.frontlock.Unlock()
        return nil
    }

    value := self.head.value
    self.head = self.head.next

    if self.head == nil {
        self.tail = nil
    } else {
        self.head.prev = nil
    }
    self.size--
    self.backlock.Unlock()
    self.frontlock.Unlock()

    return value
}


func (self *Deque) remove_rear() interface{} {
    self.frontlock.Lock()
    self.backlock.Lock()
    if self.tail == nil {
        self.backlock.Unlock()
        self.frontlock.Unlock()
        return nil
    }

    value := self.tail.value
    self.tail = self.tail.prev
    if self.tail == nil {
        self.head = nil
    } else {
        self.tail.next = nil
    }
    self.size--
    self.backlock.Unlock()
    self.frontlock.Unlock()

    return value
}


func main() {

	
	d := newDeque()

    var wg sync.WaitGroup

    delay := func() {
        time.Sleep(time.Millisecond * time.Duration(5))
    }

	// add 20 front
    for i := 0; i < 20; i++ {
        wg.Add(1)
        go func(v int) {
            defer wg.Done()
            d.add_front(v)
			fmt.Println("Added to front:", v)
            delay()
        }(i)
    }

	// add 20 back, numbers from 100 to 120
    for i := 100; i < 120; i++ {
        wg.Add(1)
        go func(v int) {
            defer wg.Done()
            d.add_rear(v)
			fmt.Println("Added to rear:", v)
        	delay()
        }(i)
    }
	fmt.Println(" ")

	// remove 20 from front
    for i := 0; i < 20; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            val := d.remove_front()
			fmt.Println("Removed from front:", val)
            delay()
        }()
    }
	fmt.Println(" ")
	// remove 20 from back
    for i := 0; i < 20; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            val := d.remove_rear()
			fmt.Println("Removed from rear:", val)
            delay()
        }()
    }

    wg.Wait()

    fmt.Println("Slutresultat i deque:", d.__str__())
    fmt.Println("Size:", d.size)
	fmt.Println("Is empty:", d.is_empty())
}
