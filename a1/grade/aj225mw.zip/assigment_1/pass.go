package main

import (
	"fmt"
	"crypto/md5"
	"runtime"
	"time"
)
// translate nubbetr to letter
func indexToChar(i int) rune {
	if i < 26 {
		return rune('a' + i)
	}
	return rune('0' + (i - 26))
}

func bruteWorker(start, end int, target string, result chan<- string, done <-chan struct{}) {

	test := []rune("aaaaaa")

	for a := start; a <= end; a++ {
		test[0] = indexToChar(a)

		for b := 0; b < 36; b++ {
			test[1] = indexToChar(b)

			for c := 0; c < 36; c++ {
				test[2] = indexToChar(c)

				for d := 0; d < 36; d++ {
					test[3] = indexToChar(d)

					for e := 0; e < 36; e++ {
						test[4] = indexToChar(e)

						for f := 0; f < 36; f++ {

							select {
							case <-done:
								return
							default:
							}

							test[5] = indexToChar(f)

							hash := md5.Sum([]byte(string(test)))
							hexString := fmt.Sprintf("%x", hash)

							if hexString == target {
								result <- string(test)
								return
							}
						}
					}
				}
			}
		}
	}
}

func main() {
	runtime.GOMAXPROCS(runtime.NumCPU())
	startTime := time.Now()

	password_r := "4f1749bac331cf85ba1e5fa7533be35f"


	result := make(chan string)
	done := make(chan struct{})

	workers := 36  // max 36
	slice := 36 / workers

	// add workers and let the start at their own letter
	for w := 0; w < workers; w++ {
		start := w * slice
		end := start + slice - 1
		if w == workers-1 {
			end = 35
		}

		go bruteWorker(start, end, password_r, result, done)
	}

	found := <-result
	close(done)
	elapsed := time.Since(startTime)

	fmt.Println("FOUND:", found)
	fmt.Println("Time to run: ", elapsed)
}
