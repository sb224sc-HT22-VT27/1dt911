package main

import (
	"fmt"
	"sync"
)

type Deque struct {
	head   *Node
	tail   *Node
	headMu sync.Mutex
	tailMu sync.Mutex
}

func (d *Deque) PushFront(val interface{}) {
	node := &Node{value: val}

	d.headMu.Lock()
	defer d.headMu.Unlock()

	if d.head == nil {
		d.tailMu.Lock()
		d.head = node
		d.tail = node
		d.tailMu.Unlock()
	} else {
		node.next = d.head
		d.head.prev = node
		d.head = node
	}
}

func (d *Deque) PushBack(val interface{}) {
	node := &Node{value: val}

	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	if d.tail == nil {
		d.headMu.Lock()
		d.head = node
		d.tail = node
		d.headMu.Unlock()
	} else {
		node.prev = d.tail
		d.tail.next = node
		d.tail = node
	}
}

func (d *Deque) PopFront() interface{} {
	d.headMu.Lock()
	defer d.headMu.Unlock()

	if d.head == nil {
		return nil
	}

	node := d.head
	val := node.value
	d.head = node.next

	if d.head != nil {
		d.head.prev = nil
	} else {
		d.tailMu.Lock()
		d.tail = nil
		d.tailMu.Unlock()
	}

	node.next = nil
	node.prev = nil
	return val
}

func (d *Deque) PopBack() interface{} {
	d.tailMu.Lock()
	defer d.tailMu.Unlock()

	if d.tail == nil {
		return nil
	}

	node := d.tail
	val := node.value
	d.tail = node.prev

	if d.tail != nil {
		d.tail.next = nil
	} else {
		d.headMu.Lock()
		d.head = nil
		d.headMu.Unlock()
	}

	node.next = nil
	node.prev = nil
	return val
}

func (d *Deque) Print() {
	d.headMu.Lock()
	d.tailMu.Lock()
	defer d.tailMu.Unlock()
	defer d.headMu.Unlock()

	current := d.head
	if current == nil {
		fmt.Println("Empty Deque")
		return
	}

	fmt.Print("[")
	for current != nil {
		fmt.Print(current.value, " ")
		current = current.next
	}
	fmt.Println("]")
}
