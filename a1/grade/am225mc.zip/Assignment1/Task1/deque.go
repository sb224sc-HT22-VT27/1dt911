package main

import "fmt"

type Deque struct {
	head *Node
	tail *Node
}

func NewDeque() *Deque {
	h := &Node{}
	t := &Node{}

	h.next = t
	t.prev = h

	return &Deque{head: h, tail: t}
}

func (d *Deque) PushFront(val interface{}) {
	newNode := &Node{value: val}

	d.head.mu.Lock()
	defer d.head.mu.Unlock()

	first := d.head.next

	first.mu.Lock()
	defer first.mu.Unlock()

	newNode.next = first
	newNode.prev = d.head
	d.head.next = newNode
	first.prev = newNode
}

func (d *Deque) PushBack(val interface{}) {
	newNode := &Node{value: val}

	d.tail.mu.Lock()
	defer d.tail.mu.Unlock()
	last := d.tail.prev

	last.mu.Lock()
	defer last.mu.Unlock()

	newNode.prev = last
	newNode.next = d.tail
	last.next = newNode
	d.tail.prev = newNode
}

func (d *Deque) PopFront() interface{} {
	d.head.mu.Lock()
	defer d.head.mu.Unlock()

	first := d.head.next

	first.mu.Lock()
	defer first.mu.Unlock()

	if first == d.tail {
		return nil
	}

	second := first.next
	second.mu.Lock()
	defer second.mu.Unlock()

	d.head.next = second
	second.prev = d.head

	val := first.value

	return val
}

func (d *Deque) PopBack() interface{} {
	d.tail.mu.Lock()
	defer d.tail.mu.Unlock()

	last := d.tail.prev
	last.mu.Lock()
	defer last.mu.Unlock()

	if last == d.head {
		return nil
	}

	secondLast := last.prev
	secondLast.mu.Lock()
	defer secondLast.mu.Unlock()

	d.tail.prev = secondLast
	secondLast.next = d.tail

	val := last.value

	return val
}

func (d *Deque) Print() {
	current := d.head

	current.mu.Lock()
	next := current.next
	current.mu.Unlock()

	fmt.Print("[")

	for next != d.tail {
		next.mu.Lock()

		fmt.Print(next.value)

		nextNode := next.next

		next.mu.Unlock()

		next = nextNode

		if next != d.tail {
			fmt.Print(" ")
		}
	}

	fmt.Println("]")
}