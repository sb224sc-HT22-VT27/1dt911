package main

import (
	"fmt"
	"sync"
)

func main() {
	d := NewDeque()
	var wg sync.WaitGroup
	tasks := 4

	// Push four numbers front
	for i := 0; i < tasks; i++ {
		wg.Add(1)
		go func(x int) {
			defer wg.Done()
			d.PushFront(x * 10)
		}(i)

	}

	// Push four numbers back
	for i := 0; i < tasks; i++ {
		wg.Add(1)
		go func(x int) {
			defer wg.Done()
			d.PushBack(x * 10)
		}(i)

	}
	//wg.Wait()

	
	// Pop 4 numbers front
	for i := 0; i < tasks; i++ {
		wg.Add(1)
		go func(x int) {
			defer wg.Done()
			d.PopFront()
		}(i)

	}
	wg.Wait()
	/*
	// Pop four numbers back
	for i := 0; i < tasks; i++ {
		wg.Add(1)
		go func(x int) {
			defer wg.Done()
			d.PopBack()
		}(i)

	}
	*/
	wg.Wait()


	fmt.Println("Finished deque:")
	d.Print()
}
