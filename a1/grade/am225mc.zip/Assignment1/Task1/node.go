package main

type Node struct {
	value interface{}
	next  *Node
	prev  *Node
}
