package main

import "sync"

type Node struct {
	value interface{}
	next  *Node
	prev  *Node
	mu    sync.Mutex
}
