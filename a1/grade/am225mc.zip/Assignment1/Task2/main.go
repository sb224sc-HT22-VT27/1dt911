package main

import (
	"fmt"
	"sync"
	"time"
)

const (
	length   = 6
	alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
)

func main() {
	target := "4f1749bac331cf85ba1e5fa7533be35f"

	total := uint64(1)
	for i := 0; i < length; i++ {
		total *= uint64(len(alphabet))
	}

	numWorkers := 16
	fmt.Println("Number of go-routines:", numWorkers)

	chunks := total / uint64(numWorkers)

	found := make(chan string)
	done := make(chan struct{})

	var wg sync.WaitGroup
	wg.Add(numWorkers)

	start := time.Now()
	for w := 0; w < numWorkers; w++ {
		start := uint64(w) * chunks
		end := start + chunks
		if w == numWorkers-1 {
			end = total
		}

		go worker(start, end, target, found, done, &wg)
	}

	result := <-found
	elapsed := time.Since(start)
	fmt.Println("FOUND:", result)
	fmt.Println("Time took:", elapsed)

	close(done)
	wg.Wait()
}
