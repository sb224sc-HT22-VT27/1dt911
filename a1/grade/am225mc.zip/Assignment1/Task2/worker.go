package main

import (
	"crypto/md5"
	"encoding/hex"
	"sync"
)

func worker(start, end uint64, target string,
	found chan<- string, done <-chan struct{}, wg *sync.WaitGroup) {

	defer wg.Done()

	var buf [length]byte
	for idx := start; idx < end; idx++ {

		select {
		case <-done:
			return
		default:
		}

		indexToPassword(idx, &buf)

		sum := md5.Sum(buf[:])

		if hex.EncodeToString(sum[:]) == target {
			found <- string(buf[:])
			return
		}
	}
}
