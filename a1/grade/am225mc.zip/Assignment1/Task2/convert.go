package main

func indexToPassword(n uint64, out *[length]byte) {
	base := uint64(len(alphabet))

	for i := length - 1; i >= 0; i-- {
		out[i] = alphabet[n%base]
		n /= base
		if i == 0 {
			return
		}
	}
}
